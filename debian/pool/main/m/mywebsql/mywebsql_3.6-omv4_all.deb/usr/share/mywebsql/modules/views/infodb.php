<div id='results'>
	<div class='heading1'><?php echo __('Table information'); ?></div>
	
</div>

<script type="text/javascript" language="javascript">
parent.transferInfoMessage();
</script>
