#!/bin/sh

set -e

. /usr/share/openmediavault/scripts/helper-functions

omv_module_set_dirty monit

exit 0
