<?php
/**
 * @license   http://www.gnu.org/licenses/gpl.html GPL Version 3
 * @author    Volker Theile <volker.theile@openmediavault.org>
 * @copyright Copyright (c) 2009-2013 Volker Theile
 * @copyright Copyright (c) 2013-2026 openmediavault plugin developers
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
require_once("openmediavault/globals.inc");
require_once("openmediavault/functions.inc");

class OMVRpcServiceRemoteMount extends \OMV\Rpc\ServiceAbstract
{
    public function getName()
    {
        return "RemoteMount";
    }

    public function initialize()
    {
        $this->registerMethod("getList");
        $this->registerMethod("getListBg");
        $this->registerMethod("enumerateMounts");
        $this->registerMethod("get");
        $this->registerMethod("set");
        $this->registerMethod("delete");
        $this->registerMethod("mount");
        $this->registerMethod("getLogs");
    }

    private function getMountsAssoc()
    {
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $objects = $db->get("conf.service.remotemount.mount");
	    $sfobjects = $db->get("conf.system.sharedfolder");
        // Add additional mount informations.
        $objectsAssoc = [];
        foreach ($objects as $objectk => &$objectv) {
            $mntentref = $objectv->get("mntentref");
            $inuse = false;
            foreach ($sfobjects as $sfobject) {
                $sfmntentref = $sfobject->get("mntentref");
                if ($mntentref == $sfmntentref) {
                    $inuse = true;
                    break;
                }
            }
            $objectv->add("inuse", "boolean", $inuse);
            // Add usage statistics so they can be surfaced in the
            // dashboard widget. `getStatistics` runs `df` against the
            // mount point, so it works for network filesystems too.
            // A share whose remote server is down/unreachable must still
            // show up here (so it stays visible and editable) rather than
            // breaking the whole list, so any failure while probing it is
            // caught and simply reported as "not mounted, no stats".
            $mounted = false;
            $size = $used = $available = "-1";
            $percentage = -1;
            $usagewarnthreshold = 0;
            try {
                $fs = \OMV\System\Filesystem\Filesystem::getImpl($objectv->get('uuid'));
                $mounted = $fs->isMounted();
                if (true === $mounted && (false !== ($stats = $fs->getStatistics()))) {
                    $size = $stats['size'];
                    $used = $stats['used'];
                    $available = $stats['available'];
                    $percentage = $stats['percentage'];
                    try {
                        $mntobj = $db->get("conf.system.filesystem.mountpoint",
                            $mntentref);
                        $usagewarnthreshold = $mntobj->get('usagewarnthreshold');
                    } catch (\Exception $e) {
                        // Mount point configuration object does not exist.
                    }
                }
            } catch (\Exception $e) {
                // Could not determine the status of this mount (e.g. its
                // remote server is unreachable). Fall back to the defaults
                // above instead of aborting the whole listing.
            }
            $objectv->add("mounted", "boolean", $mounted);
            $objectv->add("size", "string", $size);
            $objectv->add("used", "string", $used);
            $objectv->add("available", "string", $available);
            $objectv->add("percentage", "integer", $percentage);
            $objectv->add("usagewarnthreshold", "integer", $usagewarnthreshold);
            $assoc = $objectv->getAssoc();
            if ($assoc['mounttype'] === 'rclone' && !empty($assoc['rclonetype'])) {
                $assoc['mounttype'] = sprintf('rclone (%s)', $assoc['rclonetype']);
            }
            $objectsAssoc[] = $assoc;
        }
        return $objectsAssoc;
    }

    public function getList($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.getlist");
        // Filter the result.
        $objectsAssoc = $this->getMountsAssoc();
        return $this->applyFilter($objectsAssoc, $params['start'], $params['limit'],
            $params['sortfield'], $params['sortdir']);
    }

    public function getListBg($params, $context) {
        return $this->callMethodBg("getList", $params, $context);
    }

    public function enumerateMounts($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        return $this->getMountsAssoc();
    }

    public function get($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.objectuuid");
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $object = $db->get("conf.service.remotemount.mount", $params['uuid']);
        return $object->getAssoc();
    }

    public function set($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        $db = \OMV\Config\Database::getInstance();
        // Normalize the server field: collapse any accidental doubled '%' (e.g.
        // the old '%%40' WebDAV workaround) back to a single '%'. A valid URL
        // only uses '%' as part of '%XX' percent-encoding, so '%%' is never
        // legitimate; the systemd .mount template re-escapes '%' -> '%%' for
        // systemd on its own.
        if (isset($params['server'])) {
            $params['server'] = preg_replace('/%{2,}/', '%', $params['server']);
        }
        // Obscure password for rclone protocols that require it (sftp, ftp, webdav).
        $rclonetype = isset($params['rclonetype']) ? $params['rclonetype'] : 's3';
        if (isset($params['mounttype']) && $params['mounttype'] === 'rclone' &&
                in_array($rclonetype, ['sftp', 'ftp', 'webdav']) &&
                !empty($params['password'])) {
            $shouldObscure = true;
            try {
                $existingObj = $db->get("conf.service.remotemount.mount", $params['uuid']);
                $shouldObscure = ($params['password'] !== $existingObj->get('password'));
            } catch (\Exception $e) {
                // New object — always obscure.
            }
            if ($shouldObscure) {
                $proc = new \OMV\System\Process('rclone', ['obscure', $params['password']]);
                $output = [];
                $proc->execute($output);
                $params['password'] = trim($output[0]);
            }
        }
        // Prepare the configuration object.
        $object = new \OMV\Config\ConfigObject("conf.service.remotemount.mount");
        $object->setAssoc($params);
        // Set the configuration object.
        $isNew = $object->isNew();
        if (TRUE === $isNew) {
            // Check uniqueness
            $db->assertIsUnique($object, "name");
        }
        $db->set($object);
        // create mntent entry for new mounts
        if (TRUE === $isNew) {
            $baseDir = \OMV\Environment::get("OMV_MOUNT_DIR");
            $result = \OMV\Rpc\Rpc::call('FsTab', 'set', [
                'uuid' => $object->get('mntentref'),
                'fsname' => $object->get('uuid'),
                'dir' => sprintf("%s/remotemount/%s", $baseDir, $object->get('name')),
                'type' => $object->get('mounttype'),
                'opts' => '',
                'freq' => 0,
                'passno' => 0,
                'hidden' => true,
            ], $context);
            // update uuid in config
            $object->set('mntentref', $result['uuid']);
            $db->set($object);
        }
        // Return the configuration object.
        return $object->getAssoc();
    }

    public function delete($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.objectuuid");
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $object = $db->get("conf.service.remotemount.mount", $params['uuid']);
        // Delete the configuration object.
        $db->delete($object);
        // Delete the filesystem
        \OMV\Rpc\Rpc::call("FsTab", "delete", [
            "uuid" => $object->get("mntentref")
        ], $context);
        // Return the deleted configuration object.
        return $object->getAssoc();
    }

    public function mount($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $rmntobj = $db->get("conf.service.remotemount.mount", $params['uuid']);
        $mntobj = $db->get("conf.system.filesystem.mountpoint", $rmntobj->get('mntentref'));
        $action = $params['action'];
        // get escaped systemd unit (service for rclone, mount for all others)
        $suffix = ($rmntobj->get('mounttype') === 'rclone') ? 'service' : 'mount';
        $cmdArgs = [];
        $cmdArgs[] = '--path';
        $cmdArgs[] = '--suffix=' . $suffix;
        $cmdArgs[] = $mntobj->get('dir');
        $output = [];
        $cmd = new \OMV\System\Process('systemd-escape', $cmdArgs);
        $cmd->execute($output, $exitStatus);
        // perform action on systemd mount
        // escapeshellarg prevents the shell (exec) from eating the literal backslash in e.g. \x2d.
        $unitName = escapeshellarg($output[0]);
        $cmdArgs = [];
        $cmdArgs[] = $action;
        $cmdArgs[] = $unitName;
        $output = [];
        $cmd = new \OMV\System\Process('systemctl', $cmdArgs);
        $cmd->execute($output, $exitStatus);
        // Tell monit immediately so it does not auto-remount before the next
        // config apply. On unmount always unmonitor temporarily; on mount only
        // re-enable monitoring if the persistent preference says to.
        $checkId = preg_replace('/\.(mount|service)$/', '', trim($unitName, "'"));
        if ($action === 'stop' || $rmntobj->get('monitored')) {
            $monitAction = ($action === 'stop') ? 'unmonitor' : 'monitor';
            try {
                $cmd = new \OMV\System\Process('monit', [$monitAction, 'mountpoint' . $checkId]);
                $output = [];
                $cmd->execute($output, $exitStatus);
            } catch (\Exception $e) {
                // monit may not be active or the check may not exist yet.
            }
        }
    }

    public function getLogs($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.objectuuid");
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $rmntobj = $db->get("conf.service.remotemount.mount", $params['uuid']);
        $mntobj = $db->get("conf.system.filesystem.mountpoint", $rmntobj->get('mntentref'));
        // Derive the escaped systemd unit name the same way mount() does
        // (service for rclone, mount for all others).
        $suffix = ($rmntobj->get('mounttype') === 'rclone') ? 'service' : 'mount';
        $cmdArgs = [];
        $cmdArgs[] = '--path';
        $cmdArgs[] = '--suffix=' . $suffix;
        $cmdArgs[] = $mntobj->get('dir');
        $output = [];
        $cmd = new \OMV\System\Process('systemd-escape', $cmdArgs);
        $cmd->execute($output, $exitStatus);
        $unitName = trim($output[0]);
        // Stream the journal for this unit to the task dialog.
        // escapeshellarg keeps the literal backslashes (e.g. \x2d) intact so
        // journalctl matches the real unit name.
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($unitName) {
                $cmdLine = sprintf(
                    'journalctl --no-pager --no-hostname --lines=1000 --unit=%s',
                    escapeshellarg($unitName)
                );
                if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                    throw new \OMV\ExecException($cmdLine, $output);
                }
                return $output;
            }
        );
    }
}
