{% set config = salt['omv_conf.get']('conf.service.sftp') %}
{% set ns = namespace(option='', seen=[]) %}
{% for share in config.shares.share %}
{% set sfpath = salt['omv_conf.get_sharedfolder_path'](share.sharedfolderref) %}
{% set sfpath2 = sfpath | escape_blank %}
{% set sf_config = salt['omv_conf.get']('conf.system.sharedfolder', share.sharedfolderref) %}
{% set sftppath = '/sftp/' + share.username + '/' + sf_config.name | escape_blank %}
{# Skip shares whose mount target was already emitted to avoid duplicate #}
{# fstab entries and redundant mount states for the same path. #}
{% if sftppath in ns.seen %}
{% continue %}
{% endif %}
{% set ns.seen = ns.seen + [sftppath] %}
{% set ns.option = '' %}
{% for privilege in sf_config.privileges.privilege | selectattr('name', 'equalto', share.username) %}
{% if privilege.perms == 5 %}
{% set ns.option = 'bind,ro,nofail' %}
{% elif privilege.perms == 7 %}
{% set ns.option = 'bind,rw,nofail' %}
{% endif %}
{% endfor %}

{% if ns.option != "" %}
create_sftp_mountpoint_{{ share.uuid }}:
  file.accumulated:
    - filename: "/etc/fstab"
    - text: "{{ sfpath2 }}\t\t{{ sftppath }}\tnone\t{{ ns.option }},x-systemd.requires-mounts-for={{ sfpath2 }},x-systemd.before=omv-sftp.service\t0 0"
    - require_in:
      - file: append_fstab_entries

unmount_sftp_mountpoint_{{ share.uuid }}:
  cmd.run:
    - name: "umount --lazy --quiet '{{ sftppath }}'"
    - onlyif: "mountpoint -q '{{ sftppath }}' && [ \"$(findmnt --output SOURCE --noheadings '{{ sftppath }}')\" != '{{ sfpath }}' ]"

mount_sftp_mountpoint_{{ share.uuid }}:
  mount.mounted:
    - name: {{ sftppath }}
    - device: {{ sfpath }}
    - fstype: "none"
    - opts: {{ ns.option }}
    - mkmnt: True
    - persist: False
    - mount: True
    - require:
      - cmd: unmount_sftp_mountpoint_{{ share.uuid }}
{% else %}

{% if salt['file.directory_exists'](sftppath) %}
unmount_sftp_mountpoint_{{ share.uuid }}:
  cmd.run:
    - name: "umount --lazy --quiet '{{ sftppath }}'"
    - check_cmd:
      - /usr/bin/true

remove_openmediavault_dir_{{ share.uuid }}:
  cmd.run:
    - name: "rmdir '{{ sftppath }}'"
{% endif %}

{% endif %}
{% endfor %}
