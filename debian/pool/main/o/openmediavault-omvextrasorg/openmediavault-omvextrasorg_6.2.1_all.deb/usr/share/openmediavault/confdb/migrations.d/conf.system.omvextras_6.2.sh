#!/bin/sh

. /usr/share/openmediavault/scripts/helper-functions

omv_module_set_dirty omvextras

exit 0
