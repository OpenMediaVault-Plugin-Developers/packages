# @license   http://www.gnu.org/licenses/gpl.html GPL Version 3
# @author    OpenMediaVault Plugin Developers <plugins@omv-extras.org>
# @copyright Copyright (c) 2025-2026 openmediavault plugin developers
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

{% set config = salt['omv_conf.get']('conf.service.writecache') %}

{% set enabled = config.enable | to_bool %}
{% set use_tmpfs = (config.use_tmpfs | to_bool) or (config.sharedfolderref == '') %}
{% set tmpfs_size = config.tmpfs_size %}
{% if use_tmpfs and (tmpfs_size in ['', '0%']) %}
{%   set tmpfs_size = '25%' %}
{% elif not use_tmpfs %}
{%   set tmpfs_size = '0%' %}
{% endif %}

{% set ram_backing = config.get('ram_backing', 'tmpfs') %}
{% set workspace_type = (('zram' if ram_backing == 'zram' else 'tmpfs') if use_tmpfs else 'path') %}
{% set workspace_root = '' if use_tmpfs else salt['omv_conf.get_sharedfolder_path'](config.sharedfolderref) %}

{# cmd_unmount() already checks flush_on_shutdown itself to decide whether to
   flush before tearing overlays down, so ExecStop must always resolve to a
   valid 'unmount'/'rotateunmount' command -- gating it here on
   flush_on_shutdown left shutdown_action as Jinja's None, which rendered as
   the literal (invalid) command "None" and made ExecStop fail on every
   stop/reboot whenever flush-on-shutdown was disabled. #}
{% set shutdown_action = 'rotateunmount' if (config.rotate_on_shutdown | to_bool) else 'unmount' %}

{% set flush_hourly = config.flush_hourly | to_bool %}

{% set daily_action = None %}
{% if enabled and (config.flush_daily | to_bool) %}
{%   set daily_action = 'rotateflush' if (config.rotate_on_daily_flush | to_bool) else 'flush' %}
{% endif %}

{% set unit_after  = 'systemd-remount-fs.service local-fs-pre.target' ~ (' tmp.mount' if use_tmpfs else '') %}
{% set unit_before = 'local-fs.target systemd-journald.service postfix@-.service' ~ (' systemd-tmpfiles-setup.service' if use_tmpfs else '') %}


php-fpm-tmpfiles-conf:
  file.managed:
    - name: /etc/tmpfiles.d/php-fpm.conf
    - contents: |
        d /run/php 0755 root root -
    - mode: '0644'
    - user: root
    - group: root

configure_writecache_config_dir:
  file.directory:
    - name: /etc/omv-writecache
    - user: root
    - group: root
    - mode: '0755'

configure_writecache_config:
  file.managed:
    - name: /etc/omv-writecache/config.yaml
    - contents: |
        {{ pillar['headers']['auto_generated'] }}
        {{ pillar['headers']['warning'] }}
        enable: {{ enabled }}
        workspace_type: {{ workspace_type }}
        workspace_root: "{{ workspace_root }}"
        tmpfs_size: "{{ tmpfs_size }}"
        zram_size: "{{ config.zram_size }}"
        zram_algo: "{{ config.zram_algo }}"
        journald_storage: "{{ config.journald_storage }}"
        flush_on_boot: {{ config.flush_on_boot | to_bool }}
        flush_on_shutdown: {{ config.flush_on_shutdown | to_bool }}
        flush_hourly: {{ flush_hourly }}
        flush_daily: {{ config.flush_daily | to_bool }}
        paths: |
{%- for p in config.get('paths', '').splitlines() if p.strip() %}
          {{ p.strip() }}
{%- endfor %}
        services: |
{%- for s in config.get('services', '').splitlines() if s.strip() %}
          {{ s.strip() }}
{%- endfor %}
    - user: root
    - group: root
    - mode: '0644'

configure_writecache_journald_dir:
  file.directory:
    - name: /etc/systemd/journald.conf.d
    - user: root
    - group: root
    - dir_mode: '0755'

remove_old_writecache_journald:
  file.absent:
    - name: /etc/systemd/journald.conf.d/10-writecache.conf

configure_writecache_journald:
  file.managed:
    - name: /etc/systemd/journald.conf.d/50-writecache.conf
    - contents: |
        {{ pillar['headers']['auto_generated'] }}
        {{ pillar['headers']['warning'] }}
        [Journal]
        Storage={{ config.journald_storage }}
    - user: root
    - group: root
    - mode: '0644'

{# One state is enough: reload journald when the conf changes #}
restart_journald_on_change:
  service.running:
    - name: systemd-journald
    - reload: True
    - onchanges:
      - file: configure_writecache_journald


{% if enabled %}

omv-writecache-setup_service:
  file.managed:
    - name: /etc/systemd/system/omv-writecache-setup.service
    - contents: |
        [Unit]
        Description=OMV WriteCache: overlays lifecycle
        DefaultDependencies=no
        After={{ unit_after }}
        Before={{ unit_before }}
{%- if use_tmpfs %}
        RequiresMountsFor=/var
{%- else %}
        RequiresMountsFor={{ workspace_root }}
{%- endif %}
        Conflicts=shutdown.target umount.target
        Before=shutdown.target umount.target final.target

        [Service]
        Type=oneshot
        RemainAfterExit=yes
        ExecStart=/usr/sbin/omv-writecache mount
        ExecStop=/usr/sbin/omv-writecache {{ shutdown_action }}
        TimeoutStartSec=180
        TimeoutStopSec=300
        KillMode=none
        SendSIGKILL=no

        [Install]
        WantedBy=local-fs.target
    - user: root
    - group: root
    - mode: '0644'

{% else %}

omv-writecache-setup_service:
  file.absent:
    - name: /etc/systemd/system/omv-writecache-setup.service

{% endif %}

{# Always remove any explicit mount unit file left over from previous approach #}
omv-writecache-workspace-mount:
  file.absent:
    - name: /etc/systemd/system/run-omv\x2dwritecache.mount

{% if enabled and use_tmpfs %}

omv-writecache-workspace-mount-dropin-dir:
  file.directory:
    - name: /etc/systemd/system/run-omv\x2dwritecache.mount.d
    - user: root
    - group: root
    - mode: '0755'

omv-writecache-workspace-mount-dropin:
  file.managed:
    - name: /etc/systemd/system/run-omv\x2dwritecache.mount.d/10-before-setup.conf
    - contents: |
        [Unit]
        DefaultDependencies=no
        Before=omv-writecache-setup.service
    - user: root
    - group: root
    - mode: '0644'
    - require:
      - file: omv-writecache-workspace-mount-dropin-dir

{% else %}

omv-writecache-workspace-mount-dropin-dir:
  file.absent:
    - name: /etc/systemd/system/run-omv\x2dwritecache.mount.d

omv-writecache-workspace-mount-dropin:
  file.absent:
    - name: /etc/systemd/system/run-omv\x2dwritecache.mount.d/10-before-setup.conf

{% endif %}

writecache_systemctl_daemon_reload:
  module.run:
    - name: service.systemctl_reload
    - onchanges:
      - file: omv-writecache-setup_service
      - file: omv-writecache-workspace-mount-dropin

{% if enabled %}

writecache_setup_service_enable:
  service.running:
    - name: omv-writecache-setup.service
    - enable: True
    - require:
      - file: omv-writecache-setup_service
    - watch:
      - file: omv-writecache-setup_service

writecache_reconfigure_overlays:
  cmd.run:
    - name: /usr/sbin/omv-writecache remount --reconfigure
    - onchanges:
      - file: configure_writecache_config
    - require:
      - service: writecache_setup_service_enable

{% else %}

writecache_setup_service_disable:
  service.dead:
    - name: omv-writecache-setup.service
    - enable: False

{% endif %}


{% if daily_action or flush_hourly %}

omv_writecache_cron:
  file.managed:
    - name: /etc/cron.d/omv-writecache
    - contents: |
        {{ pillar['headers']['auto_generated'] }}
        {{ pillar['headers']['warning'] }}
{%- if daily_action %}
        {{ config.minute }} {{ config.hour }} * * * root /usr/sbin/omv-writecache {{ daily_action }} --restart --daily >/dev/null 2>&1
{%- endif %}
{%- if flush_hourly %}
        @hourly root /usr/sbin/omv-writecache flush --restart >/dev/null 2>&1
{%- endif %}
    - user: root
    - group: root
    - mode: '0644'

{% else %}

omv_writecache_cron:
  file.absent:
    - name: /etc/cron.d/omv-writecache

{% endif %}
