#!/bin/bash

set -e

. /usr/share/openmediavault/scripts/helper-functions

omv_module_set_dirty writecache

exit 0
