<?php
/*
 * @author    Volker Theile <volker.theile@openmediavault.org>
 * @author    OpenMediaVault Plugin Developers <plugins@omv-extras.org>
 * @copyright Copyright (c) 2009-2013 Volker Theile
 * @copyright Copyright (c) 2013-2026 openmediavault plugin developers
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

class OMVRpcServiceBorgBackup extends \OMV\Rpc\ServiceAbstract
{
    private $getProgram = '/usr/bin/borg';
    private $envFile = '/etc/borgbackup/borg-envvar-';

    public function getName()
    {
        return 'BorgBackup';
    }

    public function initialize()
    {
        $this->registerMethod('enumerateRepoCandidates');
        $this->registerMethod('getRepoList');
        $this->registerMethod('getRepo');
        $this->registerMethod('setRepo');
        $this->registerMethod('changeRepoPath');
        $this->registerMethod('changeQuota');
        $this->registerMethod('downloadKey');
        $this->registerMethod('deleteRepo');
        $this->registerMethod('repoCommand');
        $this->registerMethod('mountRepo');
        $this->registerMethod('unmountRepo');
        $this->registerMethod('changePassphrase');

        $this->registerMethod('getArchiveList');
        $this->registerMethod('getArchive');
        $this->registerMethod('setArchive');
        $this->registerMethod('deleteArchive');
        $this->registerMethod('createArchive');
        $this->registerMethod('archiveCommand');
        $this->registerMethod('enumerateArchives');
        $this->registerMethod('exportArchive');
        $this->registerMethod('extractArchive');
        $this->registerMethod('getLog');
        $this->registerMethod('getArchiveLog');

        $this->registerMethod('getEnvVarList');
        $this->registerMethod('getEnvVar');
        $this->registerMethod('setEnvVar');
        $this->registerMethod('deleteEnvVar');

        $this->registerMethod('getCompactList');
        $this->registerMethod('getCompact');
        $this->registerMethod('setCompact');
        $this->registerMethod('deleteCompact');
        $this->registerMethod('runCompact');

        $this->registerMethod('getServeList');
        $this->registerMethod('getServe');
        $this->registerMethod('setServe');
        $this->registerMethod('deleteServe');
        $this->registerMethod('generateServeKey');
        $this->registerMethod('downloadServeKey');
    }

    public function enumerateRepoCandidates($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Get configuration data.
        $db = \OMV\Config\Database::getInstance();
        $repos = $db->getAssoc('conf.service.borgbackup.repo');
        if ($params['creation'] == true) {
            $repos[] = [
                'name' => 'Repo creation',
                'uuid' => 'creation'
            ];
        }
        return $repos;
    }

    public function getRepoList($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.common.getlist');
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $objects = $db->get('conf.service.borgbackup.repo');
        $archives = $db->get('conf.service.borgbackup.archive');
        // Add additional share informations.
        $objectsAssoc = [];
        foreach ($objects as $objectk => &$objectv) {
            // Add the new property 'sharedfoldername'.
            $objectv->add('sharedfoldername', 'string', gettext("n/a"));
            if ($objectv->get('type') == 'local') {
                // Get the shared folder configuration object.
                $sfObject = $db->get('conf.system.sharedfolder',
                    $objectv->get('sharedfolderref'));
                // Update the 'sharedfoldername' property.
                $objectv->set('sharedfoldername', $sfObject->get('name'));
                $objectv->set('uri', gettext("n/a"));
            }
            // Add the new property 'mounted'.
            $objectv->add('mounted', 'boolean',
                $this->findRepoMount($objectv->get('name')) !== '');
            $archiveCount = 0;
            foreach ($archives as $archivek => $archivev) {
                if ($archivev->get('reporef') == $objectv->get('uuid')) {
                    $archiveCount++;
                }
            }
            $objectv->add('archiveCount', 'integer', $archiveCount);
            $objectsAssoc[] = $objectv->getAssoc();
        }
        // Filter the result.
        return $this->applyFilter($objectsAssoc, $params['start'], $params['limit'],
            $params['sortfield'], $params['sortdir']);
    }

    public function getRepo($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.common.objectuuid');
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        return $db->getAssoc('conf.service.borgbackup.repo', $params['uuid']);
    }

    public function setRepo($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.borgbackup.setrepo');
        // Prepare the configuration object.
        $object = new \OMV\Config\ConfigObject('conf.service.borgbackup.repo');
        // Remove spaces from name
        $params['name'] = str_replace(' ', '_', $params['name']);
        $params['storquota'] = trim($params['storquota']);
        // Clear uri if type is local
        if ($params['type'] == 'local') {
            $params['uri'] = '';
        } else {
            $params['uri'] = trim($params['uri']);
            $this->assertValidRemoteUri($params['uri']);
        }
        $object->setAssoc($params);
        // Check if new repo
        $isNew = $object->isNew();
        $db = \OMV\Config\Database::getInstance();
        if (TRUE === $isNew) {
            // Check uniqueness - name, Shared folder or uri
            $db->assertIsUnique($object, 'name');
            if ($params['type'] == 'local') {
                $db->assertIsUnique($object, 'sharedfolderref');
            } else {
                $db->assertIsUnique($object, 'uri');
            }
        }
        // initialize repo
        $cmdArgs = [];
        $cmdArgs[] = $this->getProgram;
        if ($params['skipinit'] == true) {
            $cmdArgs[] = 'list';
            $cmdArgs[] = '--consider-checkpoints';
            $cmdArgs[] = '--short';
        } else {
            $cmdArgs[] = 'init';
            if ($params['encryption'] == true) {
                $cmdArgs[] = '--encryption=keyfile';
            } else {
                $cmdArgs[] = '--encryption=none';
            }
            if ($params['storquota'] !== '') {
                $cmdArgs[] = sprintf('--storage-quota %s', $params['storquota']);
            }
        }
        if ($params['type'] == 'local') {
            $path = \OMV\Rpc\Rpc::call('ShareMgmt', 'getPath', [
                'uuid' => $params['sharedfolderref']
            ], $context);
        } else {
            $path = $params['uri'];
        }
        $cmdArgs[] = escapeshellarg($path);
        $cmd = new \OMV\System\Process($cmdArgs);
        $cmd->setEnv("BORG_PASSPHRASE", escapeshellarg($params['passphrase']), TRUE);
        $cmd->setEnv("BORG_UNKNOWN_UNENCRYPTED_REPO_ACCESS_IS_OK", "yes");
        $cmd->setEnv("BORG_EXIT_CODES", "modern");
        if ($params['skipinit'] == true) {
            $cmd->setEnv("BORG_RELOCATED_REPO_ACCESS_IS_OK", "yes");
        }
        if (!$isNew) {
            $cmd->setEnvFromFile($this->envFile . $params['uuid']);
        }
        $cmd->setEnvFromFile($this->envFile . 'creation');
        $cmd->setRedirect2to1();
        $cmdLine = $cmd->getCommandLine();
        if (0 !== $this->exec($cmdLine, $output)) {
            throw new \OMV\ExecException($cmd, $output);
        }
        // Remove skipinit parameter
        $object->remove('skipinit');
        // Set the configuration object.
        $db->set($object);
        // Return the configuration object.
        return $object->getAssoc();
    }

    public function changeRepoPath($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        //$this->validateMethodParams($params, 'rpc.borgbackup.changerepo');
        // get database object
        $db = \OMV\Config\Database::getInstance();
        // Clear uri if type is local
        $local = false;
        if ($params['type'] == 'local') {
            $params['uri'] = '';
            $local = true;
        } else {
            $params['uri'] = trim($params['uri']);
            $this->assertValidRemoteUri($params['uri']);
        }
        // get password and encryption params
        $other = $db->get('conf.service.borgbackup.repo', $params['uuid']);
        $passphrase = $other->get('passphrase');
        $encryption = $other->get('encryption');
        $params['passphrase'] = $passphrase;
        $params['encryption'] = $encryption;
        // Prepare the configuration object.
        $repo = new \OMV\Config\ConfigObject("conf.service.borgbackup.repo");
        $repo->setAssoc($params);
        // Set the configuration object.
        // Check uniqueness - Shared folder or uri
        if ($local) {
            $db->assertIsUnique($repo, 'sharedfolderref');
        } else {
            $db->assertIsUnique($repo, 'uri');
        }
        // initialize repo
        $cmdArgs = [];
        $cmdArgs[] = $this->getProgram;
        $cmdArgs[] = 'info';
        if ($local) {
            $path = \OMV\Rpc\Rpc::call('ShareMgmt', 'getPath', [
                'uuid' => $params['sharedfolderref']
            ], $context);
        } else {
            $path = $params['uri'];
        }
        $cmdArgs[] = escapeshellarg($path);
        $cmd = new \OMV\System\Process($cmdArgs);
        $cmd->setEnv("BORG_PASSPHRASE", escapeshellarg($passphrase), TRUE);
        $cmd->setEnv("BORG_UNKNOWN_UNENCRYPTED_REPO_ACCESS_IS_OK", "yes");
        $cmd->setEnv("BORG_RELOCATED_REPO_ACCESS_IS_OK", "yes");
        $cmd->setEnv("BORG_EXIT_CODES", "modern");
        $cmd->setEnvFromFile($this->envFile . $params['uuid']);
        $cmd->setEnvFromFile($this->envFile . 'creation');
        $cmd->setRedirect2to1();
        $cmdLine = $cmd->getCommandLine();
        if (0 !== $this->exec($cmdLine, $output)) {
            throw new \OMV\ExecException($cmd, $output);
        }
        // Remove skipinit parameter
        $repo->remove('skipinit');
        // Set the configuration object.
        $db->set($repo);
        // Return the configuration object.
        return $repo->getAssoc();
    }

    public function changeQuota($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        //$this->validateMethodParams($params, 'rpc.borgbackup.changequota');
        $newquota = $params['newquota'];
        // get database object
        $db = \OMV\Config\Database::getInstance();
        // get password and encryption params
        $repo = $db->get('conf.service.borgbackup.repo', $params['uuid']);
        $passphrase = $repo->get('passphrase');
        $sfref = $repo->get('sharedfolderref');
        // change quota for the repo
        $cmdArgs = [];
        $cmdArgs[] = $this->getProgram;
        $cmdArgs[] = 'config';
        $path = \OMV\Rpc\Rpc::call('ShareMgmt', 'getPath', ['uuid' => $sfref], $context);
        $cmdArgs[] = escapeshellarg($path);
        $cmdArgs[] = sprintf('storage_quota %s', $newquota);
        $cmd = new \OMV\System\Process($cmdArgs);
        $cmd->setEnv("BORG_PASSPHRASE", escapeshellarg($passphrase), TRUE);
        $cmd->setEnv("BORG_EXIT_CODES", "modern");
        $cmd->setEnvFromFile($this->envFile . $params['uuid']);
        $cmd->setRedirect2to1();
        $cmdLine = $cmd->getCommandLine();
        if (0 !== $this->exec($cmdLine, $output)) {
            throw new \OMV\ExecException($cmd, $output);
        }
        // update database
        $repo->set('storquota', $newquota);
        // Set the configuration object.
        $db->set($repo);
        // Return the configuration object.
        return $repo->getAssoc();
    }

    public function mountRepo($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.borgbackup.mountrepo');
        // Prepare the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $repo = $db->get('conf.service.borgbackup.repo', $params['uuid']);
        // mount repo
        $cmdArgs = [];
        $cmdArgs[] = $this->getProgram;
        $cmdArgs[] = 'mount';
        $vers = '';
        if ($params['versions']) {
            $vers = ',versions';
        }
        $cmdArgs[] = sprintf('-o allow_other%s', $vers);
        // repo path
        if ($repo->get('type') == 'local') {
            $path = \OMV\Rpc\Rpc::call('ShareMgmt', 'getPath', [
                'uuid' => $repo->get('sharedfolderref')
            ], $context);
            $path = str_replace('//', '/', $path);
        } else {
            $path = $repo->get('uri');
        }
        $cmdArgs[] = escapeshellarg($path);
        // mountpoint path
        $mntpath = \OMV\Rpc\Rpc::call('ShareMgmt', 'getPath', [
            'uuid' => $params['sharedfolderref']
        ], $context);
        $mntpath = sprintf('%s/%s', $mntpath, $repo->get('name'));
        $mntpath = str_replace('//', '/', $mntpath);
        mkdir($mntpath, 0775, true);
        $cmdArgs[] = escapeshellarg($mntpath);
        // execute command
        $cmd = new \OMV\System\Process($cmdArgs);
        $cmd->setEnv("BORG_PASSPHRASE", escapeshellarg($repo->get('passphrase')), TRUE);
        $cmd->setEnv("BORG_EXIT_CODES", "modern");
        $cmd->setEnvFromFile($this->envFile . $params['uuid']);
        $cmd->setRedirect2to1();
        $cmdLine = $cmd->getCommandLine();
        if (0 !== $this->exec($cmdLine, $output)) {
            throw new \OMV\ExecException($cmd, $output);
        }
        // Return the configuration object.
        return $repo->getAssoc();
    }

    public function unmountRepo($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.common.objectuuid');
        // Prepare the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $repo = $db->get('conf.service.borgbackup.repo', $params['uuid']);
        $repoName = $repo->get('name');
        // get repo directory
        $repoDir = $this->findRepoMount($repoName);
        // unmount repo
        if ($repoDir !== '') {
            $cmdArgs = [];
            $cmdArgs[] = $this->getProgram;
            $cmdArgs[] = 'umount';
            $cmdArgs[] = escapeshellarg($repoDir);
            $cmd = new \OMV\System\Process($cmdArgs);
            $cmd->setEnv('BORG_PASSPHRASE', escapeshellarg($repo->get('passphrase')), TRUE);
            $cmd->setEnv("BORG_EXIT_CODES", "modern");
            $cmd->setEnvFromFile($this->envFile . $params['uuid']);
            $cmd->setRedirect2to1();
            $cmdLine = $cmd->getCommandLine();
            if (0 !== $this->exec($cmdLine, $output)) {
                throw new \OMV\ExecException($cmd, $output);
            }
            if (!rmdir($repoDir)) {
                throw new \OMV\ExecException(gettext("Failed to remove ") . $repoDir);
            }
        } else {
            throw new \OMV\ExecException(gettext("Failed to find ") . $repoName);
        }
    }

    /**
     * Borg treats anything that is not a URL, an scp-style [user@]host:path
     * or an absolute path as a path relative to the cwd. engined runs from /,
     * so e.g. "user@host" (missing colon) silently creates /user@host locally.
     */
    private function assertValidRemoteUri($uri): void
    {
        $uri = trim($uri);
        if ($uri === '') {
            throw new \OMV\Exception(gettext("Remote path is required."));
        }
        if (str_starts_with($uri, '/') ||
            preg_match('#^[a-z][a-z0-9+.-]*://#i', $uri) ||
            preg_match('#^(?:[^@:/]+@)?[^:/]+:#', $uri)) {
            return;
        }
        throw new \OMV\Exception(sprintf(gettext(
            "Invalid remote path '%s'. Use ssh://user@host:port/path or " .
            "user@host:path (note the colon). Without it, borg creates a " .
            "local directory instead."), $uri));
    }

    private function findRepoMount($repoName): string
    {
        // Repos are mounted at <shared folder>/<repo name>. Repo names are
        // unique, so match the mountpoint's last path component exactly.
        $lines = @file('/proc/mounts', FILE_IGNORE_NEW_LINES);
        foreach ((array)$lines as $line) {
            $item = explode(' ', $line);
            if (count($item) < 3 || $item[0] !== 'borgfs' ||
                strpos($item[2], 'fuse') !== 0) {
                continue;
            }
            // /proc/mounts escapes spaces etc. as octal, e.g. \040.
            $mntDir = preg_replace_callback('/\\\\([0-7]{3})/',
                function($m) { return chr(octdec($m[1])); }, $item[1]);
            if (basename($mntDir) === $repoName) {
                return $mntDir;
            }
        }
        return '';
    }

    public function changePassphrase($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.borgbackup.changepassphrase');
        // Prepare the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $repo = $db->get('conf.service.borgbackup.repo', $params['uuid']);
        $repo->remove('skipinit');
        // change repo passphrase
        $cmdArgs = [];
        $cmdArgs[] = $this->getProgram;
        $cmdArgs[] = 'key';
        $cmdArgs[] = 'change-passphrase';
        if ($repo->get('type') == 'local') {
            $path = \OMV\Rpc\Rpc::call('ShareMgmt', 'getPath', [
                'uuid' => $repo->get('sharedfolderref')
            ], $context);
        } else {
            $path = $repo->get('uri');
        }
        $cmdArgs[] = escapeshellarg($path);
        $cmd = new \OMV\System\Process($cmdArgs);
        $cmd->setEnv("BORG_PASSPHRASE", escapeshellarg($repo->get('passphrase')), TRUE);
        $cmd->setEnv("BORG_NEW_PASSPHRASE", escapeshellarg($params['passphrase']), TRUE);
        $cmd->setEnv("BORG_EXIT_CODES", "modern");
        $cmd->setEnvFromFile($this->envFile . $params['uuid']);
        $cmd->setRedirect2to1();
        $cmdLine = $cmd->getCommandLine();
        if (0 !== $this->exec($cmdLine, $output)) {
            throw new \OMV\ExecException($cmd, $output);
        }
        // update passphrase in database
        $repo->set('passphrase',$params['passphrase']);
        $db->set($repo);
        // Set borgbackup module to dirty
        $dispatcher = \OMV\Engine\Notify\Dispatcher::getInstance();
        $dispatcher->notify(OMV_NOTIFY_MODIFY,
            'org.openmediavault.conf.service.borgbackup');
    }

    public function downloadKey($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        $uuid = $params['uuid'];
        // Prepare the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $repo = $db->get('conf.service.borgbackup.repo', $params['uuid']);
        $cmdArgs = [];
        $cmdArgs[] = $this->getProgram;
        $cmdArgs[] = 'info';
        $cmdArgs[] = '--json';
        if ($repo->get('type') == 'local') {
            $path = \OMV\Rpc\Rpc::call('ShareMgmt', 'getPath', [
              'uuid' => $repo->get('sharedfolderref')
            ], $context);
        } else {
            $path = $repo->get('uri');
        }
        $cmdArgs[] = escapeshellarg($path);
        $cmd = new \OMV\System\Process($cmdArgs);
        $cmd->setEnv("BORG_PASSPHRASE", escapeshellarg($repo->get('passphrase')), TRUE);
        $cmd->setEnv("BORG_EXIT_CODES", "modern");
        $cmd->setEnvFromFile($this->envFile . $uuid);
        $cmd->setRedirect2to1();
        $cmdLine = $cmd->getCommandLine();
        if (0 !== ($exitStatus = $this->exec($cmd, $output, $bgOutputFilename))) {
            throw new \OMV\ExecException($cmd, $output);
        }
        $info = trim(implode(PHP_EOL, $output));
        $enc = '';
        $keyfile = '';
        if (preg_match('/\{.*\}/s', $info, $matches)) {
            $json = $matches[0];
            $key = json_decode($json);
            $enc = $key->encryption;
            $keyfile = $enc->keyfile;
        }
        if (!file_exists($keyfile)) {
            throw new \OMV\ExecException(gettext(
              "Failed to get keyfile!"
            ));
        }
        // Modify the file mode/owner to allow the WebGUI PHP backend to unlink it.
        $tmpFilePath = tempnam(sys_get_temp_dir(), 'borgkeyfile');
        copy($keyfile, $tmpFilePath);
        chmod($tmpFilePath, 0700);
        chown($tmpFilePath, \OMV\Environment::get('OMV_WEBGUI_FILE_OWNERGROUP_NAME'));
        // Return values required by generic download RPC implementation.
        return [
            'filename' => sprintf('%s.%s', basename($keyfile), 'keyfile'),
            'filepath' => $tmpFilePath,
            'unlink' => TRUE
        ];
    }

    public function deleteRepo($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.borgbackup.deleterepo');
        $deleteFiles = $params['deleteFiles'];
        $uuid = $params['uuid'];
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        // check to see if archive is using repo to be deleted
        $archives = $db->get('conf.service.borgbackup.archive');
        $found = false;
        foreach ($archives as $archive) {
            $reporef = $archive->get('reporef');
            if ($reporef == $uuid) {
                if ($deleteFiles) {
                    $found = true;
                    break;
                } else {
                    $delarchive = $db->get('conf.service.borgbackup.archive', $archive->get('uuid'));
                    $db->delete($delarchive);
                }
            }
        }
        if ($found && $deleteFiles) {
            throw new \OMV\ExecException(gettext(
              "Repo is in use. Delete archives associated with this repo first!"
            ));
        }
        $repo = $db->get('conf.service.borgbackup.repo', $uuid);
        if ($deleteFiles) {
            // delete repo files
            $cmdArgs = [];
            $cmdArgs[] = $this->getProgram;
            $cmdArgs[] = 'delete';
            if ($repo->get('type') == 'local') {
                $path = \OMV\Rpc\Rpc::call('ShareMgmt', 'getPath', [
                    'uuid' => $repo->get('sharedfolderref')
                ], $context);
                $perms = fileperms($path);
                $owner = fileowner($path);
                $group = filegroup($path);
            } else {
                $path = $repo->get('uri');
            }
            $cmdArgs[] = escapeshellarg($path);
            $cmd = new \OMV\System\Process($cmdArgs);
            $cmd->setEnv("BORG_PASSPHRASE", escapeshellarg($repo->get('passphrase')), TRUE);
            $cmd->setEnv("BORG_DELETE_I_KNOW_WHAT_I_AM_DOING", "YES");
            $cmd->setEnv("BORG_EXIT_CODES", "modern");
            $cmd->setEnvFromFile($this->envFile . $params['uuid']);
            $cmd->setQuiet(TRUE);
            $cmdLine = $cmd->getCommandLine();
            if (0 !== $this->exec($cmdLine, $output)) {
                throw new \OMV\ExecException($cmd, $output);
            }
        }
        // Remove compact schedules and env vars that reference this repo,
        // otherwise they are left orphaned and still scheduled.
        foreach (['conf.service.borgbackup.compact',
            'conf.service.borgbackup.envvar'] as $id) {
            foreach ($db->get($id) as $ref) {
                if ($ref->get('reporef') == $uuid) {
                    $db->delete($ref);
                }
            }
        }
        // Delete the configuration object.
        $db->delete($repo);
        // recreate the directory that was deleted
        if ($deleteFiles && $repo->get('type') == 'local') {
            mkdir($path, $perms);
            chown($path, $owner);
            chgrp($path, $group);
        }
        // Return the deleted configuration object.
        return $repo->getAssoc();
    }

    public function repoCommand($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.borgbackup.cmd');
        // Prepare the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $repo = $db->get('conf.service.borgbackup.repo', $params['uuid']);
        // Create the background process.
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($context, $params, $repo) {
                // mount repo
                $cmdArgs = [];
                $cmdArgs[] = $this->getProgram;
                switch ($params['command']) {
                    case 'all':
                        $cmdArgs[] = 'check';
                        break;
                    case 'archives':
                        $cmdArgs[] = 'check';
                        $cmdArgs[] = '--archives-only';
                        break;
                    case 'compact':
                        $threshold = \OMV\Environment::getInteger("OMV_BORGBACKUP_COMPACT_THRESHOLD", 10);
                        $cmdArgs[] = 'compact';
                        $cmdArgs[] = '--progress';
                        if ($threshold > 0 && $threshold < 100 && $threshold != 10) {
                            $cmdArgs[] = sprintf('--threshold %d', $threshold);
                        }
                        break;
                    case 'info':
                        $cmdArgs[] = 'info';
                        break;
                    case 'list':
                        $cmdArgs[] = 'list';
                        break;
                    case 'repo':
                        $cmdArgs[] = 'check';
                        $cmdArgs[] = '--repository-only';
                        break;
                    case 'verify':
                        $cmdArgs[] = 'check';
                        $cmdArgs[] = '--verify-data';
                        break;
                }
                if ($params['command'] != 'info') {
                    $cmdArgs[] = '--info';
                }
                if ($repo->get('type') == 'local') {
                    $path = \OMV\Rpc\Rpc::call('ShareMgmt', 'getPath', [
                        'uuid' => $repo->get('sharedfolderref')
                    ], $context);
                } else {
                    $path = $repo->get('uri');
                }
                $cmdArgs[] = escapeshellarg($path);
                $cmd = new \OMV\System\Process($cmdArgs);
                $cmd->setEnv("BORG_PASSPHRASE", escapeshellarg($repo->get('passphrase')), TRUE);
                $cmd->setEnv("BORG_EXIT_CODES", "modern");
                $cmd->setEnvFromFile($this->envFile . $params['uuid']);
                $cmd->setRedirect2to1();
                $cmdLine = $cmd->getCommandLine();
                if (0 !== ($exitStatus = $this->exec($cmd, $output, $bgOutputFilename))) {
                    throw new \OMV\ExecException($cmd, $output);
                }
                return $output;
            }
        );
    }

    public function getArchiveList($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.common.getlist');
        // Get configuration data.
        $db = \OMV\Config\Database::getInstance();
        $objects = $db->get('conf.service.borgbackup.archive');
        // Add additional share informations.
        $objectsAssoc = [];
        $labels = [
            'hourly'  => gettext("hourly"),
            'daily'   => gettext("daily"),
            'weekly'  => gettext("weekly"),
            'monthly' => gettext("monthly"),
            'yearly'  => gettext("yearly"),
        ];
        $periods = [
            'hourly'  => ['hour' => null,          'min' => 'hourlymin'],
            'daily'   => ['hour' => 'dailyhour',   'min' => 'dailymin'],
            'weekly'  => ['hour' => 'weeklyhour',  'min' => 'weeklymin'],
            'monthly' => ['hour' => 'monthlyhour', 'min' => 'monthlymin'],
            'yearly'  => ['hour' => 'yearlyhour',  'min' => 'yearlymin'],
        ];
        foreach ($objects as $objectk => &$objectv) {
            $repo = $db->get('conf.service.borgbackup.repo', $objectv->get('reporef'));
            // Add the new property - reponame
            $objectv->add('reponame', 'string', $repo->get('name'));
            $includes = str_replace([',', PHP_EOL], '<br />', $objectv->get('include'));
            // Add the new properties - includes and excludes
            $objectv->add('includes', 'string', $includes);
            $excludes = str_replace([',', PHP_EOL], '<br />', $objectv->get('exclude'));
            $objectv->add('excludes', 'string', $excludes);
            // Add the new property - crontimes
            $crontimes = [];
            foreach ($periods as $name => $fields) {
                if (!$objectv->get("{$name}enable")) {
                    continue;
                }
                if ($fields['hour']) {
                    $hour = sprintf('%02d', (int)$objectv->get($fields['hour']));
                } else {
                    $hour = '*';
                }
                $min = sprintf('%02d', (int)$objectv->get($fields['min']));
                $crontimes[] = sprintf('%s %s:%s', $labels[$name], $hour, $min);
            }
            $objectv->add('crontimes', 'string', implode('<br />', $crontimes));
            $objectsAssoc[] = $objectv->getAssoc();
        }
        // Filter the result.
        return $this->applyFilter($objectsAssoc, $params['start'], $params['limit'],
            $params['sortfield'], $params['sortdir']);
    }

    public function getArchive($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.common.objectuuid');
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $object = $db->get('conf.service.borgbackup.archive', $params['uuid']);
        $includes = str_replace(',', PHP_EOL, $object->get("include"));
        $object->set("include", $includes);
        $excludes = str_replace(',', PHP_EOL, $object->get("exclude"));
        $object->set("exclude", $excludes);
        return $object->getAssoc();
    }

    public function setArchive($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.borgbackup.setarchive');
        // Prepare the configuration object.
        $object = new \OMV\Config\ConfigObject('conf.service.borgbackup.archive');
        // Map periods in order of most frequent → least frequent
        $periods = ['hourly', 'daily', 'weekly', 'monthly', 'yearly'];
        // A period with a retain count of 0 can't be enabled, regardless of
        // what was submitted (e.g. a stale default like dailyenable=true).
        foreach ($periods as $period) {
            if ((int)($params[$period] ?? 0) === 0) {
                $params["{$period}enable"] = false;
            }
        }
        // Determine if any enable flag is already true
        $anyEnabled = false;
        foreach ($periods as $period) {
            if (!empty($params["{$period}enable"])) {
                $anyEnabled = true;
                break;
            }
        }
        // If none enabled, enable most frequent period with value > 0
        if (!$anyEnabled) {
            foreach ($periods as $period) {
                $value = (int)($params[$period] ?? 0);
                if ($value > 0) {
                    $params["{$period}enable"] = true;
                    break;
                }
            }
        }
        // Remove spaces from name
        $params['name'] = str_replace(' ', '_', $params['name']);
        // format includes and excludes
        $params['include'] = $this->cleanArray($params['include']);
        $params['exclude'] = $this->cleanArray($params['exclude']);
        $object->setAssoc($params);
        // Set the configuration object.
        $isNew = $object->isNew();
        $db = \OMV\Config\Database::getInstance();
        if (TRUE === $isNew) {
            // Check uniqueness - Shared folder
            $db->assertIsUnique($object, 'name');
        }
        $db->set($object);
        // Return the configuration object.
        return $object->getAssoc();
    }

    private function archiveGlob($name): string
    {
        // Archives are named <name>-<date>..., so anchor on the date to
        // avoid matching archives of other configs sharing the prefix
        // (e.g. 'home' vs 'homeassistant' or 'home-old').
        return $name . '-[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]*';
    }

    private function printableCmd(\OMV\System\Process $cmd): string
    {
        // Command line with secrets (e.g. BORG_PASSPHRASE) masked, for
        // output that is shown in the GUI or written to log files.
        $copy = clone $cmd;
        $copy->obfuscateEnvs();
        return $copy->getCommandLine();
    }

    private function cleanArray($csvList): string
    {
        $list = str_replace(',', PHP_EOL, $csvList);
        $list = explode(PHP_EOL, $list);
        $list = array_map('trim', $list);
        $list = array_filter($list, 'strlen');
        $list = array_unique($list);
        return (implode(',', $list));
    }

    public function createArchive($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.borgbackup.createarchive');
        $db = \OMV\Config\Database::getInstance();
        // Get archive configuration object
        $archive = $db->get('conf.service.borgbackup.archive', $params['uuid']);
        // Get repo configuration object
        $repo = $db->get('conf.service.borgbackup.repo', $archive->get('reporef'));
        $dryrun = $params['dryrun'];
        $progress = $params['progress'];
        // Create the background process.
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($archive, $context, $repo, $dryrun, $progress) {
                // prescript
                $prescript = $archive->get('prescript');
                if (strlen($prescript) > 1) {
                    $cmd = new \OMV\System\Process($prescript);
                    $cmd->setEnvFromFile($this->envFile . $archive->get('reporef'));
                    $cmd->setRedirect2to1();
                    $cmdLine = $cmd->getCommandLine();
                    $this->exec($cmdLine, $output, $bgOutputFilename);
                }
                // borg command
                $cmdArgs = [];
                $basedir = $archive->get('basedir');
                if (strlen($basedir) > 0) {
                    if (!is_dir($basedir)) {
                        throw new \OMV\ValueException(
                            sprintf('%s: %s', gettext("Directory not found"), $basedir)
                        );
                    }
                    $cmdArgs[] = sprintf('cd %s && ', escapeshellarg($basedir));
                }
                $cmdArgs[] = $this->getProgram;
                $cmdArgs[] = 'create';
                if ($dryrun) {
                    $cmdArgs[] = '--dry-run';
                }
                if ($archive->get('list') == true) {
                    $cmdArgs[] = '--list';
                }
                if (!$dryrun) {
                    $cmdArgs[] = '--stats';
                }
                $cmdArgs[] = '--verbose';
                if ($progress) {
                    $cmdArgs[] = '--progress';
                }
                $ct = $archive->get('compressiontype');
                if ($ct == 'none') {
                    $comp = $ct;
                } else {
                    $cr = $archive->get('compressionratio');
                    $comp = sprintf('auto,%s,%s', $ct, $cr);
                }
                $cmdArgs[] = sprintf('--compression %s', $comp);
                if ($repo->get('type') == 'local') {
                    $path = \OMV\Rpc\Rpc::call('ShareMgmt', 'getPath', [
                        'uuid' => $repo->get('sharedfolderref')
                    ], $context);
                } else {
                    if ($archive->get('ratelimit') > 0) {
                        $cmdArgs[] = '--upload-ratelimit ' . $archive->get('ratelimit');
                    }
                    $path = $repo->get('uri');
                }
                $envFilePath = $this->envFile . $archive->get('reporef');
                if (file_exists($envFilePath)) {
                    $envContents = file_get_contents($envFilePath);
                    if (preg_match("/^BORG_EXTRA_CREATE_ARGS='(.*)'\\s*$/m", $envContents, $matches)) {
                        // Value is single-quoted with ' written as '\''.
                        $extra = str_replace("'\\''", "'", $matches[1]);
                        // Split on whitespace like the unquoted expansion
                        // in the scheduled script does.
                        foreach (preg_split('/\s+/', trim($extra)) as $arg) {
                            if ($arg !== '') {
                                $cmdArgs[] = escapeshellarg($arg);
                            }
                        }
                    }
                }
                $cmdArgs[] = sprintf('"%s::%s-{now:%%Y-%%m-%%d_%%H-%%M-%%S}"', $path, $archive->get('name'));
                $includes = explode(',', $archive->get('include'));
                foreach ($includes as $dirs) {
                    $cmdArgs[] = escapeshellarg($dirs);
                }
                $excludes = explode(',', $archive->get('exclude'));
                foreach ($excludes as $dirs) {
                    $cmdArgs[] = sprintf('--exclude %s', escapeshellarg($dirs));
                }
                if ($archive->get('onefs') == true) {
                    $cmdArgs[] = '--one-file-system';
                }
                $cmd = new \OMV\System\Process($cmdArgs);
                $cmd->setEnv("BORG_PASSPHRASE", escapeshellarg($repo->get('passphrase')), TRUE);
                $cmd->setEnv("BORG_EXIT_CODES", "modern");
                $cmd->setEnvFromFile($this->envFile . $archive->get('reporef'));
                $cmd->setRedirect2to1();
                $cmdLine = $cmd->getCommandLine();
                // Wrap in a bash pipeline to cap output at 128MB, protecting tmpfs (/tmp).
                // head -c consumes the first 128MB; the trailing cat drains the rest so
                // borg never receives SIGPIPE. set -o pipefail propagates borg's exit code.
                $cmdLine = sprintf('bash -c %s',
                    escapeshellarg(sprintf(
                        'set -o pipefail; %s | { head -c 134217728; cat >/dev/null; }',
                        $cmdLine
                    )));
                $this->writeBgProcOutput($bgOutputFilename, sprintf('Command: %s', $this->printableCmd($cmd)));
                $this->writeBgProcOutput($bgOutputFilename, PHP_EOL.PHP_EOL);
                if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                    throw new \OMV\ExecException($cmd, $output);
                }
                // If borg stats are not present at the end of the output (e.g. because
                // the output was truncated at 128MB), append borg info --last 1 so the
                // final stats are always visible. Check the last 4KB for 'This archive:'
                // which is a reliable marker in borg create --stats output.
                if (!$dryrun) {
                    clearstatcache(true, $bgOutputFilename);
                    $fsize = filesize($bgOutputFilename);
                    $checkLen = min($fsize, 4096);
                    $statsFound = false;
                    if ($checkLen > 0) {
                        $fp = fopen($bgOutputFilename, 'r');
                        fseek($fp, -$checkLen, SEEK_END);
                        $tail = fread($fp, $checkLen);
                        fclose($fp);
                        $statsFound = strpos($tail, 'This archive:') !== false;
                    }
                    if (!$statsFound) {
                        $infoArgs = [];
                        $infoArgs[] = $this->getProgram;
                        $infoArgs[] = 'info';
                        $infoArgs[] = '--last 1';
                        $infoArgs[] = sprintf('"%s"', $path);
                        $infoCmd = new \OMV\System\Process($infoArgs);
                        $infoCmd->setEnv("BORG_PASSPHRASE", escapeshellarg($repo->get('passphrase')), TRUE);
                        $infoCmd->setEnv("BORG_EXIT_CODES", "modern");
                        $infoCmd->setEnvFromFile($this->envFile . $archive->get('reporef'));
                        $infoCmd->setRedirect2to1();
                        $this->writeBgProcOutput($bgOutputFilename, PHP_EOL . PHP_EOL .
                            '[Stats not found in output; appending borg info --last 1:]' . PHP_EOL);
                        $this->exec($infoCmd->getCommandLine(), $infoOutput, $bgOutputFilename);
                    }
                }
                // post script
                $postscript = $archive->get('postscript');
                if (strlen($postscript) > 1) {
                    $cmd = new \OMV\System\Process($postscript);
                    $cmd->setEnvFromFile($this->envFile . $archive->get('reporef'));
                    $cmd->setRedirect2to1();
                    $cmdLine = $cmd->getCommandLine();
                    $this->writeBgProcOutput($bgOutputFilename, PHP_EOL.PHP_EOL);
                    $this->exec($cmdLine, $output, $bgOutputFilename);
                }
                // Append this run's output to the persistent archive log
                $logFile = sprintf("/var/log/borgbackup/%s.log", $archive->get('name'));
                $content = file_get_contents($bgOutputFilename);
                if ($content !== false) {
                    file_put_contents($logFile, $content, FILE_APPEND);
                }
                // return
                return $output;
            }
        );
    }

    public function deleteArchive($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.common.objectuuid');
        $db = \OMV\Config\Database::getInstance();
        // Get archive configuration object
        $archive = $db->get('conf.service.borgbackup.archive', $params['uuid']);
        // Get repo configuration object
        $repo = $db->get('conf.service.borgbackup.repo', $archive->get('reporef'));
        // delete archive
        $cmdArgs = [];
        $cmdArgs[] = $this->getProgram;
        $cmdArgs[] = 'delete';
        $cmdArgs[] = sprintf('--glob-archives %s',
            escapeshellarg($this->archiveGlob($archive->get('name'))));
        if ($repo->get('type') == 'local') {
            $path = \OMV\Rpc\Rpc::call('ShareMgmt', 'getPath', [
                'uuid' => $repo->get('sharedfolderref')
            ], $context);
        } else {
            $path = $repo->get('uri');
        }
        $cmdArgs[] = escapeshellarg($path);
        $cmd = new \OMV\System\Process($cmdArgs);
        $cmd->setEnv("BORG_PASSPHRASE", escapeshellarg($repo->get('passphrase')), TRUE);
        $cmd->setEnv("BORG_EXIT_CODES", "modern");
        $cmd->setEnvFromFile($this->envFile . $archive->get('reporef'));
        $cmd->setQuiet(TRUE);
        $cmdLine = $cmd->getCommandLine();
        if (0 !== $this->exec($cmdLine, $output)) {
            throw new \OMV\ExecException($cmd, $output);
        }
        // Delete the configuration object.
        $db->delete($archive);
        // Return the deleted configuration object.
        return $archive->getAssoc();
    }

    public function archiveCommand($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.borgbackup.cmd');
        $db = \OMV\Config\Database::getInstance();
        // Get archive configuration object
        $archive = $db->get('conf.service.borgbackup.archive', $params['uuid']);
        // Get repo configuration object
        $repo = $db->get('conf.service.borgbackup.repo', $archive->get('reporef'));
        // Create the background process.
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($archive, $context, $params, $repo) {
                $cmdArgs = [];
                $cmdArgs[] = $this->getProgram;
                switch ($params['command']) {
                    case 'info':
                        $cmdArgs[] = 'info';
                        break;
                    case 'list':
                        $cmdArgs[] = 'list';
                        break;
                }
                if ($params['command'] != 'info') {
                    $cmdArgs[] = '--info';
                }
                if ($repo->get('type') == 'local') {
                    $path = \OMV\Rpc\Rpc::call('ShareMgmt', 'getPath', [
                        'uuid' => $repo->get('sharedfolderref')
                    ], $context);
                } else {
                    $path = $repo->get('uri');
                }
                if ($params['command'] == 'info') {
                    $cmdArgs[] = sprintf('"%s"', $path);
                    $cmdArgs[] = sprintf('--glob-archives %s',
                        escapeshellarg($this->archiveGlob($archive->get('name'))));
                } else {
                    $cmdArgs[] = sprintf('"%s::%s"', $path, $archive->get('name'));
                }
                $cmd = new \OMV\System\Process($cmdArgs);
                $cmd->setEnv("BORG_PASSPHRASE", escapeshellarg($repo->get('passphrase')), TRUE);
                $cmd->setEnv("BORG_EXIT_CODES", "modern");
                $cmd->setEnvFromFile($this->envFile . $archive->get('reporef'));
                $cmd->setRedirect2to1();
                $cmdLine = $cmd->getCommandLine();
                $this->writeBgProcOutput($bgOutputFilename, sprintf('Command: %s', $this->printableCmd($cmd)));
                $this->writeBgProcOutput($bgOutputFilename, PHP_EOL.PHP_EOL);
                if (0 !== ($exitStatus = $this->exec($cmd, $output, $bgOutputFilename))) {
                    throw new \OMV\ExecException($cmd, $output);
                }
                return $output;
            }
        );
    }

    public function enumerateArchives($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.common.objectuuid');
        $db = \OMV\Config\Database::getInstance();
        // Get archive configuration object
        $repo = $db->get('conf.service.borgbackup.repo', $params['uuid']);
        // get a list of archives in selected repo
        $cmdArgs = [];
        $cmdArgs[] = $this->getProgram;
        $cmdArgs[] = 'list';
        $cmdArgs[] = '--short';
        if ($repo->get('type') == 'local') {
            $path = \OMV\Rpc\Rpc::call('ShareMgmt', 'getPath', [
                'uuid' => $repo->get('sharedfolderref')
            ], $context);
        } else {
            $path = $repo->get('uri');
        }
        $cmdArgs[] = escapeshellarg($path);
        $cmd = new \OMV\System\Process($cmdArgs);
        $cmd->setEnv("BORG_PASSPHRASE", escapeshellarg($repo->get('passphrase')), TRUE);
        $cmd->setEnv("BORG_EXIT_CODES", "modern");
        $cmd->setEnvFromFile($this->envFile . $repo->get('uuid'));
        $cmdLine = $cmd->getCommandLine();
        if (0 !== $this->exec($cmdLine, $output)) {
            throw new \OMV\ExecException($cmd, $output);
        }
        $archives = [];
        foreach ($output as $archive) {
            $archives[] = [
                'name' => $archive,
            ];
        }
        // Return the object.
        return $archives;
    }

    public function exportArchive($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.borgbackup.export');
        $db = \OMV\Config\Database::getInstance();
        // Get repo configuration object
        $repo = $db->get('conf.service.borgbackup.repo', $params['uuid']);
        // Create the background process so the output can be streamed to the
        // task dialog while it runs.
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($context, $params, $repo) {
                $logFile = sprintf("/tmp/omv-borg-export-%s.log", $params['uuid']);
                $cmdArgs = [];
                $cmdArgs[] = $this->getProgram;
                $cmdArgs[] = 'export-tar';
                $cmdArgs[] = '--progress';
                if ($repo->get('type') == 'local') {
                    $path = \OMV\Rpc\Rpc::call('ShareMgmt', 'getPath', [
                        'uuid' => $repo->get('sharedfolderref')
                    ], $context);
                } else {
                    $path = $repo->get('uri');
                }
                $sfpath = \OMV\Rpc\Rpc::call('ShareMgmt', 'getPath', [
                    'uuid' => $params['sharedfolderref']
                ], $context);
                $cmdArgs[] = sprintf('"%s::%s"', $path, $params['archive']);
                $filename = str_replace(' ', '_', $params['archive']);
                $cmdArgs[] = sprintf('"%s/%s.tar.gz"', $sfpath, $filename);
                $cmd = new \OMV\System\Process($cmdArgs);
                $cmd->setEnv("BORG_PASSPHRASE", escapeshellarg($repo->get('passphrase')), TRUE);
                $cmd->setEnv("BORG_EXIT_CODES", "modern");
                $cmd->setEnvFromFile($this->envFile . $repo->get('uuid'));
                $cmd->setRedirect2to1();
                $cmdLine = $cmd->getCommandLine();
                $exitStatus = $this->exec($cmdLine, $output, $bgOutputFilename);
                // Persist the captured output so the existing log viewers keep
                // working. This is done outside the pipeline so the real borg
                // exit code is preserved.
                file_put_contents($logFile, implode(PHP_EOL, (array) $output));
                if (0 !== $exitStatus) {
                    throw new \OMV\ExecException($cmd, $output);
                }
                return $output;
            }
        );
    }

    public function extractArchive($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.borgbackup.extract');
        $db = \OMV\Config\Database::getInstance();
        // Get repo configuration object
        $repo = $db->get('conf.service.borgbackup.repo', $params['uuid']);
        // The checkbox value arrives as a string via the task dialog
        // template, so convert it to a real boolean.
        $original = filter_var($params['original'], FILTER_VALIDATE_BOOLEAN);
        // Never fall back to extracting into / unless explicitly requested.
        if (!$original && !is_uuid($params['sharedfolderref'])) {
            throw new \OMV\Exception(gettext(
                "Select a shared folder or choose the original location."
            ));
        }
        // Create the background process so the output can be streamed to the
        // task dialog while it runs.
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($context, $params, $repo, $original) {
                $logFile = sprintf("/tmp/omv-borg-extract-%s.log", $params['uuid']);
                $cmdArgs = [];
                if (!$original) {
                    $sfpath = \OMV\Rpc\Rpc::call('ShareMgmt', 'getPath', [
                        'uuid' => $params['sharedfolderref']
                    ], $context);
                } else {
                    $sfpath = '/';
                }
                $cmdArgs[] = sprintf('cd %s &&', escapeshellarg($sfpath));
                $cmdArgs[] = $this->getProgram;
                $cmdArgs[] = 'extract';
                $cmdArgs[] = '--progress';
                if ($repo->get('type') == 'local') {
                    $path = \OMV\Rpc\Rpc::call('ShareMgmt', 'getPath', [
                        'uuid' => $repo->get('sharedfolderref')
                    ], $context);
                } else {
                    $path = $repo->get('uri');
                }
                $cmdArgs[] = sprintf('"%s::%s"', $path, $params['archive']);
                $cmd = new \OMV\System\Process($cmdArgs);
                $cmd->setEnv("BORG_PASSPHRASE", escapeshellarg($repo->get('passphrase')), TRUE);
                $cmd->setEnv("BORG_EXIT_CODES", "modern");
                $cmd->setEnvFromFile($this->envFile . $repo->get('uuid'));
                $cmd->setRedirect2to1();
                $cmdLine = $cmd->getCommandLine();
                $exitStatus = $this->exec($cmdLine, $output, $bgOutputFilename);
                // Persist the captured output so the existing log viewers keep
                // working. This is done outside the pipeline so the real borg
                // exit code is preserved.
                file_put_contents($logFile, implode(PHP_EOL, (array) $output));
                if (0 !== $exitStatus) {
                    throw new \OMV\ExecException($cmd, $output);
                }
                return $output;
            }
        );
    }

    public function getLog($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.borgbackup.getlog');
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($params) {
                $logFile = sprintf("/tmp/omv-borg-%s-%s.log", $params['command'], $params['uuid']);
                $cmdArgs = [];
                $cmdArgs[] = 'tail';
                $cmdArgs[] = '-n +1';
                if ($params['follow']) {
                    $cmdArgs[] = '-f';
                }
                $cmdArgs[] = escapeshellarg($logFile);
                $cmd = new \OMV\System\Process($cmdArgs);
                $cmd->setQuiet(true);
                $cmdLine = $cmd->getCommandLine();
                if (file_exists($logFile)) {
                    $exitStatus = $this->exec($cmdLine, $output, $bgOutputFilename);
                }
                return $output;
            }
        );
    }

    public function getArchiveLog($params, $context)
    {
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        $this->validateMethodParams($params, 'rpc.borgbackup.getarchivelog');
        $logFile = sprintf("/var/log/borgbackup/%s.log", $params['name']);
        if (!file_exists($logFile)) {
            return sprintf("No log file found for archive '%s'.", $params['name']);
        }
        return file_get_contents($logFile);
    }

    public function getEnvVarList($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.common.getlist');
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $objects = $db->get('conf.service.borgbackup.envvar');
        // Add additional environment variable informations.
        $objectsAssoc = [];
        foreach ($objects as $objectk => &$objectv) {
            // Add the new property 'sharedfoldername'.
            $objectv->add('reponame', 'string', gettext("n/a"));
            // Get the shared folder configuration object.
            if ($objectv->get('reporef') == 'creation') {
                $objectv->set('reponame', 'Repo creation');
            } else {
                try {
                    $repoObject = $db->get('conf.service.borgbackup.repo', $objectv->get('reporef'));
                    // Update the 'reponame' property.
                    $objectv->set('reponame', $repoObject->get('name'));
                } catch (Exception $e) {
                }
            }
            $objectsAssoc[] = $objectv->getAssoc();
        }
        // Filter the result.
        return $this->applyFilter($objectsAssoc, $params['start'], $params['limit'],
            $params['sortfield'], $params['sortdir']);
    }

    public function getEnvVar($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.common.objectuuid');
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        return $db->getAssoc('conf.service.borgbackup.envvar', $params['uuid']);
    }

    public function setEnvVar($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.borgbackup.setenvvar');
        // Prepare the configuration object.
        $object = new \OMV\Config\ConfigObject('conf.service.borgbackup.envvar');
        // Remove spaces from name
        $params['envname'] = str_replace(' ', '_', $params['envname']);
        // The name is written unquoted into a file sourced by bash.
        if (1 !== preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $params['envname'])) {
            throw new \OMV\Exception(sprintf(
                gettext("Invalid environment variable name '%s'."),
                $params['envname']));
        }
        // Set the configuration object.
        $object->setAssoc($params);
        $db = \OMV\Config\Database::getInstance();
        $db->set($object);
        // Return the configuration object.
        return $object->getAssoc();
    }

    public function deleteEnvVar($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.common.objectuuid');
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $object = $db->get('conf.service.borgbackup.envvar', $params['uuid']);
        // Delete the configuration object.
        $db->delete($object);
        // Return the deleted configuration object.
        return $object->getAssoc();
    }

    public function getCompactList($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.common.getlist');
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $objects = $db->get('conf.service.borgbackup.compact');
        $objectsAssoc = [];
        foreach ($objects as $objectk => &$objectv) {
            $objectv->add('reponame', 'string', gettext("n/a"));
            try {
                $repoObject = $db->get('conf.service.borgbackup.repo', $objectv->get('reporef'));
                $objectv->set('reponame', $repoObject->get('name'));
            } catch (Exception $e) {
            }
            $labels = [
                'daily'   => gettext("daily"),
                'weekly'  => gettext("weekly"),
                'monthly' => gettext("monthly"),
            ];
            $periods = [
                'daily'   => ['hour' => 'dailyhour',   'min' => 'dailymin'],
                'weekly'  => ['hour' => 'weeklyhour',  'min' => 'weeklymin'],
                'monthly' => ['hour' => 'monthlyhour', 'min' => 'monthlymin'],
            ];
            $dayNames = [
                gettext("Sun"), gettext("Mon"), gettext("Tue"),
                gettext("Wed"), gettext("Thu"), gettext("Fri"), gettext("Sat"),
            ];
            $crontimes = [];
            foreach ($periods as $name => $fields) {
                if (!$objectv->get("{$name}enable")) {
                    continue;
                }
                $hour = sprintf('%02d', (int)$objectv->get($fields['hour']));
                $min  = sprintf('%02d', (int)$objectv->get($fields['min']));
                if ($name === 'weekly') {
                    $day = $dayNames[(int)$objectv->get('weeklyday')] ?? $dayNames[1];
                    $crontimes[] = sprintf('%s (%s) %s:%s', $labels[$name], $day, $hour, $min);
                } elseif ($name === 'monthly') {
                    $dom = (int)$objectv->get('monthlyday');
                    $crontimes[] = sprintf('%s (day %d) %s:%s', $labels[$name], $dom, $hour, $min);
                } else {
                    $crontimes[] = sprintf('%s %s:%s', $labels[$name], $hour, $min);
                }
            }
            $objectv->add('crontimes', 'string', implode('<br />', $crontimes));
            $objectsAssoc[] = $objectv->getAssoc();
        }
        // Filter the result.
        return $this->applyFilter($objectsAssoc, $params['start'], $params['limit'],
            $params['sortfield'], $params['sortdir']);
    }

    public function getCompact($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.common.objectuuid');
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        return $db->getAssoc('conf.service.borgbackup.compact', $params['uuid']);
    }

    public function setCompact($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.borgbackup.setcompact');
        // Prepare the configuration object.
        $object = new \OMV\Config\ConfigObject('conf.service.borgbackup.compact');
        $object->setAssoc($params);
        $db = \OMV\Config\Database::getInstance();
        $db->set($object);
        // Return the configuration object.
        return $object->getAssoc();
    }

    public function deleteCompact($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.common.objectuuid');
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $object = $db->get('conf.service.borgbackup.compact', $params['uuid']);
        // Delete the configuration object.
        $db->delete($object);
        // Return the deleted configuration object.
        return $object->getAssoc();
    }

    public function runCompact($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.common.objectuuid');
        $db = \OMV\Config\Database::getInstance();
        // Get compact configuration object.
        $compact = $db->get('conf.service.borgbackup.compact', $params['uuid']);
        // Get repo configuration object.
        $repo = $db->get('conf.service.borgbackup.repo', $compact->get('reporef'));
        // Create the background process.
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($compact, $context, $repo) {
                $cmdArgs = [];
                $cmdArgs[] = $this->getProgram;
                $cmdArgs[] = 'compact';
                $cmdArgs[] = '--verbose';
                $cmdArgs[] = sprintf('--threshold %d', $compact->get('cthreshold'));
                if ($repo->get('type') == 'local') {
                    $path = \OMV\Rpc\Rpc::call('ShareMgmt', 'getPath', [
                        'uuid' => $repo->get('sharedfolderref')
                    ], $context);
                } else {
                    $path = $repo->get('uri');
                }
                $cmdArgs[] = escapeshellarg($path);
                $cmd = new \OMV\System\Process($cmdArgs);
                $cmd->setEnv("BORG_PASSPHRASE", escapeshellarg($repo->get('passphrase')), TRUE);
                $cmd->setEnv("BORG_EXIT_CODES", "modern");
                $cmd->setEnvFromFile($this->envFile . $compact->get('reporef'));
                $cmd->setRedirect2to1();
                $this->writeBgProcOutput($bgOutputFilename, sprintf('Command: %s', $this->printableCmd($cmd)));
                $this->writeBgProcOutput($bgOutputFilename, PHP_EOL.PHP_EOL);
                if (0 !== ($exitStatus = $this->exec($cmd, $output, $bgOutputFilename))) {
                    throw new \OMV\ExecException($cmd, $output);
                }
                return $output;
            }
        );
    }

    public function getServeList($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.common.getlist');
        // Get the configuration objects.
        $db = \OMV\Config\Database::getInstance();
        $objects = $db->get('conf.service.borgbackup.serve');
        $objectsAssoc = [];
        foreach ($objects as $objectk => &$objectv) {
            // Add display-only 'sharedfoldername'.
            $objectv->add('sharedfoldername', 'string', gettext("n/a"));
            try {
                $sfObject = $db->get('conf.system.sharedfolder',
                    $objectv->get('sharedfolderref'));
                $objectv->set('sharedfoldername', $sfObject->get('name'));
            } catch (\Exception $e) {
            }
            // Flag whether a private key is stored (downloadable) without
            // ever exposing the key material itself.
            $objectv->add('haskey', 'boolean',
                strlen($objectv->get('privatekey')) > 0);
            $assoc = $objectv->getAssoc();
            unset($assoc['privatekey']);
            $objectsAssoc[] = $assoc;
        }
        // Filter the result.
        return $this->applyFilter($objectsAssoc, $params['start'], $params['limit'],
            $params['sortfield'], $params['sortdir']);
    }

    public function getServe($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.common.objectuuid');
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $object = $db->getAssoc('conf.service.borgbackup.serve', $params['uuid']);
        // Never send the stored private key back to the WebGUI.
        unset($object['privatekey']);
        return $object;
    }

    public function setServe($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.borgbackup.setserve');
        // Remove spaces from name.
        $params['name'] = str_replace(' ', '_', $params['name']);
        $params['storquota'] = trim($params['storquota']);
        // The login user must exist on the system, because the deploy writes
        // borg serve forced-command lines into that user's
        // ~/.ssh/authorized_keys file.
        if (posix_getpwnam($params['username']) === false) {
            throw new \OMV\Exception(
                sprintf(gettext("The user '%s' does not exist."),
                    $params['username'])
            );
        }
        // No public key supplied means "generate one for me": create an
        // ed25519 key pair server-side and keep the private key for download.
        // (On edit the key is always resent, so an empty value only ever
        // happens when creating a client with auto-generation.)
        if (strlen(trim($params['publickey'] ?? '')) < 1) {
            $keys = $this->generateKeyPair($params['name']);
            $params['publickey'] = $keys['publickey'];
            $params['privatekey'] = $keys['privatekey'];
        }
        $db = \OMV\Config\Database::getInstance();
        // Prepare the configuration object.
        $object = new \OMV\Config\ConfigObject('conf.service.borgbackup.serve');
        $object->setAssoc($params);
        $isNew = $object->isNew();
        // The private key is never sent back to the GUI, so an edit submits an
        // empty value. Preserve any previously generated key in that case,
        // but only while the public key is unchanged - otherwise the stored
        // private key no longer matches and must not be offered for download.
        if (!$isNew && strlen($params['privatekey'] ?? '') < 1) {
            try {
                $existing = $db->get('conf.service.borgbackup.serve',
                    $object->get('uuid'));
                if (trim($existing->get('publickey')) === trim($params['publickey'])) {
                    $object->set('privatekey', $existing->get('privatekey'));
                }
            } catch (\Exception $e) {
            }
        }
        // A public key must map to exactly one forced command, otherwise sshd
        // would match an ambiguous entry. Names are kept unique for clarity.
        $db->assertIsUnique($object, 'name');
        $db->assertIsUnique($object, 'publickey');
        // Set the configuration object.
        $db->set($object);
        // Return the configuration object without the private key.
        $result = $object->getAssoc();
        unset($result['privatekey']);
        return $result;
    }

    public function deleteServe($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.common.objectuuid');
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $object = $db->get('conf.service.borgbackup.serve', $params['uuid']);
        // Delete the configuration object.
        $db->delete($object);
        // Return the deleted configuration object.
        $assoc = $object->getAssoc();
        unset($assoc['privatekey']);
        return $assoc;
    }

    public function generateServeKey($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.borgbackup.generatekey');
        return $this->generateKeyPair($params['comment'] ?? '');
    }

    private function generateKeyPair($comment): array
    {
        // Sanitise the optional key comment.
        $comment = preg_replace('/[^A-Za-z0-9_.@-]/', '_', trim($comment));
        if ($comment === '') {
            $comment = 'borg-serve';
        }
        // Generate an ed25519 keypair in a private temporary directory.
        $dir = sprintf('%s/omv-borg-serve-%s', sys_get_temp_dir(),
            bin2hex(random_bytes(6)));
        if (!mkdir($dir, 0700)) {
            throw new \OMV\Exception(gettext(
                "Failed to create temporary directory."
            ));
        }
        $keyPath = $dir . '/id_ed25519';
        $cmdArgs = [];
        $cmdArgs[] = 'ssh-keygen';
        $cmdArgs[] = '-t ed25519';
        $cmdArgs[] = '-N ""';
        $cmdArgs[] = sprintf('-C %s', escapeshellarg($comment));
        $cmdArgs[] = sprintf('-f %s', escapeshellarg($keyPath));
        $cmd = new \OMV\System\Process($cmdArgs);
        $cmd->setRedirect2to1();
        $cmd->setQuiet(TRUE);
        try {
            if (0 !== $this->exec($cmd->getCommandLine(), $output)) {
                throw new \OMV\ExecException($cmd, $output);
            }
            $privatekey = file_get_contents($keyPath);
            $publickey = trim(file_get_contents($keyPath . '.pub'));
        } finally {
            @unlink($keyPath);
            @unlink($keyPath . '.pub');
            @rmdir($dir);
        }
        return [
            'publickey' => $publickey,
            'privatekey' => $privatekey,
        ];
    }

    public function downloadServeKey($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.common.objectuuid');
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $serve = $db->get('conf.service.borgbackup.serve', $params['uuid']);
        $privatekey = $serve->get('privatekey');
        if (strlen($privatekey) < 1) {
            throw new \OMV\Exception(gettext(
                "No private key is stored for this client. The public key was ".
                "pasted in, so the private key never left the client machine."
            ));
        }
        // Write the key to a temp file owned by the WebGUI backend so it can be
        // streamed to the browser and unlinked afterwards.
        $tmpFilePath = tempnam(sys_get_temp_dir(), 'borgservekey');
        file_put_contents($tmpFilePath, $privatekey);
        chmod($tmpFilePath, 0600);
        chown($tmpFilePath, \OMV\Environment::get('OMV_WEBGUI_FILE_OWNERGROUP_NAME'));
        return [
            'filename' => sprintf('id_ed25519_%s', $serve->get('name')),
            'filepath' => $tmpFilePath,
            'unlink' => TRUE
        ];
    }
}
