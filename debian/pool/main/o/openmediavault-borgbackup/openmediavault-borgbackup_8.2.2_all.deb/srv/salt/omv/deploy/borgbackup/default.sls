# @license   http://www.gnu.org/licenses/gpl.html GPL Version 3
# @author    OpenMediaVault Plugin Developers <plugins@omv-extras.org>
# @copyright Copyright (c) 2019-2026 openmediavault plugin developers
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

{% set config = salt['omv_conf.get']('conf.service.borgbackup') %}
{% set envVarDir = '/etc/borgbackup' %}
{% set envVarPrefix = 'borg-envvar-' %}
{% set logDir = '/var/log/borgbackup' %}
{% set scriptsDir = '/var/lib/openmediavault/borgbackup' %}
{% set scriptPrefix = 'borgbackup-' %}
{% set compactPrefix = 'borgcompact-' %}
{% set repoUuids = config.repos.repo | map(attribute='uuid') | list %}

configure_borg_log_dir:
  file.directory:
    - name: "{{ logDir }}"
    - makedirs: True
    - user: root
    - group: adm
    - mode: '0750'

configure_borg_scripts_dir:
  file.directory:
    - name: "{{ scriptsDir }}"
    - makedirs: True
    - user: root
    - group: root
    - mode: '0755'

configure_borg_envvar_dir:
  file.directory:
    - name: "{{ envVarDir }}"
    - user: root
    - group: root
    - mode: '0700'

{% for repo in config.repos.repo %}
{% set envVarFile = envVarDir ~ '/' ~ envVarPrefix ~ repo.uuid %}

configure_borg_envvar_{{ repo.uuid }}:
  file.managed:
    - name: "{{ envVarFile }}"
    - source:
      - salt://{{ tpldir }}/files/etc-borgbackup-borg_envvar.j2
    - context:
        config: {{ config | json }}
        repouuid: {{ repo.uuid }}
    - template: jinja
    - user: root
    - group: root
    - mode: '0600'

{% endfor %}

{% set envVarFile = envVarDir ~ '/' ~ envVarPrefix ~ 'creation' %}
configure_borg_envvar_creation:
  file.managed:
    - name: "{{ envVarFile }}"
    - source:
      - salt://{{ tpldir }}/files/etc-borgbackup-borg_envvar.j2
    - context:
        config: {{ config | json }}
        repouuid: "creation"
    - template: jinja
    - user: root
    - group: root
    - mode: '0600'

configure_borg_crond:
  file.managed:
    - name: "/etc/cron.d/openmediavault-borgbackup"
    - source:
      - salt://{{ tpldir }}/files/etc-cron_d-openmediavault-borgbackup.j2
    - context:
        config: {{ config | json }}
        scriptsDir: {{ scriptsDir }}
        scriptPrefix: {{ scriptPrefix }}
        compactPrefix: {{ compactPrefix }}
    - template: jinja
    - user: root
    - group: root
    - mode: '0644'

{% for archive in config.archives.archive | selectattr('enable') %}

{% set ns = namespace(type='',sharedfolderref='',uri='',passphrase='') %}

{% for repo in config.repos.repo | selectattr("uuid", "equalto", archive.reporef) %}
{% set ns.type = repo.type %}
{% set ns.sharedfolderref = repo.sharedfolderref %}
{% set ns.uri = repo.uri %}
{% set ns.passphrase = repo.passphrase %}
{% endfor %}

{% set script = scriptsDir ~ '/' ~ scriptPrefix ~ archive.uuid %}

{% set rpath = '' %}
{% if ns.type == "local" %}
{% set rpath = salt['omv_conf.get_sharedfolder_path'](ns.sharedfolderref) %}
{% else %}
{% set rpath = ns.uri %}
{% endif %}

{% set archiveLogFile = logDir ~ '/' ~ archive.name ~ '.log' %}
{% if archive.email %}
{% set email = '2>&1 | tee -a ' ~ archiveLogFile %}
{% else %}
{% set email = '>> ' ~ archiveLogFile ~ ' 2>&1' %}
{% endif %}

{% set extraEnv = envVarDir ~ '/' ~ envVarPrefix ~ archive.reporef %}

configure_borg_{{ archive.uuid }}_cron_file:
  file.managed:
    - name: '{{ script }}'
    - contents: |
        #!/bin/bash

        {{ pillar['headers']['auto_generated'] }}
        {{ pillar['headers']['warning'] }}

        # Report borg's exit code, not tee's, when output is piped to the log.
        set -o pipefail

        extra="{{ extraEnv }}"
        if [ -f "${extra}" ]; then
          set -a
          . ${extra}
          set +a
        fi

        # Setting this, so the repo does not need to be given on the commandline:
        export BORG_REPO='{{ rpath | replace("'", "'\\''") }}'

        # Setting this, so you won't be asked for your repository passphrase:
        export BORG_PASSPHRASE='{{ ns.passphrase | replace("'", "'\\''") }}'

        # Wait up to 1 hour for repository/cache lock
        export BORG_LOCK_WAIT="${BORG_LOCK_WAIT:-3600}"

        # Use modern borg exit codes
        export BORG_EXIT_CODES=modern

        # some helpers
        log() {
          local level="${1}"
          shift
          printf '[%(%Y-%m-%d %H:%M:%S%z)T] %s: %s\n' -1 "${level}" "$*"
        }
        info()  { log INFO  "$@"; }
        warn()  { log WARN  "$@"; }
        error() { log ERROR "$@"; }

        # Serialize all operations per repo to avoid lock.exclusive contention
        lock_id="$(echo -n "${BORG_REPO}" | sha256sum | awk '{print $1}')"
        lockfile="/run/lock/omv-borg-${lock_id}.lock"

        mkdir -p /run/lock
        exec 9>"${lockfile}"

        info "Waiting for repo lock (${BORG_LOCK_WAIT}s): ${lockfile}" {{ email }}
        if ! flock -w "${BORG_LOCK_WAIT}" 9; then
          error "Failed to acquire outer repo lock after ${BORG_LOCK_WAIT}s: ${BORG_REPO}" {{ email }}
          exit 99
        fi
        info "Acquired outer repo lock: ${BORG_REPO}" {{ email }}

        # error handling
        trap 'echo $( date ) Backup interrupted >&2; exit 2' INT TERM

        {%- if archive.prescript | length > 1 %}
        info "Executing pre-script" {{ email }}
        {{ archive.prescript }}
        {%- endif %}

        info "Starting backup" {{ email }}

        {%- if archive.basedir | length > 0 %}
        if [ -d "{{ archive.basedir }}" ]; then
          cd "{{ archive.basedir }}"
        else
          info "Directory not found - {{ archive.basedir }}"
          exit 127
        fi
        {%- endif %}

        borg create \
          --verbose \
          --filter AME \
        {%- if archive.list %}
          --list \
        {%- endif %}
          --stats \
          --show-rc \
        {%- if archive.onefs %}
          --one-file-system \
        {%- endif %}
        {%- if archive.compressiontype == 'none' %}
          --compression {{ archive.compressiontype }} \
        {%- else %}
          --compression auto,{{ archive.compressiontype }},{{ archive.compressionratio }} \
        {%- endif %}
        {%- if archive.ratelimit > 0 %}
          --upload-ratelimit {{ archive.ratelimit }} \
        {%- endif %}
          --exclude-caches \
        {%- if archive.exclude | length > 0 %}
        {%- set excludes = archive.exclude.split(',') | map('trim') | reject('equalto', '') %}
        {%- for exclude in excludes %}
          --exclude '{{ exclude }}' \
        {%- endfor %}
        {%- endif %}
          ${BORG_EXTRA_CREATE_ARGS} \
          ::"{{ archive.name }}-{now:%Y-%m-%d_%H-%M-%S}" \
        {%- if archive.include | length > 0 %}
        {%- set includes = archive.include.split(',') | map('trim') | reject('equalto', '') %}
        {%- for include in includes %}
          '{{ include }}' \
        {%- endfor %}
        {%- endif %}
          {{ email }}

        backup_exit=$?

        {%- if archive.postscript | length > 1 %}
        info "Executing post-script" {{ email }}
        {{ archive.postscript }}
        {%- endif %}

        info "Pruning repository" {{ email }}

        borg prune \
          --list \
          --glob-archives '{{ archive.name }}-[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]*' \
          --show-rc \
        {%- if archive.hourly > 0 %}
          --keep-hourly {{ archive.hourly }} \
        {%- endif %}
        {%- if archive.daily > 0 %}
          --keep-daily {{ archive.daily }} \
        {%- endif %}
        {%- if archive.weekly > 0 %}
          --keep-weekly {{ archive.weekly }} \
        {%- endif %}
        {%- if archive.monthly > 0 %}
          --keep-monthly {{ archive.monthly }} \
        {%- endif %}
        {%- if archive.yearly > 0 %}
          --keep-yearly {{ archive.yearly }} \
        {%- endif %}
          {{ email }}

        prune_exit=$?

        {%- if archive.compact | to_bool %}
        info "Compacting repository" {{ email }}
        borg compact --verbose --threshold {{ archive.cthreshold }} {{email}}
        compact_exit=$?
        {%- else %}
        compact_exit=0
        {%- endif %}

        status_msgs=()
        overall=ok

        borg_rc_class() {
          local rc="${1}"
          if (( rc == 0 )); then
            echo ok
          elif (( rc == 1 )); then
            echo warn
          elif (( rc >= 2 && rc <= 99 )); then
            echo err
          elif (( rc >= 100 && rc <= 127 )); then
            echo warn
          elif (( rc >= 128 )); then
            echo sig
          else
            echo err
          fi
        }

        borg_rc_label() {
          local rc="${1}"
          case "$(borg_rc_class "${rc}")" in
            ok)   echo "ok" ;;
            warn) echo "warning(${rc})" ;;
            err)  echo "error(${rc})" ;;
            sig)  echo "terminated(${rc})" ;;
          esac
        }

        add_phase_status() {
          local phase="${1}"
          local rc="${2}"
          local cls
          cls="$(borg_rc_class "${rc}")"
          case "${cls}" in
            ok)
              return 0
              ;;
            warn)
              status_msgs+=( "${phase}=$(borg_rc_label "${rc}")" )
              [[ "${overall}" == "ok" ]] && overall=warn
              ;;
            err|sig)
              status_msgs+=( "${phase}=$(borg_rc_label "${rc}")" )
              overall=err
              ;;
          esac
        }

        add_phase_status "backup" "${backup_exit}"
        add_phase_status "prune" "${prune_exit}"
        add_phase_status "compact" "${compact_exit}"

        case "${overall}" in
          ok)   global_exit=0 ;;
          warn) global_exit=1 ;;
          err)  global_exit=2 ;;
        esac

        if [[ "${overall}" == "ok" ]]; then
          info "Borg finished successfully" {{ email }}
        elif [[ "${overall}" == "warn" ]]; then
          warn "Borg finished with warnings: ${status_msgs[*]}" {{ email }}
        else
          error "Borg finished with errors: ${status_msgs[*]}" {{ email }}
        fi

        exit ${global_exit}
    - user: root
    - group: root
    - mode: '0750'
{% endfor %}


{% set keep_env = [] %}
{% for repo in config.repos.repo %}
{% do keep_env.append(envVarPrefix ~ repo.uuid) %}
{% endfor %}
{% do keep_env.append(envVarPrefix ~ 'creation') %}

purge_stale_borg_envvars:
  file.tidied:
    - name: "{{ envVarDir }}"
    - matches:
      - "{{ envVarPrefix }}.*"
    - exclude:
{%- for f in keep_env %}
      - "{{ f }}"
{%- endfor %}
    - rmdirs: False
    - rmlinks: True


{% set keep_scripts = [] %}
{% for archive in config.archives.archive | selectattr('enable') %}
{% do keep_scripts.append(scriptPrefix ~ archive.uuid) %}
{% endfor %}

purge_stale_borg_scripts:
  file.tidied:
    - name: "{{ scriptsDir }}"
    - matches:
      - "{{ scriptPrefix }}.*"
    - exclude:
{%- for f in keep_scripts %}
      - "{{ f }}"
{%- endfor %}
    - rmdirs: False
    - rmlinks: True


{% for compact in config.compacts.compactsched | selectattr('enable') | selectattr('reporef', 'in', repoUuids) %}

{% set ns2 = namespace(type='',sharedfolderref='',uri='',passphrase='',name='') %}

{% for repo in config.repos.repo | selectattr("uuid", "equalto", compact.reporef) %}
{% set ns2.type = repo.type %}
{% set ns2.sharedfolderref = repo.sharedfolderref %}
{% set ns2.uri = repo.uri %}
{% set ns2.passphrase = repo.passphrase %}
{% set ns2.name = repo.name %}
{% endfor %}

{% set compactScript = scriptsDir ~ '/' ~ compactPrefix ~ compact.uuid %}

{% set crpath = '' %}
{% if ns2.type == "local" %}
{% set crpath = salt['omv_conf.get_sharedfolder_path'](ns2.sharedfolderref) %}
{% else %}
{% set crpath = ns2.uri %}
{% endif %}

{% set compactLogFile = logDir ~ '/compact-' ~ ns2.name ~ '.log' %}
{% if compact.email %}
{% set cemail = '2>&1 | tee -a ' ~ compactLogFile %}
{% else %}
{% set cemail = '>> ' ~ compactLogFile ~ ' 2>&1' %}
{% endif %}

{% set cExtraEnv = envVarDir ~ '/' ~ envVarPrefix ~ compact.reporef %}

configure_borg_{{ compact.uuid }}_compact_file:
  file.managed:
    - name: '{{ compactScript }}'
    - contents: |
        #!/bin/bash

        {{ pillar['headers']['auto_generated'] }}
        {{ pillar['headers']['warning'] }}

        # Report borg's exit code, not tee's, when output is piped to the log.
        set -o pipefail

        extra="{{ cExtraEnv }}"
        if [ -f "${extra}" ]; then
          set -a
          . ${extra}
          set +a
        fi

        # Setting this, so the repo does not need to be given on the commandline:
        export BORG_REPO='{{ crpath | replace("'", "'\\''") }}'

        # Setting this, so you won't be asked for your repository passphrase:
        export BORG_PASSPHRASE='{{ ns2.passphrase | replace("'", "'\\''") }}'

        # Wait up to 1 hour for repository/cache lock
        export BORG_LOCK_WAIT="${BORG_LOCK_WAIT:-3600}"

        # Use modern borg exit codes
        export BORG_EXIT_CODES=modern

        # some helpers
        log() {
          local level="${1}"
          shift
          printf '[%(%Y-%m-%d %H:%M:%S%z)T] %s: %s\n' -1 "${level}" "$*"
        }
        info()  { log INFO  "$@"; }
        warn()  { log WARN  "$@"; }
        error() { log ERROR "$@"; }

        # Serialize all operations per repo to avoid lock.exclusive contention
        lock_id="$(echo -n "${BORG_REPO}" | sha256sum | awk '{print $1}')"
        lockfile="/run/lock/omv-borg-${lock_id}.lock"

        mkdir -p /run/lock
        exec 9>"${lockfile}"

        info "Waiting for repo lock (${BORG_LOCK_WAIT}s): ${lockfile}" {{ cemail }}
        if ! flock -w "${BORG_LOCK_WAIT}" 9; then
          error "Failed to acquire outer repo lock after ${BORG_LOCK_WAIT}s: ${BORG_REPO}" {{ cemail }}
          exit 99
        fi
        info "Acquired outer repo lock: ${BORG_REPO}" {{ cemail }}

        trap 'echo $( date ) Compact interrupted >&2; exit 2' INT TERM

        info "Compacting repository" {{ cemail }}
        borg compact --verbose --threshold {{ compact.cthreshold }} {{ cemail }}
        compact_exit=$?

        if (( compact_exit == 0 )); then
          info "Borg compact finished successfully" {{ cemail }}
        elif (( compact_exit == 1 )); then
          warn "Borg compact finished with warnings" {{ cemail }}
        else
          error "Borg compact finished with errors (rc=${compact_exit})" {{ cemail }}
        fi

        exit ${compact_exit}
    - user: root
    - group: root
    - mode: '0750'
{% endfor %}


{% set keep_compact = [] %}
{% for compact in config.compacts.compactsched | selectattr('enable') | selectattr('reporef', 'in', repoUuids) %}
{% do keep_compact.append(compactPrefix ~ compact.uuid) %}
{% endfor %}

purge_stale_borg_compact_scripts:
  file.tidied:
    - name: "{{ scriptsDir }}"
    - matches:
      - "{{ compactPrefix }}.*"
    - exclude:
{%- for f in keep_compact %}
      - "{{ f }}"
{%- endfor %}
    - rmdirs: False
    - rmlinks: True


# ---------------------------------------------------------------------------
# Serve clients - "borg serve" forced-command lines in each login user's
# personal ~/.ssh/authorized_keys file. We deliberately do NOT use OMV's
# managed authorized_keys (/var/lib/openmediavault/ssh/authorized_keys/%u):
# that file is rewritten without a forced command and wiped on every SSH
# apply, which would hand connecting clients an unrestricted shell. sshd also
# reads each user's ~/.ssh/authorized_keys, which OMV never touches, so we own
# a clearly marked block there instead - leaving any other keys the admin
# added intact.
# ---------------------------------------------------------------------------

{% set serveMarkerStart = '# >>> openmediavault-borgbackup serve >>>' %}
{% set serveMarkerEnd = '# <<< openmediavault-borgbackup serve <<<' %}

# Distinct login users that currently have serve clients. Driven by the serve
# entries themselves (not the OMV user list) so any real system user works.
{% set ns_serve = namespace(users=[]) %}
{% for serve in config.serves.serve %}
{% if serve.username not in ns_serve.users %}
{% do ns_serve.users.append(serve.username) %}
{% endif %}
{% endfor %}

{% for username in ns_serve.users %}
{% set uinfo = salt['user.info'](username) %}
{% if uinfo and uinfo.home %}
{% set serveEntries = config.serves.serve | selectattr('username', 'equalto', username) | list %}

borg_serve_ssh_dir_{{ username }}:
  file.directory:
    - name: "{{ uinfo.home }}/.ssh"
    - user: {{ uinfo.uid }}
    - group: {{ uinfo.gid }}
    - mode: '0700'
    - makedirs: True

borg_serve_authorized_keys_file_{{ username }}:
  file.managed:
    - name: "{{ uinfo.home }}/.ssh/authorized_keys"
    - user: {{ uinfo.uid }}
    - group: {{ uinfo.gid }}
    - mode: '0600'
    - replace: False
    - contents: ''
    - require:
      - file: borg_serve_ssh_dir_{{ username }}

borg_serve_authorized_keys_{{ username }}:
  file.blockreplace:
    - name: "{{ uinfo.home }}/.ssh/authorized_keys"
    - marker_start: "{{ serveMarkerStart }}"
    - marker_end: "{{ serveMarkerEnd }}"
    - append_if_not_found: True
    - backup: False
    - content: |
        {%- for serve in serveEntries %}
        command="borg serve{% if serve.sharedfolderref | length > 0 %} --restrict-to-path '{{ salt['omv_conf.get_sharedfolder_path'](serve.sharedfolderref) }}'{% endif %}{% if serve.appendonly | to_bool %} --append-only{% endif %}{% if serve.storquota | length > 0 %} --storage-quota {{ serve.storquota }}{% endif %}",restrict {{ serve.publickey }}
        {%- endfor %}
    - require:
      - file: borg_serve_authorized_keys_file_{{ username }}

{% endif %}
{% endfor %}

# Strip our managed block from any user that no longer has serve clients. The
# write loop above only touches users that still have clients, so deletion
# (and the "no clients at all" case) is handled here for every other user.
{% for username in salt['user.list_users']() %}
{% set uhome = salt['user.info'](username).get('home', '') %}
{% if username not in ns_serve.users and uhome.startswith('/') %}
borg_serve_authorized_keys_cleanup_{{ username }}:
  file.replace:
    - name: "{{ uhome }}/.ssh/authorized_keys"
    - pattern: '(?ms)^{{ serveMarkerStart | regex_escape }}.*?{{ serveMarkerEnd | regex_escape }}\n?'
    - repl: ''
    - backup: False
    - ignore_if_missing: True
{% endif %}
{% endfor %}
