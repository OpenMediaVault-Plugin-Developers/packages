#!/bin/sh

find /var/www/openmediavault/ -type f -name "clientqrcode*.png" -print -delete

exit 0
