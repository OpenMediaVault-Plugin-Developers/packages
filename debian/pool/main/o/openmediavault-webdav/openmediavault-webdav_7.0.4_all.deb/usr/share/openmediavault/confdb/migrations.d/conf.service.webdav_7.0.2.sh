#!/bin/sh

set -e

. /usr/share/openmediavault/scripts/helper-functions

omv_module_set_dirty webdav

exit 0

