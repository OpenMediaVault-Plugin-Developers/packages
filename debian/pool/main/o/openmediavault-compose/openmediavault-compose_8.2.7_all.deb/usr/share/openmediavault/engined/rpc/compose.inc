<?php
/**
 * Copyright (C) 2022-2026 openmediavault plugin developers
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

class OMVRpcServiceCompose extends \OMV\Rpc\ServiceAbstract
{
    private $baseUrl = "https://github.com/OpenMediaVault-Plugin-Developers/packages/raw";
    private $url = "master/compose-files";
    private $refsUrl = "refs/heads/master/compose-files";
    private $regctl = "/usr/local/bin/regctl";
    private $cacheFileFiles = '/var/cache/openmediavault/compose_cache_files';
    private $cacheFileServices = '/var/cache/openmediavault/compose_cache_services';
    private $cacheFileStats = '/var/cache/openmediavault/compose_cache_stats.json';
    private $cacheFileImages = '/var/cache/openmediavault/compose_cache_images';
    private $cacheFileNetworks = '/var/cache/openmediavault/compose_cache_networks.json';
    private $cacheFileNetworksInspect = '/var/cache/openmediavault/compose_cache_networks_inspect.json';
    private $cacheFileVolumes = '/var/cache/openmediavault/compose_cache_volumes.json';
    private $cacheFileContainers = '/var/cache/openmediavault/compose_cache_containers.json';
    private $cacheImagesExampleList = '/var/www/openmediavault/assets/composeImages';
    private $podmanSockPath = 'unix:///run/podman/podman.sock';

    public function getName()
    {
        return "Compose";
    }

    public function initialize()
    {
        $this->registerMethod("get");
        $this->registerMethod("set");
        $this->registerMethod("enableDockerRepo");
        $this->registerMethod("reinstallDocker");
        $this->registerMethod("restartDocker");
        $this->registerMethod("clearCacheFiles");

        $this->registerMethod("getFileList");
        $this->registerMethod("getFileListBg");
        $this->registerMethod("getFileListSuggest");
        $this->registerMethod("enumerateComposeNames");
        $this->registerMethod("getFile");
        $this->registerMethod("setFile");
        $this->registerMethod("deleteFile");
        $this->registerMethod("doCommand");
        $this->registerMethod("doCommandList");
        $this->registerMethod("doDownAll");
        $this->registerMethod("doGit");
        $this->registerMethod("getLog");
        $this->registerMethod("doPrune");
        $this->registerMethod("enumerateFiles");

        $this->registerMethod("getConfigList");
        $this->registerMethod("getConfig");
        $this->registerMethod("setConfig");
        $this->registerMethod("deleteConfig");

        $this->registerMethod("getGlobalEnv");
        $this->registerMethod("setGlobalEnv");

        $this->registerMethod("getDockerfileList");
        $this->registerMethod("getDockerfile");
        $this->registerMethod("setDockerfile");
        $this->registerMethod("deleteDockerfile");
        $this->registerMethod("doBuild");
        $this->registerMethod("doTag");
        $this->registerMethod("doHubPush");

        $this->registerMethod("getExampleList");
        $this->registerMethod("setExample");

        $this->registerMethod("setUrl");

        $this->registerMethod("getServicesList");
        $this->registerMethod("getServicesListBg");
        $this->registerMethod("doServiceCommand");
        $this->registerMethod("getServiceLog");

        $this->registerMethod("getContainerList");
        $this->registerMethod("getContainerListBg");
        $this->registerMethod("doContainerCommand");
        $this->registerMethod("getContainerLog");

        $this->registerMethod("enumerateContainers");
        $this->registerMethod("doAutocompose");

        $this->registerMethod("importChanges");
        $this->registerMethod("importExistingFolder");
        $this->registerMethod("importExistingOne");
        $this->registerMethod("doPreviewImportFolder");
        $this->registerMethod("doImportExistingFolder");
        $this->registerMethod("doImportExistingOne");

        $this->registerMethod("importConfig");
        $this->registerMethod("importDockerfile");
        $this->registerMethod("importPortainerStacks");
        $this->registerMethod("doImportPortainerStacks");

        $this->registerMethod("getStats");
        $this->registerMethod("getStatsBg");
        $this->registerMethod("doDockerCmd");

        $this->registerMethod("getContainers");
        $this->registerMethod("getContainersTerm");

        $this->registerMethod("getVolumes");
        $this->registerMethod("getVolumesBg");
        $this->registerMethod("doDockerVolumeCmd");
        $this->registerMethod("setVolume");
        $this->registerMethod("createBindPath");

        $this->registerMethod("getNetworks");
        $this->registerMethod("getNetworksBg");
        $this->registerMethod("doDockerNetworkCmd");
        $this->registerMethod("doNetworkConnect");
        $this->registerMethod("setNetwork");
        $this->registerMethod("enumerateNetworkList");

        $this->registerMethod("getImages");
        $this->registerMethod("getImagesBg");
        $this->registerMethod("doDockerImageCmd");

        $this->registerMethod('getRestoreList');
        $this->registerMethod('doRestore');
        $this->registerMethod('restoreGlobalEnv');
        $this->registerMethod('deleteBackup');

        $this->registerMethod('getJobList');
        $this->registerMethod('getJob');
        $this->registerMethod('setJob');
        $this->registerMethod('deleteJob');
        $this->registerMethod('doJob');

        $this->registerMethod('getRepoList');
        $this->registerMethod('repoLogin');
        $this->registerMethod('repoLogout');

        $this->registerMethod('getUsedPorts');
        $this->registerMethod('getUsedPortsBg');
        $this->registerMethod('doFindFreePorts');
    }

    private function clearCache($file)
    {
        // delete cache files
        if ($file == 'files' || $file == 'all') {
            $files = glob(sprintf('%s*.json', $this->cacheFileFiles));
            foreach ($files as $ufile) {
                if (is_file($ufile)) {
                    unlink($ufile);
                }
            }
        }
        if ($file == 'services' || $file == 'all') {
            $files = glob(sprintf('%s*.json', $this->cacheFileServices));
            foreach ($files as $ufile) {
                if (is_file($ufile)) {
                    unlink($ufile);
                }
            }
        }
        if (($file == 'stats' || $file == 'all') && file_exists($this->cacheFileStats)) {
            unlink($this->cacheFileStats);
        }
        if ($file == 'images' || $file == 'all') {
            $files = glob(sprintf('%s*.json', $this->cacheFileImages));
            foreach ($files as $ufile) {
                if (is_file($ufile)) {
                    unlink($ufile);
                }
            }
        }
        if (($file == 'networks' || $file == 'all') && file_exists($this->cacheFileNetworks)) {
            unlink($this->cacheFileNetworks);
        }
        if (($file == 'networks' || $file == 'all') && file_exists($this->cacheFileNetworksInspect)) {
            unlink($this->cacheFileNetworksInspect);
        }
        if (($file == 'volumes' || $file == 'all') && file_exists($this->cacheFileVolumes)) {
            unlink($this->cacheFileVolumes);
        }
        if (($file == 'containers' || $file == 'all') && file_exists($this->cacheFileContainers)) {
            unlink($this->cacheFileContainers);
        }
    }

    private function getComposePath($context)
    {
        // Get configuration data.
        $db = \OMV\Config\Database::getInstance();
        // Get sharedfolder path
        $sfobject = $db->get("conf.service.compose");
        $sfref = $sfobject->get("sharedfolderref");
        $sfpath = "";
        if (is_uuid($sfref)) {
            $sfpath = \OMV\Rpc\Rpc::call("ShareMgmt", "getPath", ["uuid" => $sfref], $context);
            $sfpath = rtrim($sfpath, '/');
        } else {
            throw new \OMV\Exception(gettext("Please set shared folder for file storage."));
        }
        return ($sfpath);
    }

    private function getDockerPath($context)
    {
        // Get configuration data.
        $db = \OMV\Config\Database::getInstance();
        // Get sharedfolder path
        $sfobject = $db->get("conf.service.compose");
        $sfref = $sfobject->get("datasharedfolderref");
        $sfpath = "";
        if (is_uuid($sfref)) {
            $sfpath = \OMV\Rpc\Rpc::call("ShareMgmt", "getPath", ["uuid" => $sfref], $context);
            $sfpath = rtrim($sfpath, '/');
        } else {
            $sfpath = "";
        }
        return ($sfpath);
    }

    private function getBackupPath($context)
    {
        // Get configuration data.
        $db = \OMV\Config\Database::getInstance();
        // Get sharedfolder path
        $sfobject = $db->get("conf.service.compose");
        $sfref = $sfobject->get("backupsharedfolderref");
        $sfpath = "";
        if (is_uuid($sfref)) {
            $sfpath = \OMV\Rpc\Rpc::call("ShareMgmt", "getPath", ["uuid" => $sfref], $context);
            $sfpath = rtrim($sfpath, '/');
        } else {
            throw new \OMV\Exception(gettext("Please set shared folder for backups."));
        }
        return ($sfpath);
    }

    // Probes the shared folder for capabilities required by Docker, Compose, and
    // saltstack. Uses live filesystem tests rather than a type allowlist so that
    // any incompatible mount (CIFS, exFAT, read-only NFS, etc.) is caught.
    private function assertSharedFolderCompatible($sfref, $label, $context)
    {
        if (!is_uuid($sfref)) {
            return;
        }
        $path = \OMV\Rpc\Rpc::call("ShareMgmt", "getPath", ["uuid" => $sfref], $context);
        $path = rtrim($path, '/');
        // Detect filesystem type for informative error messages.
        $cmdOutput = [];
        exec(sprintf('findmnt --noheadings --output FSTYPE --target %s 2>/dev/null',
            escapeshellarg($path)), $cmdOutput);
        $fstype = !empty($cmdOutput) ? trim($cmdOutput[0]) : gettext('unknown');
        // Test: write access. tempnam() falls back to /tmp silently when the
        // target is not writable (e.g. server-side read-only NFS), so we use
        // touch() directly to ensure the file is created in the actual folder.
        $tmpFile = $path . '/.omv_compat_' . uniqid('', true);
        if (!@touch($tmpFile)) {
            throw new \OMV\ExecException(sprintf(
                gettext("The shared folder selected for '%s' (%s filesystem) is not writable. Verify the filesystem is mounted read-write."),
                $label, $fstype
            ));
        }
        $tmpLink = $tmpFile . '_link';
        $tmpHard = $tmpFile . '_hard';
        $tmpFifo = $tmpFile . '_fifo';
        $fh = null;
        try {
            // Test: file permissions — use 0640 so a filesystem that silently
            // ignores chmod (CIFS, exFAT) produces a mismatch.
            chmod($tmpFile, 0640);
            clearstatcache(true, $tmpFile);
            if ((fileperms($tmpFile) & 0777) !== 0640) {
                throw new \OMV\ExecException(sprintf(
                    gettext("The shared folder selected for '%s' (%s filesystem) does not support Linux file permissions, which are required by this plugin."),
                    $label, $fstype
                ));
            }
            // Test: symbolic links — required by Docker and many container apps.
            if (!@symlink($tmpFile, $tmpLink)) {
                throw new \OMV\ExecException(sprintf(
                    gettext("The shared folder selected for '%s' (%s filesystem) does not support symbolic links, which are required by Docker and container applications."),
                    $label, $fstype
                ));
            }
            // Test: hard links — used by some container applications and storage backends.
            if (!@link($tmpFile, $tmpHard)) {
                throw new \OMV\ExecException(sprintf(
                    gettext("The shared folder selected for '%s' (%s filesystem) does not support hard links, which are required by some container applications."),
                    $label, $fstype
                ));
            }
            // Test: named pipes (FIFOs) — used for IPC by databases and other containers.
            if (!posix_mkfifo($tmpFifo, 0600)) {
                throw new \OMV\ExecException(sprintf(
                    gettext("The shared folder selected for '%s' (%s filesystem) does not support named pipes (FIFOs), which are required by some container applications."),
                    $label, $fstype
                ));
            }
            // Test: file locking — required by Compose and many container applications.
            $fh = fopen($tmpFile, 'r+');
            if ($fh === false || !flock($fh, LOCK_EX | LOCK_NB)) {
                throw new \OMV\ExecException(sprintf(
                    gettext("The shared folder selected for '%s' (%s filesystem) does not support file locking, which is required by Compose and many container applications."),
                    $label, $fstype
                ));
            }
            flock($fh, LOCK_UN);
            fclose($fh);
            $fh = null;
        } finally {
            if ($fh !== null) {
                flock($fh, LOCK_UN);
                fclose($fh);
            }
            @unlink($tmpLink);
            @unlink($tmpHard);
            @unlink($tmpFifo);
            @unlink($tmpFile);
        }
    }

    private function getUrlHostname($context)
    {
        // Get configuration data.
        $db = \OMV\Config\Database::getInstance();
        // Get sharedfolder path
        $settings = $db->get("conf.service.compose");
        $urlhn = $settings->get('urlHostname');
        if (strlen($urlhn) < 1) {
            // get fqdn
            $dns = $db->get('conf.system.network.dns');
            $urlhn = $dns->get('hostname');
            $dn = $dns->get('domainname');
            if (strlen($dn) > 1) {
                $urlhn = sprintf('%s.%s', $urlhn, $dn);
            }
        }
        return ($urlhn);
    }

    private function getShowCmd($context)
    {
        // Get configuration data.
        $db = \OMV\Config\Database::getInstance();
        // get showcmd setting
        $settings = $db->get("conf.service.compose");
        $showCmd = $settings->get('showcmd');
        // return showcmd value
        return (boolval($showCmd));
    }

    private function getPodman($context)
    {
        // Get configuration data.
        $db = \OMV\Config\Database::getInstance();
        // get podman setting
        $settings = $db->get("conf.service.compose");
        $podman = $settings->get('podman');
        // return podman value
        return (boolval($podman));
    }

    // Build a process that runs docker compose for a stack through
    // omv-compose-run, which adds the --file/--env-file arguments and the
    // podman environment. Each entry in $args may hold several words
    // (e.g. "up -d"); every word is shell-escaped. $noLog skips the
    // omv-compose-run log, for commands that run on every list refresh.
    private function getComposeRunProcess(string $cname, array $args,
        bool $dryRun = false, bool $noLog = false): \OMV\System\Process
    {
        $cmdArgs = ['/usr/sbin/omv-compose-run'];
        if ($dryRun) {
            $cmdArgs[] = '--dry-run';
        }
        if ($noLog) {
            $cmdArgs[] = '--no-log';
        }
        $cmdArgs[] = escapeshellarg($cname);
        foreach ($args as $arg) {
            $words = preg_split('/\s+/', trim(strval($arg)), -1, PREG_SPLIT_NO_EMPTY);
            foreach ($words as $word) {
                $cmdArgs[] = escapeshellarg($word);
            }
        }
        return new \OMV\System\Process($cmdArgs);
    }

    // The full docker compose command line omv-compose-run will execute.
    // Used for the 'show command' setting.
    private function getComposeRunCmdLine(string $cname, array $args): string
    {
        $cmd = $this->getComposeRunProcess($cname, $args, true);
        $cmd->setRedirect2to1();
        $cmd->setQuiet(true);
        $cmd->execute($output, $exitStatus);
        return implode(PHP_EOL, $output);
    }

    // Get the compose name from a compose file path sent by the UI and make
    // sure the path is a compose file in the compose shared folder.
    private function getComposeNameFromPath(string $sfpath, string $path): string
    {
        $cname = basename(dirname($path));
        if ($path !== sprintf("%s/%s/%s.yml", $sfpath, $cname, $cname)) {
            throw new \OMV\Exception(sprintf(
                gettext("Invalid compose file path '%s'."), $path));
        }
        return $cname;
    }

    // Get 'docker compose ps --all --format json' output for each compose
    // file, one JSON object per line. Uses the cache file when it is newer
    // than $cacheTime seconds; otherwise runs ps for all uncached compose
    // files in parallel and refreshes their cache files. These calls run on
    // every list refresh, so they are not logged by omv-compose-run.
    private function getComposePsOutputs(array $cnames, string $sfpath,
        string $cachePrefix, int $cacheTime): array
    {
        $outputs = [];
        $cmdLines = [];
        foreach ($cnames as $cname) {
            $cacheFile = sprintf('%s_%s.json', $cachePrefix, $cname);
            if ($cacheTime > 0 && file_exists($cacheFile) &&
              (time() - filemtime($cacheFile)) < $cacheTime) {
                $outputs[$cname] = json_decode(file_get_contents($cacheFile), true) ?? [];
                continue;
            }
            $composeFile = sprintf("%s/%s/%s.yml", $sfpath, $cname, $cname);
            if (!file_exists($composeFile)) {
                $outputs[$cname] = [];
                continue;
            }
            $cmd = $this->getComposeRunProcess($cname,
                ['ps --all --format json'], false, true);
            $cmdLines[$cname] = $cmd->getCommandLine();
        }
        foreach ($this->execParallel($cmdLines) as $cname => $output) {
            $outputs[$cname] = $output;
            if ($cacheTime > 0) {
                $cacheFile = sprintf('%s_%s.json', $cachePrefix, $cname);
                file_put_contents($cacheFile, json_encode($output));
            }
        }
        return $outputs;
    }

    // Run shell command lines in parallel, at most $maxParallel at a time.
    // Returns the non-empty stdout lines of each command, keyed like
    // $cmdLines. stderr is discarded.
    private function execParallel(array $cmdLines, int $maxParallel = 4): array
    {
        $results = [];
        $running = [];
        while (!empty($cmdLines) || !empty($running)) {
            while (!empty($cmdLines) && count($running) < $maxParallel) {
                $key = array_key_first($cmdLines);
                $cmdLine = $cmdLines[$key];
                unset($cmdLines[$key]);
                $proc = proc_open($cmdLine, [
                    0 => ['file', '/dev/null', 'r'],
                    1 => ['pipe', 'w'],
                    2 => ['file', '/dev/null', 'w']
                ], $pipes);
                if (!is_resource($proc)) {
                    $results[$key] = [];
                    continue;
                }
                stream_set_blocking($pipes[1], false);
                $running[$key] = ['proc' => $proc, 'pipe' => $pipes[1], 'out' => ''];
            }
            // wait until a running command has output or has exited
            $read = array_column($running, 'pipe');
            $write = null;
            $except = null;
            @stream_select($read, $write, $except, 1);
            foreach (array_keys($running) as $key) {
                $running[$key]['out'] .= stream_get_contents($running[$key]['pipe']);
                if (feof($running[$key]['pipe'])) {
                    fclose($running[$key]['pipe']);
                    proc_close($running[$key]['proc']);
                    $lines = array_map('rtrim', explode("\n", $running[$key]['out']));
                    $results[$key] = array_values(array_filter($lines));
                    unset($running[$key]);
                }
            }
        }
        return $results;
    }

    private function getPort($context, $publisher, $fqdn)
    {
        $port = '';
        $url = $publisher->URL;
        $tgtPort = $publisher->TargetPort;
        $pubPort = $publisher->PublishedPort;
        $protocol = $publisher->Protocol;
        if ($tgtPort > 0 && $pubPort > 0) {
            $port .= sprintf('%d->', $pubPort);
        }
        $port .= sprintf('%s/%s', $tgtPort, $protocol);
        if (strlen($url) > 0) $port .= sprintf(' [%s]', $url);
        if ($protocol == "tcp") {
            $hrefPort = 0;
            if ($pubPort > 0) {
                $hrefPort = $pubPort;
            } else {
                $hrefPort = $tgtPort;
            }
            $port = sprintf('<a href="http://%s:%d" target="_blank">%s</a>', $fqdn, $hrefPort, $port);
        }
        return ($port);
    }

    private function isOptionalContainer($cntj)
    {
        $labels = $cntj->Labels ?? null;
        if (is_object($labels)) {
            return (($labels->{'openmediavault.compose.optional'} ?? '') === 'true');
        }
        if (is_string($labels)) {
            return (strpos($labels, 'openmediavault.compose.optional=true') !== false);
        }
        return false;
    }

    private function getExecUrl($context, $db, $fqdn)
    {
        try {
            $settings = $db->get("conf.service.cterm")->getAssoc();
            $bp = trim(strval($settings["basepath"] ?? ""), "/");
            $basepath = ($bp !== "") ? "/".$bp : "";
            // reverse proxy - relative url uses current web ui host
            if (boolval($settings["enablenginx"] ?? false) && $basepath !== "") {
                return sprintf('%s/terminal', $basepath);
            }
            $port = $settings["port"];
            $webadmin = $db->get("conf.webadmin");
            $protocol = boolval($webadmin->get("enablessl")) ? "https" : "http";
            return sprintf('%s://%s:%d%s/terminal', $protocol, $fqdn, $port, $basepath);
        } catch (Exception $e) {
            // cterm not installed
            return "";
        }
    }

    private function getHeader()
    {
        $header = '# This file is auto-generated by openmediavault (https://www.openmediavault.org)';
        $header .= PHP_EOL;
        $header .= '# WARNING: Do not edit this file, your changes will get lost.';
        $header .= PHP_EOL . PHP_EOL;
        return ($header);
    }

    private function applyChanges($context)
    {
        \OMV\Rpc\Rpc::call('Config', 'applyChanges', [
          'modules' => [ 'compose' ],
          'force' => TRUE
        ], $context);
    }

    private function addAndCommit($context, $files, $msg)
    {
        $sfpath = $this->getComposePath($context);
        if (is_dir(sprintf("%s/.git", $sfpath))) {
            // git add to repo
            $cmdArgs = [];
            $cmdArgs[] = '-C';
            $cmdArgs[] = escapeshellarg($sfpath);
            $cmdArgs[] = 'add';
            $cmdArgs = array_merge($cmdArgs, array_map('escapeshellarg', $files));
            $cmd = new \OMV\System\Process('git', $cmdArgs);
            $cmd->setQuiet(true);
            $cmd->execute($output, $exitStatus);
            // git commit change
            $cmdArgs = [];
            $cmdArgs[] = '-C';
            $cmdArgs[] = escapeshellarg($sfpath);
            $cmdArgs[] = 'commit';
            $cmdArgs[] = '-m';
            $cmdArgs[] = escapeshellarg(sprintf('Added %s on %s', $msg, date('Y.m.d h:i:sa')));
            $cmd = new \OMV\System\Process('git', $cmdArgs);
            $cmd->setQuiet(true);
            $cmd->execute($output, $exitStatus);
        }
    }

    private function removeAndCommit($context, $files, $msg)
    {
        $sfpath = $this->getComposePath($context);
        if (is_dir(sprintf("%s/.git", $sfpath))) {
            // git add to repo
            $cmdArgs = [];
            $cmdArgs[] = '-C';
            $cmdArgs[] = escapeshellarg($sfpath);
            $cmdArgs[] = 'rm';
            $cmdArgs[] = '-f';
            $cmdArgs = array_merge($cmdArgs, array_map('escapeshellarg', $files));
            $cmd = new \OMV\System\Process('git', $cmdArgs);
            $cmd->setQuiet(true);
            $cmd->execute($output, $exitStatus);
            // git commit change
            $cmdArgs = [];
            $cmdArgs[] = '-C';
            $cmdArgs[] = escapeshellarg($sfpath);
            $cmdArgs[] = 'commit';
            $cmdArgs[] = '-m';
            $cmdArgs[] = escapeshellarg(sprintf('Removed %s on %s', $msg, date('Y.m.d h:i:sa')));
            $cmd = new \OMV\System\Process('git', $cmdArgs);
            $cmd->setQuiet(true);
            $cmd->execute($output, $exitStatus);
        }
    }

    private function getSharedfolderPathMap($context)
    {
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }
        $db = \OMV\Config\Database::getInstance();
        $sfConfig = $db->get("conf.system.sharedfolder");
        $map = [];
        foreach ($sfConfig as $sf) {
            $name = $sf->get('name');
            $uuid = is_array($sf) ? $sf['uuid'] : $sf->get('uuid');
            $path = \OMV\Rpc\Rpc::call("ShareMgmt", "getPath", ["uuid" => $uuid], $context);
            if ($path === null) {
                continue;
            }
            $map[$name] = rtrim($path, '/');
        }
        $cache = $map;
        return $cache;
    }

    private function resolveSfPlaceholders($body, $context)
    {
        if ($body === null || $body === '') {
            return '';
        }
        $sfmap = $this->getSharedfolderPathMap($context);
        if (empty($sfmap)) {
            return $body;
        }
        $result = $body;
        foreach ($sfmap as $name => $path) {
            $placeholder = '${{ sf:"' . $name . '" }}';
            $result = str_replace($placeholder, $path, $result);
        }
        return $result;
    }

    private function getUidMap()
    {
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }
        $map = [];
        foreach (file('/etc/passwd', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            if ($line[0] === '#') {
                continue;
            }
            [$name, , $uid] = explode(':', $line, 4);
            $map[$name] = $uid;
        }
        return $cache = $map;
    }

    private function getGidMap()
    {
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }
        $map = [];
        foreach (file('/etc/group', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            if ($line[0] === '#') {
                continue;
            }
            [$name, , $gid] = explode(':', $line, 4);
            $map[$name] = $gid;
        }
        return $cache = $map;
    }

    private function getTimezone()
    {
        $tz = @file_get_contents('/etc/timezone');
        if ($tz !== false && $tz !== '') {
            return trim($tz);
        }
        return date_default_timezone_get();
    }

    // Replace ${{ nfp: N }} placeholders in the given texts (e.g. the compose
    // body and override of one file) with the first free host port >= N.
    // Ports used by any stored compose file and literal ports in the texts
    // themselves count as used; each placeholder gets a different port.
    private function resolveNfpPlaceholders(array $texts): array
    {
        $hasPlaceholder = false;
        foreach ($texts as $text) {
            if (strpos($text, '${{ nfp:') !== false) {
                $hasPlaceholder = true;
            }
        }
        if (!$hasPlaceholder) {
            return $texts;
        }

        $nfpRegex = '/\$\{\{\s*nfp:\s*(\d+)\s*\}\}/';
        // Collect all numeric host ports from every stored compose file body
        // and from the texts being resolved. The placeholders are masked with
        // port 0 (ignored) first: an unquoted '${{ nfp: N }}' contains ': ',
        // which is not valid YAML and would hide every literal port in the text.
        $db = \OMV\Config\Database::getInstance();
        $bodies = preg_replace($nfpRegex, '0', $texts);
        foreach ($db->get("conf.service.compose.file") as $objectv) {
            $bodies[] = strval($objectv->get('body'));
            $bodies[] = strval($objectv->get('override'));
        }
        $usedPorts = [];
        foreach ($bodies as $body) {
            foreach ($this->parseComposePorts($body, '') as $port) {
                $hp = $port['host_port'];
                if (strpos($hp, '-') !== false) {
                    [$rs, $re] = explode('-', $hp, 2);
                    if (is_numeric($rs) && is_numeric($re)) {
                        for ($p = intval($rs); $p <= intval($re) && $p <= 65535; $p++) {
                            $usedPorts[$p] = true;
                        }
                    }
                } elseif (is_numeric($hp)) {
                    $usedPorts[intval($hp)] = true;
                }
            }
        }

        // Ports claimed by earlier ${{ nfp: N }} tags within this same render pass.
        $claimed = [];

        $callback = function ($matches) use (&$usedPorts, &$claimed) {
            $port = max(1, min(65535, intval($matches[1])));
            while ($port <= 65535) {
                if (!isset($usedPorts[$port]) && !isset($claimed[$port])) {
                    $claimed[$port] = true;
                    return (string)$port;
                }
                $port++;
            }
            return $matches[0]; // no free port found, leave placeholder intact
        };
        foreach ($texts as $key => $text) {
            $texts[$key] = preg_replace_callback($nfpRegex, $callback, $text);
        }
        return $texts;
    }

    private function renderBody($rawBody, $name, $datapath, $context)
    {
        if ($rawBody === null) {
            $rawBody = '';
        }
        $body = $this->resolveSfPlaceholders($rawBody, $context);
        if ($name !== '') {
            $body = str_replace('CHANGE_TO_COMPOSE_NAME', $name, $body);
        }
        if ($datapath !== null && $datapath !== '') {
            $body = str_replace('CHANGE_TO_COMPOSE_DATA_PATH', $datapath, $body);
        }
        foreach ($this->getUidMap() as $user => $uid) {
            $body = str_replace('${{ uid:"' . $user . '" }}', $uid, $body);
        }
        foreach ($this->getGidMap() as $group => $gid) {
            $body = str_replace('${{ gid:"' . $group . '" }}', $gid, $body);
        }
        $body = str_replace('${{ tz }}', $this->getTimezone(), $body);
        return $body;
    }

    private function findComposeFile($dir)
    {
        $name = basename(rtrim($dir, '/'));
        $candidates = [
            sprintf('%s/%s.yml', $dir, $name),
            sprintf('%s/compose.yml', $dir),
            sprintf('%s/compose.yaml', $dir),
            sprintf('%s/docker-compose.yml', $dir),
            sprintf('%s/docker-compose.yaml', $dir),
        ];
        foreach ($candidates as $candidate) {
            if (file_exists($candidate)) {
                return $candidate;
            }
        }
        return null;
    }

    private function scanForComposeDirs($path, $maxDepth = 4, $currentDepth = 0)
    {
        $found = [];
        if ($currentDepth > $maxDepth) {
            return $found;
        }
        $entries = array_diff(scandir($path), ['.', '..']);
        foreach ($entries as $entry) {
            $full = sprintf('%s/%s', $path, $entry);
            if (!is_dir($full)) {
                continue;
            }
            if ($this->findComposeFile($full) !== null) {
                $found[] = $full;
            } else {
                $found = array_merge($found, $this->scanForComposeDirs($full, $maxDepth, $currentDepth + 1));
            }
        }
        return $found;
    }

    private function descriptionFromReadme($dir)
    {
        foreach (['README.md', 'readme.md', 'README'] as $filename) {
            $readmePath = sprintf('%s/%s', $dir, $filename);
            if (!file_exists($readmePath)) {
                continue;
            }
            $lines = file($readmePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            if ($lines === false) {
                continue;
            }
            foreach ($lines as $line) {
                $line = trim($line);
                if ($line === '' || $line[0] === '#' || $line[0] === '=') {
                    continue;
                }
                $line = preg_replace('/[*_`\[\]()!]/', '', $line);
                $line = trim($line);
                if ($line === '') {
                    continue;
                }
                return mb_strimwidth($line, 0, 100, '...');
            }
        }
        return null;
    }


    public function get($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $object = $db->get("conf.service.compose");
        $podman = $this->getPodman($context);
        // Remove useless properties from the object.
        $object->remove("files");
        $object->remove("dockerfiles");
        $object->remove("globalenv");
        // docker/podman version
        $cmdLine = sprintf(
            'dpkg -l | awk \'$1 == "ii" && ($2 == "%s") { print $2 " " $3 }\'',
            $podman ? 'podman' : 'docker-ce'
        );
        $cmd = new \OMV\System\Process($cmdLine);
        $cmd->setQuiet(true);
        $output = [];
        $cmd->execute($output, $exitStatus);
        // compose version
        $cmdLine = 'dpkg -l | awk \'$1 == "ii" && ($2 == "docker-compose-plugin") { print $2 " " $3 }\'';
        $cmd = new \OMV\System\Process($cmdLine);
        $cmd->setQuiet(true);
        $cmd->execute($output2, $exitStatus);
        if (!empty($output)) {
            // Get docker service status
            $svc = $podman ? 'podman.socket' : 'docker';
            $systemCtl = new \OMV\System\SystemCtl($svc);
            if ($systemCtl->isActive()) {
                $running = gettext("and running");
            } else {
                $running = gettext("and not running");
            }
            $status = sprintf('%s %s', gettext("Installed"), $running);
            $dockerVersion = $output[0];
            $composeVersion = $output2[0];
        } else {
            $status = gettext("Not installed");
            $dockerVersion = gettext("n/a");
            $composeVersion = gettext("n/a");
        }
        $object->add('dockerStatus', 'string', $status);
        $object->add('dockerVersion', 'string', $dockerVersion);
        $object->add('composeVersion', 'string', $composeVersion);
        // Return the configuration object.
        return $object->getAssoc();
    }

    public function set($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.compose.set");
        // Make sure shared folder are different than other shared folders
        $checks = [[
            'sharedfolderref', 'datasharedfolderref',
            gettext("Compose file shared folder must be different than data shared folder")
        ],[
            'sharedfolderref', 'dockersharedfolderref',
            gettext("Compose file shared folder must be different than docker shared folder")
        ],[
            'datasharedfolderref', 'dockersharedfolderref',
            gettext("Data shared folder must be different than docker shared folder")
        ],[
            'backupsharedfolderref', 'dockersharedfolderref',
            gettext("Backup shared folder must be different than docker shared folder")
        ],[
            'sharedfolderref', 'podmansharedfolderref',
            gettext("Compose file shared folder must be different than podman shared folder")
        ],[
            'datasharedfolderref', 'podmansharedfolderref',
            gettext("Data shared folder must be different than podman shared folder")
        ],[
            'backupsharedfolderref', 'podmansharedfolderref',
            gettext("Backup shared folder must be different than podman shared folder")
        ]];
        foreach ($checks as [$left, $right, $message]) {
            if ($params[$left] !== '' && $params[$left] === $params[$right]) {
                throw new \OMV\ExecException($message);
            }
        }
        // Get the existing configuration object.
        $db = \OMV\Config\Database::getInstance();
        // Validate that all selected shared folders are on compatible filesystems.
        $sfCompatChecks = [
            'sharedfolderref'       => gettext("Compose file storage"),
            'datasharedfolderref'   => gettext("Data storage"),
            'backupsharedfolderref' => gettext("Backup storage"),
            'dockersharedfolderref' => gettext("Docker storage"),
            'podmansharedfolderref' => gettext("Podman storage"),
        ];
        foreach ($sfCompatChecks as $field => $label) {
            $this->assertSharedFolderCompatible($params[$field], $label, $context);
        }
        $object = $db->get("conf.service.compose");
        $perms = "";
        switch ($params['mode']) {
            case "700": $perms = "600"; break;
            case "750": $perms = "640"; break;
            case "770": $perms = "660"; break;
            case "755": $perms = "644"; break;
            case "775": $perms = "664"; break;
            case "777": $perms = "666"; break;
            default:    $perms = "600";
        }
        $params['fileperms'] = $perms;
        // override the docker storage path with the absolute path of
        // the docker sharedfolder if set
        $sfref = $params['dockersharedfolderref'];
        if (is_uuid($sfref)) {
            $sfpath = \OMV\Rpc\Rpc::call("ShareMgmt", "getPath", ["uuid" => $sfref], $context);
            $sfpath = rtrim($sfpath, '/');
            $params['dockerStorage'] = $sfpath;
        }
        $params['dockersharedfolderref'] = '';
        // override the podman storage path with the absolute path of
        // the podman sharedfolder if set
        $sfref = $params['podmansharedfolderref'];
        if (is_uuid($sfref)) {
            $sfpath = \OMV\Rpc\Rpc::call("ShareMgmt", "getPath", ["uuid" => $sfref], $context);
            $sfpath = rtrim($sfpath, '/');
            $params['podmanStorage'] = $sfpath;
        }
        $params['podmansharedfolderref'] = '';
        $object->setAssoc($params);
        $db->set($object);
        // Remove useless properties from the object.
        $object->remove("files");
        $object->remove("dockerfiles");
        // delete all cache files
        $this->clearCache('all');
        // Return the configuration object.
        return $object->getAssoc();
    }

    public function enableDockerRepo($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // enable docker repo
        $db = \OMV\Config\Database::getInstance();
        $object = $db->get('conf.system.omvextras');
        $object->set('docker', true);
        $db->set($object);
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($params) {
                // setup repos
                $cmd = new \OMV\System\Process('omv-aptclean repos');
                $cmdLine = $cmd->getCommandLine();
                if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                    throw new \OMV\ExecException($cmdLine, $output);
                }
                return $output;
            }
        );
    }

    public function reinstallDocker($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($params) {
                // remove existing docker packages
                $cmdArgs = [];
                $cmdArgs[] = 'apt-get';
                $cmdArgs[] = '--yes';
                $cmdArgs[] = '--autoremove';
                $cmdArgs[] = 'purge';
                $cmdArgs[] = 'docker-ce';
                $cmdArgs[] = 'docker.io';
                $cmdArgs[] = 'containerd.io';
                $cmdArgs[] = 'containerd';
                $cmdArgs[] = 'docker-ce-cli';
                $cmdArgs[] = 'docker-compose-plugin';
                $cmdArgs[] = 'docker-compose';
                $cmd = new \OMV\System\Process($cmdArgs);
                $cmd->setRedirect2to1();
                $cmdLine = $cmd->getCommandLine();
                if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                    throw new \OMV\ExecException($cmdLine, $output);
                }
                // run compose saltsack
                $cmdArgs = [];
                $cmdArgs[] = 'omv-salt';
                $cmdArgs[] = 'deploy';
                $cmdArgs[] = 'run';
                $cmdArgs[] = 'compose';
                $cmd = new \OMV\System\Process($cmdArgs);
                //$cmd->setRedirect2to1();
                $cmdLine = $cmd->getCommandLine();
                if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                    if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                        throw new \OMV\ExecException($cmdLine, $output);
                    }
                }
                return $output;
            }
        );
    }

    public function restartDocker($params, $context)
    {
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $object = $db->get("conf.service.compose");
        $podman = $this->getPodman($context);
        $svc = $podman ? 'podman.socket' : 'docker';
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        $systemCtl = new \OMV\System\SystemCtl($svc);
        $systemCtl->restart();
    }

    public function clearCacheFiles($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // delete all cache files
        $this->clearCache('all');
    }

    public function getFileList($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.getlist");
        // Get configuration data.
        $db = \OMV\Config\Database::getInstance();
        $objects = $db->get("conf.service.compose.file");
        $sfpath = $this->getComposePath($context);
        // get cache time
        $db = \OMV\Config\Database::getInstance();
        $settings = $db->get("conf.service.compose");
        $cacheTime = $settings->get('cachetimefiles');
        // get fqdn
        $fqdn = $this->getUrlHostname($context);
        // get ps output for all compose files (in parallel)
        $cnames = [];
        foreach ($objects as $objectv) {
            $cnames[] = $objectv->get('name');
        }
        $psOutputs = $this->getComposePsOutputs($cnames, $sfpath,
            $this->cacheFileFiles, intval($cacheTime));
        // Add additional informations.
        $objectsAssoc = [];
        foreach ($objects as $objectk => &$objectv) {
            // build filenames
            $cname = $objectv->get('name');
            $composeFile = sprintf("%s/%s/%s.yml", $sfpath, $cname, $cname);
            $output = $psOutputs[$cname] ?? [];
            // get state of each container
            $down = 0;
            $exited = 0;
            $running = 0;
            if (count($output) == 0) {
                $down++;
            } else {
                foreach ($output as $cnt) {
                    $cntj = json_decode($cnt);
                    if ($this->isOptionalContainer($cntj)) {
                        continue;
                    }
                    if ($cntj->State == "running") {
                        $running++;
                    } elseif ($cntj->State == "exited") {
                        $exited++;
                    } else {
                        $down++;
                    }
                }
            }
            $status = [];
            if ($running > 0) $status[] = "UP";
            if ($exited > 0) $status[] = "STOPPED";
            if ($down > 0) $status[] = "DOWN";
            $objectv->add('status', 'string', implode(',', $status));
            // Add other details
            $filedate = filemtime($composeFile);
            if ($filedate === false) $filedate = 0;
            $objectv->add('filedate', 'integer', $filedate);
            $objectv->add('build', 'boolean', false);
            if (stripos($objectv->get('body'), 'build:') !== false) {
                $objectv->set('build', true);
            }
            // add image names, ports, service names, uptime
            $ports = [];
            $uptime = [];
            $svcname = [];
            $imgname = [];
            foreach ($output as $cnt) {
                $cntj = json_decode($cnt);
                if ($this->isOptionalContainer($cntj)) {
                    continue;
                }
                foreach ($cntj->Publishers as $publisher) {
                    $ports[] = $this->getPort($context, $publisher, $fqdn);
                }
                $uptime[] = $cntj->Status;
                $svcname[] = $cntj->Service;
                $imgname[] = $cntj->Image;
            }
            $objectv->add('image', 'string', implode('<br/>', $imgname));
            $objectv->add('ports', 'string', implode('<br/>', $ports));
            $objectv->add('svcname', 'string', implode('<br/>', $svcname));
            $objectv->add('uptime', 'string', implode('<br/>', $uptime));
            // remove unneeded fields
            $objectv->remove('body');
            $objectv->remove('env');
            $objectv->remove('override');
            // add to list
            $objectsAssoc[] = $objectv->getAssoc();
        }
        // Filter the result.
        return $this->applyFilter($objectsAssoc, $params['start'], $params['limit'],
            $params['sortfield'], $params['sortdir'], $params['search']);
    }

    public function getFileListBg($params, $context) {
        return $this->callMethodBg("getFileList", $params, $context);
    }

    public function getFileListSuggest($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Get configuration data.
        $db = \OMV\Config\Database::getInstance();
        $objects = $db->get("conf.service.compose.file");
        // Add additional informations.
        $files = [];
        $files[] = '*';
        foreach ($objects as $objectk => &$objectv) {
            $files[] = $objectv->get('name');
        }
        // Filter the result.
        return ($files);
    }

    public function enumerateComposeNames($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Get configuration data.
        $db = \OMV\Config\Database::getInstance();
        $objects = $db->get("conf.service.compose.file");
        // Return the compose file names as objects so they can be used to
        // populate a 'select' form field. Unlike getFileListSuggest this
        // omits the '*' wildcard, which only makes sense in the text filter.
        $names = [];
        foreach ($objects as $objectk => &$objectv) {
            $names[] = ["name" => $objectv->get('name')];
        }
        return ($names);
    }

    public function getFile($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.objectuuid");
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        return $db->getAssoc("conf.service.compose.file", $params['uuid']);
    }

    private function checkFileSyntax($context, $yml1, $yml2, $env1, $cname, $datapath)
    {
        $db = \OMV\Config\Database::getInstance();
        $settings = $db->get("conf.service.compose");
        $runConfig = $settings->get('runconfig');

        if ($runConfig == false) return true;

        $sfpath = $this->getComposePath($context);
        $globalEnvFile = sprintf("%s/global.env", $sfpath);

        $tmpDir = sprintf('%s/compose_check_%s', sys_get_temp_dir(), bin2hex(random_bytes(4)));
        mkdir($tmpDir, 0700, true);

        $ymlFile1 = $tmpDir . '/test.yml';
        $ymlFile2 = $tmpDir . '/test.override.yml';
        $envFile1 = $tmpDir . '/test.env1';

        $body = $this->renderBody($yml1, $cname, $datapath, $context);
        $env = $this->renderBody($env1, $cname, $datapath, $context);
        $override = $this->renderBody($yml2, $cname, $datapath, $context);

        file_put_contents($ymlFile1, $body);
        file_put_contents($ymlFile2, $override);
        file_put_contents($envFile1, $env);

        // checks temporary files, so omv-compose-run can't be used here
        $cmdArgs = [];
        $cmdArgs[] = 'docker';
        $cmdArgs[] = 'compose';
        $cmdArgs[] = '--file ' . escapeshellarg($ymlFile1);
        $cmdArgs[] = '--file ' . escapeshellarg($ymlFile2);
        $cmdArgs[] = '--env-file ' . escapeshellarg($globalEnvFile);
        $cmdArgs[] = '--env-file ' . escapeshellarg($envFile1);
        $cmdArgs[] = 'config';
        $cmd = new \OMV\System\Process($cmdArgs);
        $podman = $this->getPodman($context);
        if ($podman) {
            $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
            $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
        }
        $cmd->setRedirect2to1();
        $cmdLine = $cmd->getCommandLine();
        $failed = false;
        $output = [];
        if (0 !== $this->exec($cmdLine, $output)) {
            $failed = true;
        }

        // Clean up temp files
        @unlink($ymlFile1);
        @unlink($ymlFile2);
        @unlink($envFile1);
        @rmdir($tmpDir);

        if ($failed) {
            throw new \OMV\Exception(implode(PHP_EOL, $output));
        }
        return true;
    }

    public function setFile($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.compose.setfile");
        // Verify that shared folder is set
        $db = \OMV\Config\Database::getInstance();
        $datapath = $this->getDockerPath($context);
        $sfpath = $this->getComposePath($context);
        // If data path string is used in file body, verify that data shared folder is set
        if (strpos($params['body'], 'CHANGE_TO_COMPOSE_DATA_PATH') !== false) {
            if ($datapath == '') {
                throw new \OMV\Exception(
                  gettext("Please set shared folder for data on the Settings tab.")
                );
            }
        }
        // Resolve ${{ nfp: N }} placeholders before storing so the assigned
        // port is locked in and does not shift on subsequent saves.
        [$params['body'], $params['override']] = $this->resolveNfpPlaceholders(
            [$params['body'], $params['override'] ?? '']);
        // Prepare the configuration object.
        $object = new \OMV\Config\ConfigObject("conf.service.compose.file");
        $object->setAssoc($params);
        // Set the configuration object.
        $isNew = $object->isNew();
        if (TRUE === $isNew) {
            // Check uniqueness - name
            $db->assertIsUnique($object, "name");
        }
        // check syntax if enabled
        $checkSyntax = $this->checkFileSyntax($context, $object->get('body'), $object->get('override'), $object->get('env'), $object->get('name'), $datapath);
        // update database
        $db->set($object);
        $cname = $object->get('name');
        // Apply changes immmediately
        if (TRUE === $isNew) {
            $this->applyChanges($context);
            // clear cache for files
            $this->clearCache('files');
        } else {
            $composeDir = sprintf("%s/%s", $sfpath, $cname);
            if (is_dir($composeDir)) {
                $composeName = sprintf("%s/%s", $composeDir, $cname);
                $composeFile = sprintf("%s.yml", $composeName);
                $overrideFile = sprintf("%s/compose.override.yml", $composeDir);
                $envFile = sprintf("%s.env", $composeName);

                $body = $this->renderBody($object->get('body'), $cname, $datapath, $context);
                $env = $this->renderBody($object->get('env'), $cname, $datapath, $context);
                $override = $this->renderBody($object->get('override'), $cname, $datapath, $context);

                $eol = PHP_EOL;
                $eol2 = str_repeat($eol, 2);
                $eol3 = str_repeat($eol, 3);
                $header = $this->getHeader();
                $desc   = $object->get('description');
                $line1 = sprintf("# %s%s", $cname, $eol);
                $line2 = sprintf("# %s", $desc);
                $lineE = sprintf("# environment file for %s%s", $cname, $eol);
                $header1 = $header . $line1 . $line2 . $eol2;
                $header2 = $header . $lineE . $line2 . $eol3;
                $header3 = $header . $line1 . $line2 . $eol3;

                file_put_contents($composeFile, $header1 . $body . PHP_EOL);
                file_put_contents($envFile, $header2 . $env);
                file_put_contents($overrideFile, $header3 . $override);
            } else {
                $this->applyChanges($context);
                $this->clearCache('files');
            }
        }
        // add and commit to git if repo exists
        $files = [];
        $files[] = sprintf("%s/%s.yml", $cname, $cname);
        $files[] = sprintf("%s/%s.env", $cname, $cname);
        $files[] = sprintf("%s/compose.override.yml", $cname);
        $this->addAndCommit($context, $files, $cname);
        // Return the configuration object.
        return $object->getAssoc();
    }

    public function deleteFile($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.objectuuid");
        // Verify that shared folder is set
        $db = \OMV\Config\Database::getInstance();
        $sfpath = $this->getComposePath($context);
        // Delete the configuration object.
        $object = $db->get("conf.service.compose.file", $params['uuid']);
        $cname = $object->get('name');
        $composeDir = sprintf("%s/%s", $sfpath, $cname);
        $composeName = sprintf("%s/%s", $composeDir, $cname);
        $composeFile = sprintf("%s.yml", $composeName);
        $overrideFile = sprintf("%s/compose.override.yml", $composeDir);
        $envFile = sprintf("%s.env", $composeName);
        $composeLink = sprintf("%s/compose.yml", $composeDir);
        $envLink = sprintf("%s/.env", $composeDir);
        // stop container(s) if running
        $cmd = $this->getComposeRunProcess($cname, ['down']);
        $cmd->setQuiet(true);
        $cmd->execute($output, $exitStatus);
        // remove and commit to git if repo exists
        $files = [];
        $files[] = sprintf("%s/%s.yml", $cname, $cname);
        $files[] = sprintf("%s/%s.env", $cname, $cname);
        $files[] = sprintf("%s/compose.override.yml", $cname);
        $this->removeAndCommit($context, $files, $cname);
        // remove files
        $files = [$composeFile, $envFile, $overrideFile, $composeLink, $envLink];
        foreach ($files as $f) {
            if (file_exists($f) || is_link($f)) {
                unlink($f);
            }
        }
        // remove dir if empty
        if (is_dir($composeDir)) {
            rmdir($composeDir);
        }
        // delete database entry
        $db->delete($object);
        // clear cache for files
        $this->clearCache('files');
        // Return the deleted configuration object.
        return $object->getAssoc();
    }

    public function getGlobalEnv($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $object = $db->get("conf.service.compose.globalenv");
        return $object->getAssoc();
    }

    public function setGlobalEnv($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.compose.setglobalenv");
        // Get the existing configuration object.
        $db = \OMV\Config\Database::getInstance();
        $object = $db->get("conf.service.compose.globalenv");
        $object->setAssoc($params);
        $db->set($object);
        // write changes
        $sfpath = $this->getComposePath($context);
        $globalenv = sprintf('%s/global.env', $sfpath);
        $genvbody = $this->renderBody($params['globalenv'], '', '', $context);
        file_put_contents($globalenv, $genvbody . PHP_EOL);
        // add and commit to git if repo exists
        $this->addAndCommit($context, ['global.env'], 'global.env');
        // Return the configuration object.
        return $object->getAssoc();
    }

    public function getDockerfileList($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.getlist");
        // Get configuration data.
        $db = \OMV\Config\Database::getInstance();
        $objects = $db->getAssoc("conf.service.compose.dockerfile");
        // Filter the result.
        return $this->applyFilter($objects, $params['start'], $params['limit'],
            $params['sortfield'], $params['sortdir'], $params['search']);
    }

    public function getDockerfile($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.objectuuid");
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        return $db->getAssoc("conf.service.compose.dockerfile", $params['uuid']);
    }

    public function setDockerfile($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.compose.setdockerfile");
        // make sure filenames are not a full path
        $params['script'] = basename($params['script']);
        $params['conf'] = basename($params['conf']);
        // check for disallowed filenames
        $fname = sprintf('%s.yml', $params['name']);
        $ename = sprintf('%s.env', $params['name']);
        $errors = [
            'script' => gettext("Script filename cannot be"),
            'conf' => gettext("Conf filename cannot be")
        ];
        foreach ($errors as $key => $message) {
            if ($params[$key] == $fname || $params[$key] == $ename || $params[$key] == 'Dockerfile') {
                throw new \OMV\Exception(sprintf("%s %s.", $message, $params[$key]));
            }
        }
        // Verify that shared folder is set
        $db = \OMV\Config\Database::getInstance();
        $sfpath = $this->getComposePath($context);
        // Prepare the configuration object.
        $object = new \OMV\Config\ConfigObject("conf.service.compose.dockerfile");
        $object->setAssoc($params);
        // Set the configuration object.
        $isNew = $object->isNew();
        if (TRUE === $isNew) {
            // Check uniqueness - name
            $db->assertIsUnique($object, "name");
        }
        $db->set($object);
        if (TRUE === $isNew) {
            $this->applyChanges($context);
        } else {
            $dfname = $object->get('name');
            $dfDir = sprintf("%s/%s", $sfpath, $dfname);
            if (is_dir($dfDir)) {
                $dfFile = sprintf("%s/Dockerfile", $dfDir);
                $confFile = sprintf("%s/%s", $dfDir, $object->get('conf'));
                $scriptFile = sprintf("%s/%s", $dfDir, $object->get('script'));

                $dblEol = PHP_EOL . PHP_EOL;
                $desc = $object->get('description');
                $header = $this->getHeader();
                $header1 = sprintf('%s# %s%s# %s%s', $header, $dfname, PHP_EOL, $desc, $dblEol);
                $header2 = sprintf('%s# config file for %s%s# %s%s', $header, $dfname, PHP_EOL, $desc, $dblEol);

                file_put_contents($dfFile, $header1 . $object->get('body') . PHP_EOL);
                if ($object->get('conf') !== '') {
                    file_put_contents($confFile, $header2 . $object->get('conffile') . PHP_EOL);
                }
                if ($object->get('script') !== '') {
                    file_put_contents($scriptFile, $object->get('scriptfile') . PHP_EOL);
                }
            }
        }
        // Return the configuration object.
        return $object->getAssoc();
    }

    public function deleteDockerfile($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.objectuuid");
        // Verify that shared folder is set
        $db = \OMV\Config\Database::getInstance();
        $sfpath = $this->getComposePath($context);
        // Delete the configuration object.
        $object = $db->get("conf.service.compose.dockerfile", $params['uuid']);
        $dname = $object->get('name');
        $dockerDir = sprintf("%s/%s", $sfpath, $dname);
        $files = [sprintf("%s/Dockerfile", $dockerDir)];
        foreach (['script', 'conf'] as $key) {
            if ($object->get($key) !== '') {
                $files[] = sprintf("%s/%s", $dockerDir, $object->get($key));
            }
        }
        foreach ($files as $f) {
            if (is_file($f)) {
                unlink($f);
            }
        }
        // remove dir if empty
        if (is_dir($dockerDir) && count(scandir($dockerDir)) == 2) {
            rmdir($dockerDir);
        }
        $db->delete($object);
        // Return the deleted configuration object.
        return $object->getAssoc();
    }

    public function doBuild($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        $podman = $this->getPodman($context);
        $sfpath = $this->getComposePath($context);
        $showCmd = $this->getShowCmd($context);
        // accept a comma-separated list of names (multi-select) or a single name
        $names = array_filter(array_map('trim', explode(',', $params['names'] ?? $params['name'] ?? '')));
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($names, $params, $sfpath, $showCmd, $podman) {
                $output = '';
                foreach ($names as $name) {
                    $cmdArgs = [];
                    $cmdArgs[] = 'docker';
                    $cmdArgs[] = 'build';
                    if ($params['options'] == 'pull') {
                        $cmdArgs[] = '--pull';
                    }
                    if ($params['options'] == 'nocache') {
                        $cmdArgs[] = '--no-cache';
                    }
                    $cmdArgs[] = '--progress plain';
                    $cmdArgs[] = '--tag ' . escapeshellarg($name);
                    $cmdArgs[] = escapeshellarg(sprintf('%s/%s/', $sfpath, $name));
                    $cmd = new \OMV\System\Process($cmdArgs);
                    if ($podman) {
                        $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                        $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
                    }
                    $cmd->setRedirect2to1();
                    $cmdLine = $cmd->getCommandLine();
                    if ($showCmd) file_put_contents($bgOutputFilename, $cmdLine . PHP_EOL . PHP_EOL, FILE_APPEND);
                    $exitStatus = $this->exec($cmdLine, $output, $bgOutputFilename);
                    if ($exitStatus !== 0) {
                        // single build keeps the old behavior; multi continues with the next one
                        if (count($names) == 1) {
                            throw new \OMV\ExecException($cmdLine, $output);
                        }
                        $errmsg = PHP_EOL . PHP_EOL . '*** ERROR #' . $exitStatus . ' ***' . PHP_EOL . PHP_EOL;
                        file_put_contents($bgOutputFilename, $errmsg, FILE_APPEND);
                    }
                }
                return $output;
            }
        );
    }

    public function doTag($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        $db = \OMV\Config\Database::getInstance();
        $settings = $db->get("conf.service.compose");
        $podman = $this->getPodman($context);
        $sfpath = $this->getComposePath($context);
        $showCmd = $this->getShowCmd($context);
        // docker tag SOURCE_IMAGE[:TAG] TARGET_IMAGE[:TAG]
        $srcids = $this->splitImageIds($params['srcid'] ?? '');
        if (count($srcids) > 1) {
            throw new \OMV\Exception(sprintf(
                gettext("Cannot tag a row that groups %d different images."),
                count($srcids)));
        } elseif (count($srcids) == 1) {
            $src = $srcids[0];
        } elseif (strlen($params['srctag'] ?? '') > 0) {
            $src = sprintf('%s:%s', $params['srcimg'] ?? '', $params['srctag']);
        } else {
            $src = $params['srcimg'] ?? '';
        }
        if (strlen($params['tgttag'] ?? '') > 0) {
            $tgt = sprintf('%s:%s', $params['tgtimg'] ?? '', $params['tgttag']);
        } else {
            $tgt = $params['tgtimg'] ?? '';
        }
        if (strlen($src) == 0 || strlen($tgt) == 0) {
            throw new \OMV\Exception(gettext("Source and target image are required."));
        }
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($src, $tgt, $sfpath, $showCmd, $podman) {
                $cmdArgs = [];
                $cmdArgs[] = 'docker';
                $cmdArgs[] = 'tag';
                $cmdArgs[] = escapeshellarg($src);
                $cmdArgs[] = escapeshellarg($tgt);
                $cmd = new \OMV\System\Process($cmdArgs);
                if ($podman) {
                    $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                    $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
                }
                $cmd->setRedirect2to1();
                $cmdLine = $cmd->getCommandLine();
                if ($showCmd) file_put_contents($bgOutputFilename, $cmdLine . PHP_EOL . PHP_EOL, FILE_APPEND);
                if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                    throw new \OMV\ExecException($cmdLine, $output);
                }
                // show the new tag on the images tab
                $this->clearCache('images');
                return $output;
            }
        );
    }

    public function doHubPush($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        $db = \OMV\Config\Database::getInstance();
        $settings = $db->get("conf.service.compose");
        $podman = $this->getPodman($context);
        $sfpath = $this->getComposePath($context);
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($params, $sfpath, $podman) {
                // docker image push NAME[:TAG]
                $cmdArgs = [];
                $cmdArgs[] = 'docker';
                $cmdArgs[] = 'image';
                $cmdArgs[] = 'push';
                if (strlen($params['imgtag'] ?? '') > 0) {
                    $cmdArgs[] = escapeshellarg(sprintf('%s:%s', $params['imgname'], $params['imgtag']));
                } else {
                    $cmdArgs[] = escapeshellarg($params['imgname']);
                }
                $cmd = new \OMV\System\Process($cmdArgs);
                if ($podman) {
                    $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                    $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
                }
                $cmd->setRedirect2to1();
                $cmdLine = $cmd->getCommandLine();
                if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                    throw new \OMV\ExecException($cmdLine, $output);
                }
                return $output;
            }
        );
    }

    public function doCommand($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // clear cache for files
        $this->clearCache('files');
        $this->clearCache('images');
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $object = $db->get("conf.service.compose.file", $params['uuid']);
        $showCmd = $this->getShowCmd($context);
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($object, $params, $showCmd) {
                $cname = $object->get('name');
                $args = [$params['command'], $params['command2']];
                $quiet = \OMV\Environment::getBoolean("OMV_COMPOSE_QUIET", false);
                if ($quiet) {
                    switch ($params['command']) {
                        case 'pull': $args[] = '--quiet'; break;
                        case 'up -d': $args[] = '--quiet-pull'; break;
                    }
                }
                $cmd = $this->getComposeRunProcess($cname, $args);
                $cmd->setRedirect2to1();
                $cmd->setQuiet(true);
                $cmdLine = $cmd->getCommandLine();
                if ($showCmd) file_put_contents($bgOutputFilename, $this->getComposeRunCmdLine($cname, $args) . PHP_EOL . PHP_EOL, FILE_APPEND);
                $exitStatus = $this->exec($cmdLine, $output, $bgOutputFilename);
                if ($params['command'] != 'config' && $exitStatus !== 0) {
                    $errmsg = PHP_EOL . PHP_EOL . '*** ERROR #' . $exitStatus . ' ***' . PHP_EOL . PHP_EOL;
                    file_put_contents($bgOutputFilename, $errmsg, FILE_APPEND);
                }
                return $output;
            }
        );
    }

    public function doCommandList($params, $context)
    {
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        $this->clearCache('files');
        $this->clearCache('images');
        $db = \OMV\Config\Database::getInstance();
        $uuids = array_filter(array_map('trim', explode(',', $params['uuids'])));
        $objects = [];
        foreach ($uuids as $uuid) {
            $objects[] = $db->get("conf.service.compose.file", $uuid);
        }
        $showCmd = $this->getShowCmd($context);
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($objects, $params, $showCmd) {
                foreach ($objects as $object) {
                    $cname = $object->get('name');
                    $args = [$params['command'], $params['command2'] ?? ''];
                    $quiet = \OMV\Environment::getBoolean("OMV_COMPOSE_QUIET", false);
                    if ($quiet) {
                        switch ($params['command']) {
                            case 'pull': $args[] = '--quiet'; break;
                            case 'up -d': $args[] = '--quiet-pull'; break;
                        }
                    }
                    $cmd = $this->getComposeRunProcess($cname, $args);
                    $cmd->setRedirect2to1();
                    $cmd->setQuiet(true);
                    $cmdLine = $cmd->getCommandLine();
                    if ($showCmd) file_put_contents($bgOutputFilename, $this->getComposeRunCmdLine($cname, $args) . PHP_EOL . PHP_EOL, FILE_APPEND);
                    $exitStatus = $this->exec($cmdLine, $output, $bgOutputFilename);
                    if ($exitStatus !== 0) {
                        $errmsg = PHP_EOL . PHP_EOL . '*** ERROR #' . $exitStatus . ' ***' . PHP_EOL . PHP_EOL;
                        file_put_contents($bgOutputFilename, $errmsg, FILE_APPEND);
                    }
                }
                return $output;
            }
        );
    }

    public function doDownAll($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // clear cache for files
        $this->clearCache('files');
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $objects = $db->get("conf.service.compose.file");
        $showCmd = $this->getShowCmd($context);
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($objects, $showCmd) {
                foreach ($objects as $objectk => &$objectv) {
                    $cname = $objectv->get('name');
                    $cmd = $this->getComposeRunProcess($cname, ['down']);
                    $cmd->setRedirect2to1();
                    $cmd->setQuiet(true);
                    $cmdLine = $cmd->getCommandLine();
                    if ($showCmd) file_put_contents($bgOutputFilename, $this->getComposeRunCmdLine($cname, ['down']) . PHP_EOL . PHP_EOL, FILE_APPEND);
                    $exitStatus = $this->exec($cmdLine, $output, $bgOutputFilename);
                    if ($exitStatus !== 0) {
                        $errmsg = PHP_EOL . PHP_EOL . '*** ERROR #' . $exitStatus . ' ***' . PHP_EOL . PHP_EOL;
                        file_put_contents($bgOutputFilename, $errmsg, FILE_APPEND);
                    }
                }
                return $output;
            }
        );
    }

    public function doGit($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $object = false;
        if (is_uuid($params['uuid'])) {
            if ($params['command'] == 'diffc') {
                $object = $db->get("conf.service.compose.config", $params['uuid']);
            } else {
                $object = $db->get("conf.service.compose.file", $params['uuid']);
            }
        }
        $sfpath = $this->getComposePath($context);
        $showCmd = $this->getShowCmd($context);
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($object, $params, $sfpath, $showCmd, $db) {
                $cmdArgs = [];
                switch ($params['command']) {
                    case 'init':
                        $cmdArgs = [];
                        $cmdArgs[] = escapeshellarg($sfpath);
                        $cmd = new \OMV\System\Process('omv-compose-init-git', $cmdArgs);
                        break;
                    case 'diff':
                        if (!$object)
                            return [];

                        $cname = $object->get('name');
                        $composeDir = sprintf("%s/%s", $sfpath, $cname);
                        $composeName = sprintf("%s/%s", $composeDir, $cname);
                        $overrideFile = sprintf("%s/compose.override.yml", $composeDir);
                        $globalEnvFile = sprintf("%s/global.env", $sfpath);

                        $cmdArgs = [];
                        $cmdArgs[] = '-C ' . escapeshellarg($sfpath);
                        $cmdArgs[] = 'log';
                        $cmdArgs[] = '-p';
                        $cmdArgs[] = '--';
                        $cmdArgs[] = escapeshellarg(sprintf('%s.yml', $composeName));
                        $cmd = new \OMV\System\Process('git', $cmdArgs);
                        break;
                    case 'diffg':
                        $cmdArgs = [];
                        $cmdArgs[] = '-C ' . escapeshellarg($sfpath);
                        $cmdArgs[] = 'log';
                        $cmdArgs[] = '-p';
                        $cmdArgs[] = '--';
                        $cmdArgs[] = 'global.env';
                        $cmd = new \OMV\System\Process('git', $cmdArgs);
                        break;
                    case 'diffc':
                        if (!$object)
                            return [];
                        $cname = $object->get('name');
                        $fobj = $db->get("conf.service.compose.file", $object->get('fileref'));
                        $fname = $fobj->get('name');
                        $cpath = sprintf('%s/%s', $fname, $cname);
                        $cmdArgs = [];
                        $cmdArgs[] = '-C ' . escapeshellarg($sfpath);
                        $cmdArgs[] = 'log';
                        $cmdArgs[] = '-p';
                        $cmdArgs[] = '--';
                        $cmdArgs[] = escapeshellarg($cpath);
                        $cmd = new \OMV\System\Process('git', $cmdArgs);
                        break;
                }
                $cmd->setRedirect2to1();
                $cmd->setQuiet(true);
                $cmdLine = $cmd->getCommandLine();
                if ($showCmd) {
                    file_put_contents($bgOutputFilename, $cmdLine . PHP_EOL . PHP_EOL, FILE_APPEND);
                }
                $exitStatus = $this->exec($cmdLine, $output, $bgOutputFilename);
                if ($exitStatus !== 0) {
                    $errmsg = PHP_EOL . PHP_EOL . '*** ERROR #' . $exitStatus . ' ***' . PHP_EOL . PHP_EOL;
                    file_put_contents($bgOutputFilename, $errmsg, FILE_APPEND);
                }
                return $output;
            }
        );
    }

    function getLog($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.compose.getlog");
        // Create a temporary file which will contain the content of the requested log file.
        $tmpFilePath = tempnam(sys_get_temp_dir(), 'dockerlogfile');
        // Execute the given command to get the log file content.
        $cname = $params['name'];
        $cmd = $this->getComposeRunProcess($cname, ['logs']);
        $cmd->setRedirect1toFile($tmpFilePath);
        $cmd->setRedirect2to1();
        $cmd->execute();
        // Modify the file mode/owner to allow the WebGUI PHP backend to unlink it.
        chmod($tmpFilePath, 0700);
        chown($tmpFilePath, \OMV\Environment::get('OMV_WEBGUI_FILE_OWNERGROUP_NAME'));
        // Return values required by generic download RPC implementation.
        return [
            'filename' => sprintf('%s.log', $cname),
            'filepath' => $tmpFilePath,
            'unlink' => TRUE
        ];
    }

    public function doPrune($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // clear cache for all
        $this->clearCache('all');
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.compose.doprune");
        $podman = $this->getPodman($context);
        $showCmd = $this->getShowCmd($context);
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($params, $showCmd, $podman) {
                $cmdArgs = [];
                $cmdArgs[] = 'docker';
                $cmdArgs[] = $params['command'];
                $cmdArgs[] = '--force';
                $cmd = new \OMV\System\Process($cmdArgs);
                if ($podman) {
                    $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                    $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
                }
                $cmd->setRedirect2to1();
                $cmdLine = $cmd->getCommandLine();
                if ($showCmd) file_put_contents($bgOutputFilename, $cmdLine . PHP_EOL . PHP_EOL, FILE_APPEND);
                if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                    throw new \OMV\ExecException($cmdLine, $output);
                }
                return $output;
            }
        );
    }

    public function enumerateFiles($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Get configuration data.
        $db = \OMV\Config\Database::getInstance();
        $objects = $db->get("conf.service.compose.file");
        $files = [];
        foreach ($objects as $objectk => &$objectv) {
            $uuid = $objectv->get("uuid");
            $name = $objectv->get("name");
            $files[] = [
                'uuid' => $uuid,
                'name' => $name
            ];
        }
        // Filter the result.
        return ($files);
    }

    public function getConfigList($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.getlist");
        // Get configuration data.
        $db = \OMV\Config\Database::getInstance();
        $objects = $db->get("conf.service.compose.config");
        $objectsAssoc = [];
        $sfpath = $this->getComposePath($context);
        foreach ($objects as $objectk => &$objectv) {
            $objectv->add('composefile', 'string', gettext("n/a"));
            try {
                $file = $db->get('conf.service.compose.file', $objectv->get('fileref'));
                $objectv->set('composefile', $file->get('name'));
                $path = sprintf('%s/%s/%s', $sfpath, $file->get('name'), $objectv->get('name'));
                $fullpath = file_exists($path) ? $path : gettext("file not found!");
            } catch (Exception $e) {
                $fullpath = gettext("file not found!");
            }
            $objectv->add('fullpath', 'string', $fullpath);
            $objectv->remove('body');
            $objectsAssoc[] = $objectv->getAssoc();
        }
        // Filter the result.
        return $this->applyFilter($objectsAssoc, $params['start'], $params['limit'],
            $params['sortfield'], $params['sortdir'], $params['search']);
    }

    public function getConfig($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.objectuuid");
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        return $db->getAssoc("conf.service.compose.config", $params['uuid']);
    }

    public function setConfig($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, 'rpc.compose.setconfig');
        // make sure filenames are not a full path
        $params['name'] = basename($params['name']);
        // Verify that shared folder is set
        $db = \OMV\Config\Database::getInstance();
        $sfpath = $this->getComposePath($context);
        // check for bad filename
        $file = $db->get('conf.service.compose.file', $params['fileref']);
        $cfname = $file->get('name');
        $composeFile = sprintf('%s.yml', $cfname);
        $envFile = sprintf('%s.env', $cfname);
        $confName = $params['name'];
        if (($confName == $composeFile) || ($confName == 'compose.override.yml') ||
            ($confName == $envFile) || ($confName == 'Dockerfile')) {
            throw new \OMV\ExecException('Cannot use that filename!');
        }
        // Prepare the configuration object.
        $object = new \OMV\Config\ConfigObject('conf.service.compose.config');
        $object->setAssoc($params);
        // Set the configuration object.
        $isNew = $object->isNew();
        if (TRUE === $isNew) {
            // Check uniqueness - name
            $db->assertIsUnique($object, 'name');
        }
        $db->set($object);
        if (TRUE === $isNew) {
            $this->applyChanges($context);
        } else {
            $composeDir = sprintf('%s/%s', $sfpath, $cfname);
            if (is_dir($composeDir)) {
                $confFile = sprintf('%s/%s', $composeDir, $confName);
                file_put_contents($confFile, $params['body'] . PHP_EOL);
            }
        }
        // add and commit to git if repo exists
        $confPath = sprintf('%s/%s', $cfname, $confName);
        $this->addAndCommit($context, [$confPath], $confName);
        // Return the configuration object.
        return $object->getAssoc();
    }

    public function deleteConfig($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.objectuuid");
        // Verify that shared folder is set
        $db = \OMV\Config\Database::getInstance();
        $sfpath = $this->getComposePath($context);
        // get compose file
        $object = $db->get("conf.service.compose.config", $params['uuid']);
        $fileref = $object->get('fileref');
        $cnfName = $object->get('name');
        try {
            $file = $db->get('conf.service.compose.file', $fileref);
            $composeName = $file->get('name');
            $composeDir = sprintf("%s/%s", $sfpath, $composeName);
            // Delete the configuration object.
            $cnfPath = sprintf("%s/%s", $composeDir, $cnfName);
            // remove and commit to git if repo exists
            $confPath = sprintf('%s/%s', $composeName, $cnfName);
            $this->removeAndCommit($context, [$confPath], $cnfName);
            // remove file
            if (is_file($cnfPath)) {
                unlink($cnfPath);
            }
        } catch (Exception $e) {
            // Parent compose file is gone (orphaned config) — still remove from DB.
        }
        $db->delete($object);
        // Return the deleted configuration object.
        return $object->getAssoc();
    }

    public function getExampleList($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Download example list
        $cmdArgs = [];
        $cmdArgs[] = 'wget';
        $cmdArgs[] = '-4';
        $cmdArgs[] = '-q';
        $cmdArgs[] = '-O -';
        $cmdArgs[] = sprintf("%s/%s/list.json", $this->baseUrl, $this->url);
        $cmd = new \OMV\System\Process($cmdArgs);
        $cmd->setQuiet(true);
        $cmd->execute($list, $exitStatus);
        if ($exitStatus !== 0) {
            return [];
        }
        $listJson = json_decode(implode(PHP_EOL, $list), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return [];
        }
        // create list
        $objects = [];
        foreach ($listJson as $image) {
            $objects[] = [
                "name" => $image['name'],
                "description" => sprintf("%s - %s", $image['name'], $image['description']),
                "image" => $this->getExampleImagesList($image['name'])
            ];
        }
        // Filter the result.
        return ($objects);
    }

    private function getExampleImagesList($name)
    {
        $assets = '/assets/composeImages/';
        mkdir($this->cacheImagesExampleList, 0755, true);
        $path = sprintf('%s/%s', $this->cacheImagesExampleList, $name);
        if (file_exists($path)) {
            return $assets . $name;
        }
        // Fetch the image from the URL
        $url = sprintf('%s/%s/%s/%s', $this->baseUrl, $this->refsUrl, $name, $name);
        $context = stream_context_create(["http" => ["timeout" => 1]]);
        $image = @file_get_contents($url, false, $context);
        if ($image === false) {
            return $assets . 'none';
        }
        // Save the image to the cache
        if (file_put_contents($path, $image) === false) {
            return 'Failed to save image';
        }
        return $assets . $name;
    }

    public function setExample($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.compose.setexample");
        // Verify that shared folder is set
        $this->getComposePath($context);
        // Prepare the configuration object.
        $object = new \OMV\Config\ConfigObject("conf.service.compose.file");
        $name = $params['example'];
        $url = sprintf("%s/%s/%s/%s", $this->baseUrl, $this->url, $name, $name);
        $body = file_get_contents(sprintf("%s.yml", $url));
        $env = file_get_contents(sprintf("%s.env", $url));
        // set object values
        $object->set('name', $params['name']);
        $object->set('description', $params['description']);
        $object->set('body', $body);
        $object->set('env', $env);
        $object->set('override', '');
        // Set the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $db->assertIsUnique($object, "name");
        $db->set($object);
        // delete cache files
        $this->clearCache('files');
        // Return the configuration object.
        return $object->getAssoc();
    }

    public function setUrl($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.compose.seturl");
        // Verify that shared folder is set
        $this->getComposePath($context);
        // Prepare the configuration object.
        $object = new \OMV\Config\ConfigObject("conf.service.compose.file");
        $body = $this->removeIllegal(file_get_contents($params['url']));
        $body = preg_replace('/^(\s*)(?!#)(env_file:)/m', '$1#${2}', $body);
        // set object values
        $object->set('name', $params['name']);
        $object->set('description', $params['description']);
        $object->set('body', $body);
        $object->set('env', '');
        $object->set('override', '');
        // Set the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $db->assertIsUnique($object, "name");
        $db->set($object);
        // delete cache files
        $this->clearCache('files');
        // Return the configuration object.
        return $object->getAssoc();
    }

    public function getServicesList($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.getlist");
        // Get configuration data.
        $db = \OMV\Config\Database::getInstance();
        $sfpath = $this->getComposePath($context);
        $settings = $db->get("conf.service.compose");
        // get fqdn
        $fqdn = $this->getUrlHostname($context);
        // get cterm settings
        try {
            $cterm = $db->get("conf.service.cterm");
            // hmac
            $autouser = $cterm->get('autouser') ?: $context['username'];
            $secret = trim(file_get_contents('/etc/omv_cterm.secret'));
            $ts = sprintf('%s', microtime(true));
            $userts = sprintf('%s:%s', $autouser, $ts);
            $hmac = hash_hmac('sha256', $userts, $secret);
            // get exec url
            $execurl = $this->getExecUrl($context, $db, $fqdn);
        } catch (Exception $e) {
            // cterm not installed
            $cterm = false;
        }
        // get cache time
        $cacheTime = $settings->get('cachetimeservices');
        // populate services
        $imagesAssoc = [];
        $objects = $db->get("conf.service.compose.file");
        // get ps output for all compose files (in parallel)
        $cnames = [];
        foreach ($objects as $objectv) {
            $cnames[] = $objectv->get('name');
        }
        $psOutputs = $this->getComposePsOutputs($cnames, $sfpath,
            $this->cacheFileServices, intval($cacheTime));
        foreach ($objects as $objectk => &$objectv) {
            $cname = $objectv->get('name');
            $path = sprintf("%s/%s/%s", $sfpath, $cname, $cname);
            $filepath = sprintf("%s.yml", $path);
            $envfilepath = sprintf("%s.env", $path);
            $overrideFile = sprintf("%s/%s/compose.override.yml", $sfpath, $cname);
            $exists = file_exists($filepath);
            $output = [];
            if ($exists) {
                $output = $psOutputs[$cname] ?? [];
                foreach ($output as $image) {
                    $imagej = json_decode($image);
                    $ports = [];
                    foreach ($imagej->Publishers as $publisher) {
                        $ports[] = $this->getPort($context, $publisher, $fqdn);
                    }
                    if (!$cterm || ($cterm && $cterm->get("enable") == 0)) {
                        $url = gettext("disabled");
                    } else {
                        $url = sprintf('<a href="%s/%s/docker?user=%s&hmac=%s&ts=%s" target="_blank">link</a>',
                          $execurl, $imagej->Name, $autouser, $hmac, $ts);
                    }
                    $imagesAssoc[] = [
                        "name" => $imagej->Name,
                        "image" => $imagej->Image,
                        "project" => $imagej->Project,
                        "service" => $imagej->Service,
                        "execurl" => $url,
                        "ports" => implode('<br/>', $ports),
                        "created" => date("Y-m-d H:i:s", $imagej->Created),
                        "state" => $imagej->State,
                        "status" => $imagej->Status,
                        "filepath" => $filepath,
                        "envpath" => $envfilepath,
                        "overridepath" => $overrideFile
                    ];
                }
            }
        }
        // Filter the result.
        return $this->applyFilter($imagesAssoc, $params['start'], $params['limit'],
            $params['sortfield'], $params['sortdir'], $params['search']);
    }

    public function getServicesListBg($params, $context) {
        return $this->callMethodBg("getServicesList", $params, $context);
    }

    public function doServiceCommand($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // clear cache for services
        $this->clearCache('services');
        $sfpath = $this->getComposePath($context);
        $cname = $this->getComposeNameFromPath($sfpath, $params['path']);
        $showCmd = $this->getShowCmd($context);
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($params, $cname, $showCmd) {
                $args = [$params['command'], $params['command2']];
                $quiet = \OMV\Environment::getBoolean("OMV_COMPOSE_QUIET", false);
                if ($quiet) {
                    switch ($params['command']) {
                        case 'pull': $args[] = '--quiet'; break;
                        case 'up -d': $args[] = '--quiet-pull'; break;
                    }
                }
                $args[] = $params['service'];
                $cmd = $this->getComposeRunProcess($cname, $args);
                $cmd->setRedirect2to1();
                $cmdLine = $cmd->getCommandLine();
                if ($showCmd) file_put_contents($bgOutputFilename, $this->getComposeRunCmdLine($cname, $args) . PHP_EOL . PHP_EOL, FILE_APPEND);
                if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                    throw new \OMV\ExecException($cmdLine, $output);
                }
                return $output;
            }
        );
    }

    function getServiceLog($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.compose.getservicelog");
        $sfpath = $this->getComposePath($context);
        $cname = $this->getComposeNameFromPath($sfpath, $params['path']);
        // Create a temporary file which will contain the content of the requested log file.
        $tmpFilePath = tempnam(sys_get_temp_dir(), 'dockerlogfile');
        // Execute the given command to get the log file content.
        $cmd = $this->getComposeRunProcess($cname, ['logs', $params['service']]);
        $cmd->setRedirect1toFile($tmpFilePath);
        $cmd->setRedirect2to1();
        $cmd->execute();
        // Modify the file mode/owner to allow the WebGUI PHP backend to unlink it.
        chmod($tmpFilePath, 0700);
        chown($tmpFilePath, \OMV\Environment::get('OMV_WEBGUI_FILE_OWNERGROUP_NAME'));
        // Return values required by generic download RPC implementation.
        return [
            'filename' => sprintf('%s_%s.log', $params['service'],$params['name']),
            'filepath' => $tmpFilePath,
            'unlink' => TRUE
        ];
    }


    public function getContainerList($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.getlist");
        // Get configuration data.
        $db = \OMV\Config\Database::getInstance();
        // get cache time
        $settings = $db->get("conf.service.compose");
        // get fqdn
        $fqdn = $this->getUrlHostname($context);
        $podman = $this->getPodman($context);
        // get cterm settings
        try {
            $cterm = $db->get("conf.service.cterm");
            // hmac
            $autouser = $cterm->get('autouser') ?: $context['username'];
            $secret = trim(file_get_contents('/etc/omv_cterm.secret'));
            $ts = sprintf('%s', microtime(true));
            $userts = sprintf('%s:%s', $autouser, $ts);
            $hmac = hash_hmac('sha256', $userts, $secret);
            // get exec url
            $execurl = $this->getExecUrl($context, $db, $fqdn);
        } catch (Exception $e) {
            // cterm not installed
            $cterm = false;
        }
        $cacheTime = $settings->get('cachetimecontainers');
        // Check if cache file exists and is not older than cache setting
        if ($cacheTime > 0 && file_exists($this->cacheFileContainers)
          && (time() - filemtime($this->cacheFileContainers)) < $cacheTime) {
            $output = json_decode(file_get_contents($this->cacheFileContainers), true);
        } else {
            $output = [];
            // populate containers
            $cmdArgs = [];
            $cmdArgs[] = 'docker';
            $cmdArgs[] = 'container';
            $cmdArgs[] = 'ls';
            $cmdArgs[] = '--all';
            $cmdArgs[] = '--no-trunc';
            if ($podman) {
                $cmdArgs[] = '--format "{{json .}}"';
            } else {
                $cmdArgs[] = '--format "json"';
            }
            $cmd = new \OMV\System\Process($cmdArgs);
            if ($podman) {
                $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
            }
            $cmd->setQuiet(true);
            $cmd->execute($output, $exitStatus);
            if ($cacheTime > 0) {
                file_put_contents($this->cacheFileContainers, json_encode($output));
            }
        }
        $cntAssoc = [];

        // docker --format json might return a JSON array in one line,
        // while {{json .}} returns one JSON object per line.
        // Normalize both into a flat list of container objects.
        $containers = [];
        foreach ($output as $line) {
            $decoded = json_decode($line);
            if ($decoded === null) {
                continue;
            }
            if (is_array($decoded)) {
                foreach ($decoded as $item) {
                    if (is_object($item)) {
                        $containers[] = $item;
                    }
                }
            } elseif (is_object($decoded)) {
                $containers[] = $decoded;
            }
        }

        $cntAssoc = [];
        foreach ($containers as $container) {
            $id   = $container->ID   ?? $container->Id   ?? '';
            $name = $container->Names ?? $container->Name ?? $container->names ?? '';
            $image = $container->Image ?? $container->image ?? '';
            $ports = [];
            $rawPorts = $container->Ports ?? $container->ports ?? null;

            if (is_string($rawPorts)) {
                $portList = array_filter(array_map('trim', explode(',', $rawPorts)));
                foreach ($portList as $p) {
                    $p = str_replace(':::', ':', $p);
                    $match = [];
                    if (preg_match('/:(\d+)->/', $p, $match) === 1) {
                        $ports[] = sprintf('<a href="http://%s:%s" target="_blank">%s</a>', $fqdn, $match[1], $p);
                    } else {
                        $ports[] = $p;
                    }
                }
            } elseif (is_array($rawPorts)) {
                foreach ($rawPorts as $p) {
                    if (is_object($p)) {
                        $hostIp = $p->host_ip ?? $p->HostIp ?? $p->hostIP ?? '';
                        $hostPort = $p->host_port ?? $p->HostPort ?? '';
                        $containerPort = $p->container_port ?? $p->ContainerPort ?? '';
                        $range = (int)($p->range ?? $p->Range ?? 1);
                        $proto = $p->protocol ?? $p->Protocol ?? '';

                        $hostLabel = ($hostIp !== '' ? $hostIp : '0.0.0.0');
                        if ($hostPort !== '' && $containerPort !== '') {
                            if ($range > 1) {
                                $hostEnd = (int)$hostPort + $range - 1;
                                $contEnd = (int)$containerPort + $range - 1;
                                $label = sprintf('%s:%s-%s->%s-%s/%s', $hostLabel, $hostPort, $hostEnd, $containerPort, $contEnd, $proto);
                                $ports[] = sprintf('<a href="http://%s:%s" target="_blank">%s</a>', $fqdn, $hostPort, $label);
                            } else {
                                $label = sprintf('%s:%s->%s/%s', $hostLabel, $hostPort, $containerPort, $proto);
                                $ports[] = sprintf('<a href="http://%s:%s" target="_blank">%s</a>', $fqdn, $hostPort, $label);
                            }
                        } else {
                            $ports[] = json_encode($p, JSON_UNESCAPED_SLASHES);
                        }
                    } else {
                        $ports[] = is_string($p) ? $p : json_encode($p, JSON_UNESCAPED_SLASHES);
                    }
                }
            } else {
                $ports = [];
            }

            $mountLines = [];
            $rawMounts = $container->Mounts ?? $container->mounts ?? null;

            if (is_string($rawMounts)) {
                $mountLines = array_filter(array_map('trim', explode(',', $rawMounts)));
            } elseif (is_array($rawMounts)) {
                foreach ($rawMounts as $m) {
                    if (is_object($m)) {
                        $src = $m->Source ?? $m->source ?? '';
                        $dst = $m->Destination ?? $m->destination ?? '';
                        if ($src !== '' || $dst !== '') {
                            $mountLines[] = ($src !== '' && $dst !== '') ? sprintf('%s:%s', $src, $dst) : ($src ?: $dst);
                        } else {
                            $mountLines[] = json_encode($m, JSON_UNESCAPED_SLASHES);
                        }
                    } else {
                        $mountLines[] = is_string($m) ? $m : json_encode($m, JSON_UNESCAPED_SLASHES);
                    }
                }
            } else {
                $mountLines = [];
            }
            if (!$cterm || ($cterm && $cterm->get("enable") == 0)) {
                $url = gettext("disabled");
            } else {
                $url = sprintf(
                    '<a href="%s/%s/docker?user=%s&hmac=%s&ts=%s" target="_blank">link</a>',
                    $execurl, $name, $autouser, $hmac, $ts
                );
            }
            if ($podman) {
                $created = $container->Created;
                $state   = $container->state;
                $status  = $container->status;
                $running = $container->StartedAt;
                $command = $container->command;
                $network = $container->networks;
            } else {
                $created = $container->CreatedAt;
                $state   = $container->State;
                $status  = $container->Status;
                $running = $container->RunningFor;
                $command = $container->Command;
                $network = $container->Networks;
            }
            $cntAssoc[] = [
                "id"      => $id,
                "name"    => $name,
                "image"   => $image,
                "execurl" => $url,
                "ports"   => implode('<br/>', $ports),
                "mounts"  => implode('<br/>', $mountLines),
                "created" => $created,
                "state"   => $state,
                "status"  => $status,
                "running" => $running,
                "command" => $command,
                "network" => $network
            ];
        }
        // Filter the result.
        return $this->applyFilter($cntAssoc, $params['start'], $params['limit'],
            $params['sortfield'], $params['sortdir'], $params['search']);
    }

    public function getContainerListBg($params, $context) {
        return $this->callMethodBg("getContainerList", $params, $context);
    }

    public function doContainerCommand($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // delete cache containers
        $this->clearCache('containers');
        $podman = $this->getPodman($context);
        $showCmd = $this->getShowCmd($context);
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($params, $showCmd, $podman) {
                $cmdArgs = [];
                $cmdArgs[] = 'docker';
                $cmdArgs[] = $params['command'];
                $cmdArgs[] = $params['command2'];
                $cmdArgs[] = $params['id'];
                $cmdArgs = array_filter($cmdArgs);
                $cmd = new \OMV\System\Process($cmdArgs);
                if ($podman) {
                    $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                    $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
                }
                $cmd->setRedirect2to1();
                $cmdLine = $cmd->getCommandLine();
                if ($showCmd) file_put_contents($bgOutputFilename, $cmdLine . PHP_EOL . PHP_EOL, FILE_APPEND);
                if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                    throw new \OMV\ExecException($cmdLine, $output);
                }
                return $output;
            }
        );
    }

    function getContainerLog($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.compose.getcontainerlog");
        // Create a temporary file which will contain the content of the requested log file.
        $tmpFilePath = tempnam(sys_get_temp_dir(), 'dockerlogfile');
        // Execute the given command to get the log file content.
        $podman = $this->getPodman($context);
        $sfpath = $this->getComposePath($context);
        $cmdArgs = [];
        $cmdArgs[] = 'docker';
        $cmdArgs[] = 'logs';
        $cmdArgs[] = $params['id'];
        $cmd = new \OMV\System\Process($cmdArgs);
        if ($podman) {
            $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
            $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
        }
        $cmd->setRedirect1toFile($tmpFilePath);
        $cmd->setRedirect2to1();
        $cmd->execute();
        // Modify the file mode/owner to allow the WebGUI PHP backend to unlink it.
        chmod($tmpFilePath, 0700);
        chown($tmpFilePath, \OMV\Environment::get('OMV_WEBGUI_FILE_OWNERGROUP_NAME'));
        // Return values required by generic download RPC implementation.
        return [
            'filename' => sprintf('%s_%s.log', $params['name'],$params['id']),
            'filepath' => $tmpFilePath,
            'unlink' => TRUE
        ];
    }

    public function enumerateContainers($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        $podman = $this->getPodman($context);
        // Get running containers
        $cmdArgs = [];
        $cmdArgs[] = 'docker';
        $cmdArgs[] = 'container';
        $cmdArgs[] = 'ls';
        $cmdArgs[] = '--format "{{.Names}},{{.Image}}"';
        $cmd = new \OMV\System\Process($cmdArgs);
        if ($podman) {
            $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
            $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
        }
        $output = [];
        $cmd->execute($output, $exitStatus);
        $objects = [];
        foreach ($output as $line) {
            $cntr = explode(',', $line);
            $objects[] = [
                'desc' => sprintf('%s (%s)', trim($cntr[0]), trim($cntr[1])),
                'name' => trim($cntr[0])
            ];
        }
        return ($objects);
    }

    public function doAutocompose($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.compose.doautocompose");
        // Verify that shared folder is set
        $this->getComposePath($context);
        // Get running containers
        $cmdArgs = [];
        $cmdArgs[] = 'python3';
        $cmdArgs[] = '/usr/bin/autocompose.py';
        $cmdArgs[] = sprintf('-v %s', $params['version']);
        $cmdArgs[] = $params['container'];
        $cmd = new \OMV\System\Process($cmdArgs);
        $output = [];
        $cmd->execute($output, $exitStatus);
        // Prepare the configuration object.
        $object = new \OMV\Config\ConfigObject("conf.service.compose.file");
        // set object values
        $object->set('name', $params['name']);
        $object->set('description', $params['description']);
        $object->set('body', trim(implode(PHP_EOL, $output)));
        $object->set('env', '');
        $object->set('override', '');
        // Set the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $db->assertIsUnique($object, 'name');
        $db->set($object);
        // delete cache files
        $this->clearCache('files');
        // Return the configuration object.
        return $object->getAssoc();
    }

    public function importChanges($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Verify that shared folder is set
        $sfpath = $this->getComposePath($context);
        $dockerpath = $this->getDockerPath($context);
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $object = $db->get("conf.service.compose.file", $params['uuid']);
        // Set paths
        $cname = $object->get('name');
        $composeDir = sprintf("%s/%s", $sfpath, $cname);
        $composeName = sprintf("%s/%s", $composeDir, $cname);
        $composeFile = sprintf("%s.yml", $composeName);
        $overrideFile = sprintf("%s/compose.override.yml", $composeDir);
        $envFile = sprintf("%s.env", $composeName);
        // Get file content
        $composeContent = $this->removeIllegal(file_get_contents($composeFile));
        $envContent = $this->removeIllegal(file_get_contents($envFile));
        $overrideContent = $this->removeIllegal(file_get_contents($overrideFile));
        if ($dockerpath != '') {
            $composeContent = preg_replace('/'.str_replace('/','\/',$dockerpath).'/', 'CHANGE_TO_COMPOSE_DATA_PATH', $composeContent);
        }
        // Update object
        $object->set('body', $composeContent);
        $object->set('env', $envContent);
        $object->set('override', $overrideContent);
        // Set the configuration object.
        $db->set($object);
        // delete cache files
        $this->clearCache('files');
        // Return the configuration object.
        return $object->getAssoc();
    }

    public function importExistingFolder($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Verify that shared folder is set
        $sfpath = $this->getComposePath($context);
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $path = $params['path'];
        $path = (substr($path, 0, 1) == '/' ? $path : '/' . $path);
        // If the user entered a file path, use its parent directory
        if (!is_dir($path)) {
            $path = dirname($path);
        }
        $dirs = array_diff(scandir($path), ["..", "."]);
        foreach ($dirs as $dir) {
            $full = sprintf('%s/%s', $path, $dir);
            if (!is_dir($full)) {
                continue;
            }
            $object = new \OMV\Config\ConfigObject("conf.service.compose.file");
            // get compose file — check candidates in priority order
            $candidates = [
                sprintf('%s/%s.yml', $full, $dir),
                sprintf('%s/compose.yml', $full),
                sprintf('%s/compose.yaml', $full),
                sprintf('%s/docker-compose.yml', $full),
                sprintf('%s/docker-compose.yaml', $full),
            ];
            $bodyFile = null;
            foreach ($candidates as $candidate) {
                if (file_exists($candidate)) {
                    $bodyFile = $candidate;
                    break;
                }
            }
            if ($bodyFile === null) {
                continue;
            }
            $body = $this->removeIllegal(file_get_contents($bodyFile));
            // get environment file if it exists
            $envFile = sprintf('%s/%s.env', $full, $dir);
            if (file_exists($envFile)) {
                $env = $this->removeIllegal(file_get_contents($envFile));
                if ($env == false || is_null($env)) $env = '';
            } else {
                $env = '';
            }
            $overrideFile = sprintf("%s/compose.override.yml", $full);
            if (file_exists($overrideFile)) {
                $override = $this->removeIllegal(file_get_contents($overrideFile));
                if ($override == false || is_null($override)) $override = '';
            } else {
                $override = '';
            }
            // set object values
            $object->set('name', $dir);
            $object->set('description', 'imported ' . date("Y.m.d H:i"));
            $object->set('body', $body);
            $object->set('env', $env);
            $object->set('override', $override);
            // Set the configuration object.
            try {
                $db->assertIsUnique($object, 'name');
            } catch (Exception $e) {
                continue;
            }
            $db->set($object);
        }
        // clear cache for files
        $this->clearCache('files');
    }

    public function importExistingOne($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Verify that shared folder is set
        $sfpath = $this->getComposePath($context);
        // Get the configuration object.
        $path = $params['path'];
        $path = (substr($path, 0, 1) == '/' ? $path : '/' . $path);
        // If the user entered a file path, use its parent directory
        if (!is_dir($path)) {
            $path = dirname($path);
        }
        if (!is_dir($path)) {
            throw new \OMV\ExecException($path . ' does not exist!');
        }
        $name = basename(rtrim($path, '/'));
        // get body — check candidates in priority order
        $candidates = [
            sprintf('%s/%s.yml', $path, $name),
            sprintf('%s/compose.yml', $path),
            sprintf('%s/compose.yaml', $path),
            sprintf('%s/docker-compose.yml', $path),
            sprintf('%s/docker-compose.yaml', $path),
        ];
        $bodyFile = null;
        foreach ($candidates as $candidate) {
            if (file_exists($candidate)) {
                $bodyFile = $candidate;
                break;
            }
        }
        if ($bodyFile === null) {
            throw new \OMV\ExecException(gettext("No compose file found!"));
        }
        $body = $this->removeIllegal(file_get_contents($bodyFile));
        // get env (if exists)
        $envFile = sprintf('%s/%s.env', $path, $name);
        if (!file_exists($envFile)) {
            $envFile = sprintf('%s/.env', $path);
        }
        $env = '';
        if (file_exists($envFile)) {
            $env = $this->removeIllegal(file_get_contents($envFile));
            if ($env === false || $env === null) {
                $env = '';
            }
        }
        $overrideFile = sprintf("%s/compose.override.yml", $path);
        if (file_exists($overrideFile)) {
            $override = $this->removeIllegal(file_get_contents($overrideFile));
            if ($override == false || is_null($override)) $override = '';
        } else {
            $override = '';
        }
        // set object values
        $object = new \OMV\Config\ConfigObject("conf.service.compose.file");
        $object->set('name', $name);
        $object->set('description', $this->descriptionFromReadme($path) ?? ('imported ' . date("Y.m.d H:i")));
        $object->set('body', $body);
        $object->set('env', $env);
        $object->set('override', $override);
        // Set the configuration object.
        $db = \OMV\Config\Database::getInstance();
        try {
            $db->assertIsUnique($object, 'name');
        } catch (Exception $e) {
            throw new \OMV\ExecException("A compose file with the name '$name' already exists!");
        }
        $db->set($object);
        // clear cache for files
        $this->clearCache('files');
    }

    public function doImportExistingOne($params, $context)
    {
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        $this->getComposePath($context);
        $path = $params['path'];
        $path = (substr($path, 0, 1) == '/' ? $path : '/' . $path);
        if (!is_dir($path)) {
            $path = dirname($path);
        }
        if (!is_dir($path)) {
            throw new \OMV\ExecException($path . ' does not exist!');
        }
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename) use ($path) {
            $name = basename(rtrim($path, '/'));
            $composeFile = $this->findComposeFile($path);
            if ($composeFile === null) {
                file_put_contents($bgOutputFilename, "No compose file found in: $path\n", FILE_APPEND);
                return;
            }
            $filename = basename($composeFile);
            $db = \OMV\Config\Database::getInstance();
            $tempObj = new \OMV\Config\ConfigObject("conf.service.compose.file");
            $tempObj->set('name', $name);
            try {
                $db->assertIsUnique($tempObj, 'name');
            } catch (Exception $e) {
                file_put_contents($bgOutputFilename,
                    "Skipping (already exists): $name\n", FILE_APPEND);
                return;
            }
            $body = $this->removeIllegal(file_get_contents($composeFile));
            $envFile = sprintf('%s/%s.env', $path, $name);
            if (!file_exists($envFile)) {
                $envFile = sprintf('%s/.env', $path);
            }
            $env = '';
            if (file_exists($envFile)) {
                $env = $this->removeIllegal(file_get_contents($envFile)) ?: '';
            }
            $overrideFile = sprintf('%s/compose.override.yml', $path);
            $override = '';
            if (file_exists($overrideFile)) {
                $override = $this->removeIllegal(file_get_contents($overrideFile)) ?: '';
            }
            $desc = $this->descriptionFromReadme($path) ?? ('imported ' . date("Y.m.d H:i"));
            $object = new \OMV\Config\ConfigObject("conf.service.compose.file");
            $object->set('name', $name);
            $object->set('description', $desc);
            $object->set('body', $body);
            $object->set('env', $env);
            $object->set('override', $override);
            $db->set($object);
            $this->clearCache('files');
            file_put_contents($bgOutputFilename,
                "Imported: $name  ($filename)\n", FILE_APPEND);
        });
    }

    public function doPreviewImportFolder($params, $context)
    {
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        $path = $params['path'];
        $path = (substr($path, 0, 1) == '/' ? $path : '/' . $path);
        if (!is_dir($path)) {
            $path = dirname($path);
        }
        if (!is_dir($path)) {
            throw new \OMV\ExecException($path . ' does not exist!');
        }
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename) use ($path) {
            file_put_contents($bgOutputFilename, "Scanning: $path\n\n", FILE_APPEND);
            $dirs = $this->scanForComposeDirs($path);
            if (empty($dirs)) {
                file_put_contents($bgOutputFilename, "No compose files found.\n", FILE_APPEND);
                return;
            }
            $db = \OMV\Config\Database::getInstance();
            $wouldImport = 0;
            $wouldSkip = 0;
            file_put_contents($bgOutputFilename,
                sprintf("Found %d folder(s):\n\n", count($dirs)), FILE_APPEND);
            foreach ($dirs as $dir) {
                $name = basename(rtrim($dir, '/'));
                $composeFile = $this->findComposeFile($dir);
                $filename = basename($composeFile);
                $tempObj = new \OMV\Config\ConfigObject("conf.service.compose.file");
                $tempObj->set('name', $name);
                $exists = false;
                try {
                    $db->assertIsUnique($tempObj, 'name');
                } catch (Exception $e) {
                    $exists = true;
                }
                if ($exists) {
                    file_put_contents($bgOutputFilename,
                        "  [SKIP - already exists]  $name  ($filename)\n", FILE_APPEND);
                    $wouldSkip++;
                } else {
                    $desc = $this->descriptionFromReadme($dir);
                    $descStr = $desc ? " — $desc" : '';
                    file_put_contents($bgOutputFilename,
                        "  [WOULD IMPORT]  $name  ($filename)$descStr\n", FILE_APPEND);
                    $wouldImport++;
                }
            }
            file_put_contents($bgOutputFilename, sprintf(
                "\nSummary: %d would be imported, %d already exist (would skip).\n",
                $wouldImport, $wouldSkip
            ), FILE_APPEND);
        });
    }

    public function doImportExistingFolder($params, $context)
    {
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        $this->getComposePath($context);
        $path = $params['path'];
        $path = (substr($path, 0, 1) == '/' ? $path : '/' . $path);
        if (!is_dir($path)) {
            $path = dirname($path);
        }
        if (!is_dir($path)) {
            throw new \OMV\ExecException($path . ' does not exist!');
        }
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename) use ($path) {
            file_put_contents($bgOutputFilename, "Scanning: $path\n\n", FILE_APPEND);
            $dirs = $this->scanForComposeDirs($path);
            if (empty($dirs)) {
                file_put_contents($bgOutputFilename, "No compose files found.\n", FILE_APPEND);
                return;
            }
            $db = \OMV\Config\Database::getInstance();
            $imported = 0;
            $skipped = 0;
            foreach ($dirs as $dir) {
                $name = basename(rtrim($dir, '/'));
                $composeFile = $this->findComposeFile($dir);
                $filename = basename($composeFile);
                $tempObj = new \OMV\Config\ConfigObject("conf.service.compose.file");
                $tempObj->set('name', $name);
                try {
                    $db->assertIsUnique($tempObj, 'name');
                } catch (Exception $e) {
                    file_put_contents($bgOutputFilename,
                        "  Skipping (already exists): $name\n", FILE_APPEND);
                    $skipped++;
                    continue;
                }
                $body = $this->removeIllegal(file_get_contents($composeFile));
                $envFile = sprintf('%s/%s.env', $dir, $name);
                if (!file_exists($envFile)) {
                    $envFile = sprintf('%s/.env', $dir);
                }
                $env = '';
                if (file_exists($envFile)) {
                    $env = $this->removeIllegal(file_get_contents($envFile)) ?: '';
                }
                $overrideFile = sprintf('%s/compose.override.yml', $dir);
                $override = '';
                if (file_exists($overrideFile)) {
                    $override = $this->removeIllegal(file_get_contents($overrideFile)) ?: '';
                }
                $desc = $this->descriptionFromReadme($dir) ?? ('imported ' . date("Y.m.d H:i"));
                $object = new \OMV\Config\ConfigObject("conf.service.compose.file");
                $object->set('name', $name);
                $object->set('description', $desc);
                $object->set('body', $body);
                $object->set('env', $env);
                $object->set('override', $override);
                $db->set($object);
                file_put_contents($bgOutputFilename,
                    "  Imported: $name  ($filename)\n", FILE_APPEND);
                $imported++;
            }
            $this->clearCache('files');
            file_put_contents($bgOutputFilename, sprintf(
                "\nDone. %d imported, %d skipped (already exist).\n",
                $imported, $skipped
            ), FILE_APPEND);
        });
    }

    public function importConfig($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Verify that shared folder is set
        $sfpath = $this->getComposePath($context);
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        // fix path
        $path = $params['path'];
        $path = (substr($path, 0, 1) == '/' ? $path : '/' . $path);
        // get last directory name
        $lastDir = rtrim($path, DIRECTORY_SEPARATOR);
        $lastDirName = basename($lastDir);
        // get a list files and exclude compose related files
        $excludes = ["..", ".", "compose.override.yml", $lastDirName . '.yml', $lastDirName . '.env'];
        $files = array_diff(scandir($path), $excludes);
        // get compose file uuid
        $fileref = $params['fileref'];
        // import files
        foreach ($files as $file) {
            $full = sprintf('%s/%s', $path, $file);
            if (is_dir($full)) {
                continue;
            }
            $object = new \OMV\Config\ConfigObject("conf.service.compose.config");
            // set object values
            $object->set('name', $file);
            $object->set('description', 'imported ' . date("Y.m.d H:i"));
            $object->set('fileref', $fileref);
            $object->set('body', $this->removeIllegal(file_get_contents($full)));
            // Set the configuration object.
            try {
                $db->assertIsUnique($object, 'name');
            } catch (Exception $e) {
                continue;
            }
            $db->set($object);
        }
    }

    public function importPortainerStacks($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.compose.importportainerstacks");
        $portainerUrl = rtrim($params['url'], '/');
        $apiKey = trim($params['apikey'] ?? '');
        $username = trim($params['username'] ?? '');
        $password = trim($params['password'] ?? '');
        $sslverify = $params['sslverify'] ?? true;
        // Determine auth token — API key takes precedence over username/password.
        if (!empty($apiKey)) {
            $authHeader = "X-API-Key: $apiKey\r\n";
        } elseif (!empty($username)) {
            $jwt = $this->portainerLogin($portainerUrl, $username, $password, $sslverify);
            $authHeader = "Authorization: Bearer $jwt\r\n";
        } else {
            throw new \OMV\Exception(gettext("Provide either an API key or a username and password."));
        }
        // Fetch stack list and import each compose stack.
        $stacks = $this->portainerGet($portainerUrl . '/api/stacks', $authHeader, $sslverify);
        if (!is_array($stacks)) {
            throw new \OMV\Exception(gettext("Unexpected response from Portainer API."));
        }
        $db = \OMV\Config\Database::getInstance();
        $imported = 0;
        foreach ($stacks as $stack) {
            // Type 2 = standalone compose stack; skip swarm (1) and kubernetes (3).
            if (($stack['Type'] ?? 0) !== 2) {
                continue;
            }
            $name = $stack['Name'] ?? '';
            if (empty($name)) {
                continue;
            }
            $fileData = $this->portainerGet(
                $portainerUrl . '/api/stacks/' . $stack['Id'] . '/file',
                $authHeader,
                $sslverify
            );
            $body = $fileData['StackFileContent'] ?? '';
            if (empty($body)) {
                continue;
            }
            // Convert Portainer env array [{"name":...,"value":...}] to KEY=VALUE lines.
            $env = '';
            if (!empty($stack['Env']) && is_array($stack['Env'])) {
                $lines = [];
                foreach ($stack['Env'] as $e) {
                    if (!empty($e['name'])) {
                        $lines[] = $e['name'] . '=' . ($e['value'] ?? '');
                    }
                }
                $env = implode(PHP_EOL, $lines);
            }
            $object = new \OMV\Config\ConfigObject("conf.service.compose.file");
            $object->set('name', $name);
            $object->set('description', 'imported from Portainer ' . date("Y.m.d H:i"));
            $object->set('body', $this->removeIllegal($body));
            $object->set('env', $this->removeIllegal($env));
            $object->set('override', '');
            try {
                $db->assertIsUnique($object, 'name');
            } catch (Exception $e) {
                continue;
            }
            $db->set($object);
            $imported++;
        }
        $this->clearCache('files');
        return $imported;
    }

    public function doImportPortainerStacks($params, $context)
    {
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // sslverify arrives as a string ("true"/"false") when called from a
        // taskDialog, so coerce it explicitly rather than relying on schema validation.
        $portainerUrl = rtrim($params['url'], '/');
        $apiKey       = trim($params['apikey'] ?? '');
        $username     = trim($params['username'] ?? '');
        $password     = trim($params['password'] ?? '');
        $sslverify    = filter_var($params['sslverify'] ?? true, FILTER_VALIDATE_BOOLEAN);
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($portainerUrl, $apiKey, $username, $password, $sslverify) {
                file_put_contents($bgOutputFilename,
                    "Connecting to Portainer: $portainerUrl\n\n", FILE_APPEND);
                if (!empty($apiKey)) {
                    $authHeader = "X-API-Key: $apiKey\r\n";
                } elseif (!empty($username)) {
                    try {
                        $jwt = $this->portainerLogin($portainerUrl, $username, $password, $sslverify);
                    } catch (Exception $e) {
                        file_put_contents($bgOutputFilename,
                            "Error: " . $e->getMessage() . "\n", FILE_APPEND);
                        return;
                    }
                    $authHeader = "Authorization: Bearer $jwt\r\n";
                } else {
                    file_put_contents($bgOutputFilename,
                        "Error: Provide either an API key or a username and password.\n", FILE_APPEND);
                    return;
                }
                try {
                    $stacks = $this->portainerGet($portainerUrl . '/api/stacks', $authHeader, $sslverify);
                } catch (Exception $e) {
                    file_put_contents($bgOutputFilename,
                        "Error: " . $e->getMessage() . "\n", FILE_APPEND);
                    return;
                }
                if (!is_array($stacks)) {
                    file_put_contents($bgOutputFilename,
                        "Error: Unexpected response from Portainer API.\n", FILE_APPEND);
                    return;
                }
                $db = \OMV\Config\Database::getInstance();
                $imported = 0;
                $skipped  = 0;
                foreach ($stacks as $stack) {
                    if (($stack['Type'] ?? 0) !== 2) {
                        continue;
                    }
                    $name = $stack['Name'] ?? '';
                    if (empty($name)) {
                        continue;
                    }
                    try {
                        $fileData = $this->portainerGet(
                            $portainerUrl . '/api/stacks/' . $stack['Id'] . '/file',
                            $authHeader,
                            $sslverify
                        );
                    } catch (Exception $e) {
                        file_put_contents($bgOutputFilename,
                            "  Error fetching $name: " . $e->getMessage() . "\n", FILE_APPEND);
                        continue;
                    }
                    $body = $fileData['StackFileContent'] ?? '';
                    if (empty($body)) {
                        continue;
                    }
                    $env = '';
                    if (!empty($stack['Env']) && is_array($stack['Env'])) {
                        $lines = [];
                        foreach ($stack['Env'] as $e) {
                            if (!empty($e['name'])) {
                                $lines[] = $e['name'] . '=' . ($e['value'] ?? '');
                            }
                        }
                        $env = implode(PHP_EOL, $lines);
                    }
                    $object = new \OMV\Config\ConfigObject("conf.service.compose.file");
                    $object->set('name', $name);
                    $object->set('description', 'imported from Portainer ' . date("Y.m.d H:i"));
                    $object->set('body', $this->removeIllegal($body));
                    $object->set('env', $this->removeIllegal($env));
                    $object->set('override', '');
                    $tempObj = new \OMV\Config\ConfigObject("conf.service.compose.file");
                    $tempObj->set('name', $name);
                    try {
                        $db->assertIsUnique($tempObj, 'name');
                    } catch (Exception $e) {
                        file_put_contents($bgOutputFilename,
                            "  Skipping (already exists): $name\n", FILE_APPEND);
                        $skipped++;
                        continue;
                    }
                    $db->set($object);
                    file_put_contents($bgOutputFilename,
                        "  Imported: $name\n", FILE_APPEND);
                    $imported++;
                }
                $this->clearCache('files');
                file_put_contents($bgOutputFilename, sprintf(
                    "\nDone. %d imported, %d skipped (already exist).\n",
                    $imported, $skipped
                ), FILE_APPEND);
            }
        );
    }

    private function portainerLogin(string $url, string $username, string $password, bool $sslverify): string
    {
        $payload = json_encode(['Username' => $username, 'Password' => $password]);
        $context = stream_context_create([
            'http' => [
                'method'        => 'POST',
                'header'        => "Content-Type: application/json\r\nContent-Length: " . strlen($payload) . "\r\n",
                'content'       => $payload,
                'timeout'       => 10,
                'ignore_errors' => true,
            ],
            'ssl' => ['verify_peer' => $sslverify, 'verify_peer_name' => $sslverify],
        ]);
        $response = @file_get_contents($url . '/api/auth', false, $context);
        if ($response === false) {
            throw new \OMV\Exception(sprintf(gettext("Could not connect to Portainer at %s."), $url));
        }
        $data = json_decode($response, true);
        if (empty($data['jwt'])) {
            throw new \OMV\Exception(gettext("Portainer authentication failed. Check your credentials."));
        }
        return $data['jwt'];
    }

    private function portainerGet(string $url, string $authHeader, bool $sslverify): array
    {
        $context = stream_context_create([
            'http' => [
                'method'        => 'GET',
                'header'        => "Content-Type: application/json\r\n" . $authHeader,
                'timeout'       => 10,
                'ignore_errors' => true,
            ],
            'ssl' => ['verify_peer' => $sslverify, 'verify_peer_name' => $sslverify],
        ]);
        $response = @file_get_contents($url, false, $context);
        if ($response === false) {
            throw new \OMV\Exception(sprintf(gettext("Portainer API request failed: %s"), $url));
        }
        $data = json_decode($response, true);
        if (!is_array($data)) {
            throw new \OMV\Exception(sprintf(gettext("Invalid JSON response from Portainer: %s"), $url));
        }
        return $data;
    }

    public function importDockerfile($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Verify that shared folder is set
        $sfpath = $this->getComposePath($context);
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        // fix path
        $path = $params['path'];
        $path = (substr($path, 0, 1) == '/' ? $path : '/' . $path);
        // scan for subdirectories containing a Dockerfile
        $dirs = array_diff(scandir($path), ["..", "."]);
        foreach ($dirs as $dir) {
            $full = sprintf('%s/%s', $path, $dir);
            if (!is_dir($full)) {
                continue;
            }
            $dockerFile = sprintf('%s/Dockerfile', $full);
            if (!file_exists($dockerFile)) {
                continue;
            }
            $object = new \OMV\Config\ConfigObject("conf.service.compose.dockerfile");
            $object->set('name', $dir);
            $object->set('description', 'imported ' . date("Y.m.d H:i"));
            $object->set('body', $this->removeIllegal(file_get_contents($dockerFile)));
            $object->set('script', '');
            $object->set('scriptfile', '');
            $object->set('conf', '');
            $object->set('conffile', '');
            // skip if a dockerfile with this name already exists
            try {
                $db->assertIsUnique($object, 'name');
            } catch (Exception $e) {
                continue;
            }
            $db->set($object);
        }
    }

    private function removeIllegal(string $xmlString): string
    {
        // match anything NOT in the allowed XML 1.0 ranges
        return trim(preg_replace('/[^\x09\x0A\x0D\x20-\x{D7FF}\x{E000}-\x{FFFD}]+/u', '', $xmlString));
    }

    public function getStats($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // get cache time
        $db = \OMV\Config\Database::getInstance();
        $settings = $db->get("conf.service.compose");
        $cacheTime = $settings->get('cachetimestats');
        $podman = $this->getPodman($context);
        // Check if cache file exists and is not older than cache setting
        if ($cacheTime > 0 && file_exists($this->cacheFileStats)
          && (time() - filemtime($this->cacheFileStats)) < $cacheTime) {
            $output = file_get_contents($this->cacheFileStats);
            $output = explode(PHP_EOL, $output);
        } else {
            // Get running containers
            $cmdArgs = [];
            $cmdArgs[] = 'docker';
            $cmdArgs[] = 'stats';
            $cmdArgs[] = '--no-stream';
            $cmdArgs[] = '--format "{{.ID}},{{.Name}},{{.CPUPerc}},{{.MemUsage}},{{.MemPerc}},{{.NetIO}},{{.BlockIO}},{{.PIDs}}"';
            $cmd = new \OMV\System\Process($cmdArgs);
            if ($podman) {
                $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
            }
            $output = [];
            $cmd->execute($output, $exitStatus);
            if ($cacheTime > 0) {
                $output2 = implode(PHP_EOL, $output);
                file_put_contents($this->cacheFileStats, $output2);
            }
        }
        $objects = [];
        foreach ($output as $line) {
            if (trim($line) === '') {
                continue;
            }
            $cntr = explode(',', $line);
            $cpu = floatval(trim(str_replace('%', '', $cntr[2])));
            $memUL = explode('/', $cntr[3]);
            $memUse = $this->convertToBytes($memUL[0]);
            $memLim = $this->convertToBytes($memUL[1]);
            $mem = floatval(trim(str_replace('%', '', $cntr[4])));
            $net = explode('/', $cntr[5]);
            $netIn = $this->convertToBytes($net[0]);
            $netOut = $this->convertToBytes($net[1]);
            $block = explode('/', $cntr[6]);
            $blockIn = $this->convertToBytes($block[0]);
            $blockOut = $this->convertToBytes($block[1]);
            $objects[] = [
                'id' => trim($cntr[0]),
                'name' => trim($cntr[1]),
                'cpu' => $cpu,
                'memuse' => $memUse,
                'memlim' => $memLim,
                'mem' => $mem,
                'netin' => $netIn,
                'netout' => $netOut,
                'blockin' => $blockIn,
                'blockout' => $blockOut,
                'pids' => intval(trim($cntr[7]))
            ];
        }
        return $this->applyFilter($objects, $params['start'], $params['limit'],
            $params['sortfield'], $params['sortdir'], $params['search']);
    }

    public function getStatsBg($params, $context) {
        return $this->callMethodBg("getStats", $params, $context);
    }

    private function convertToBytes($val)
    {
        $valL = strtolower($val);
        $level = 1;
        if (strpos($valL, 'k')) {
            $level = 1024;
        } elseif (strpos($valL, 'm')) {
            $level = pow(1024, 2);
        } elseif (strpos($valL, 'g')) {
            $level = pow(1024, 3);
        } elseif (strpos($valL, 't')) {
            $level = pow(1024, 4);
        } elseif (strpos($valL, 'p')) {
            $level = pow(1024, 5);
        }
        return (intval(floatval($val) * $level));
    }

    public function doDockerCmd($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // clear cache for stats
        $this->clearCache('stats');
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.compose.dodockercmd");
        $podman = $this->getPodman($context);
        $showCmd = $this->getShowCmd($context);
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($params, $showCmd, $podman) {
                $cmdArgs = [];
                $cmdArgs[] = 'docker';
                $cmdArgs[] = $params['cmd'];
                $cmdArgs[] = $params['cmd2'];
                $cmdArgs[] = $params['id'];
                $cmdArgs = array_filter($cmdArgs);
                $cmd = new \OMV\System\Process($cmdArgs);
                if ($podman) {
                    $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                    $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
                }
                $cmd->setRedirect2to1();
                $cmdLine = $cmd->getCommandLine();
                if ($showCmd) file_put_contents($bgOutputFilename, $cmdLine . PHP_EOL . PHP_EOL, FILE_APPEND);
                if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                    throw new \OMV\ExecException($cmdLine, $output);
                }
                return $output;
            }
        );
    }

    public function getContainers($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_EVERYONE]);
        $objects = [];
        $status = '';
        $podman = $this->getPodman($context);
        $svc = 'docker';
        $svcname = 'Docker';
        $svcpath = '/lib/systemd/system/docker.service';
        if ($podman) {
            $svc = 'podman.socket';
            $svcname = 'Podman';
            $svcpath = '/lib/systemd/system/podman.socket';
        }
        // check to see if docker is installed and running
        if (file_exists($svcpath)) {
            $systemCtl = new \OMV\System\SystemCtl($svc);
            $running = $systemCtl->isActive();
            $status = $running ? gettext('running') : gettext('stopped');
        } else {
            $running = false;
            $status = gettext('not installed');
        }
        // get containers and status if docker is running
        $objects[] = [
            'image' => '',
            'name' => $svcname,
            'status' => $status
        ];
        if ($running) {
            $output = [];
            $cmdArgs = [];
            $cmdArgs[] = 'docker';
            $cmdArgs[] = 'container';
            $cmdArgs[] = 'ls';
            $cmdArgs[] = '--all';
            $cmdArgs[] = '--format "{{.Image}},{{.Names}},{{.Status}}"';
            $cmd = new \OMV\System\Process($cmdArgs);
            if ($podman) {
                $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
            }
            $cmd->execute($output, $exitStatus);
            foreach ($output as $cnt) {
                if (empty($cnt)) {
                    continue;
                }
                $parts = explode(',', $cnt);
                $objects[] = [
                    'image' => $parts[0],
                    'name' => $parts[1],
                    'status' => $parts[2]
                ];
            }
        }
        return ($objects);
    }

    public function getContainersTerm($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_EVERYONE]);
        $db = \OMV\Config\Database::getInstance();
        // get fqdn
        $fqdn = $this->getUrlHostname($context);
        // get cterm settings
        try {
            $cterm = $db->get("conf.service.cterm");
            // hmac
            if ($context['role'] == OMV_ROLE_ADMINISTRATOR) {
                $autouser = $cterm->get('autouser') ?: $context['username'];
            } else {
                $autouser = $context['username'];
            }
            $secret = trim(file_get_contents('/etc/omv_cterm.secret'));
            $ts = sprintf('%s', microtime(true));
            $userts = sprintf('%s:%s', $autouser, $ts);
            $hmac = hash_hmac('sha256', $userts, $secret);
            // get exec url
            $execurl = $this->getExecUrl($context, $db, $fqdn);
        } catch (Exception $e) {
            // cterm not installed
            $cterm = false;
        }
        // get containers and status if docker is running
        $output = [];
        $cmdArgs = [];
        $cmdArgs[] = 'docker';
        $cmdArgs[] = 'container';
        $cmdArgs[] = 'ls';
        $cmdArgs[] = '--format "{{.Names}}"';
        $cmd = new \OMV\System\Process($cmdArgs);
        $podman = $this->getPodman($context);
        if ($podman) {
            $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
            $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
        }
        $cmd->execute($output, $exitStatus);
        $objects = [];
        foreach ($output as $cnt) {
            if (empty($cnt)) {
                continue;
            }
            if (!$cterm || ($cterm && $cterm->get("enable") == 0)) {
                $url = gettext("disabled");
            } else {
                $url = sprintf('<a href="%s/%s?user=%s&hmac=%s&ts=%s" target="_blank">link</a>',
                  $execurl, $cnt, $autouser, $hmac, $ts);
            }
            $objects[] = [
                'name' => $cnt,
                'term' => $url
            ];
        }
        return ($objects);
    }

    // Build a map of volume name => list of container names that mount it.
    // Uses 'docker inspect' so named volumes are matched by name (the
    // '{{.Mounts}}' column of 'docker ps' only shows bind-mount sources and
    // truncates). Works for both docker and podman since the plugin always
    // drives the docker CLI, pointing DOCKER_HOST at the podman socket.
    private function getVolumeContainerMap($podman)
    {
        $map = [];
        $cmdArgs = [];
        $cmdArgs[] = 'docker ps -aq';
        $cmdArgs[] = '|';
        $cmdArgs[] = 'xargs -r docker inspect';
        $cmdArgs[] = '--format';
        $cmdArgs[] = '\'{{.Name}}|{{range .Mounts}}{{if eq .Type "volume"}}{{.Name}},{{end}}{{end}}\'';
        $cmd = new \OMV\System\Process($cmdArgs);
        if ($podman) {
            $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
            $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
        }
        $cmd->setQuiet(true);
        $output = [];
        $cmd->execute($output, $exitStatus);
        foreach ($output as $line) {
            if (empty($line) || strpos($line, '|') === false) {
                continue;
            }
            list($container, $volumes) = explode('|', $line, 2);
            // Container names are reported with a leading slash.
            $container = ltrim(trim($container), '/');
            if ($container === '') {
                continue;
            }
            foreach (array_filter(array_map('trim', explode(',', $volumes))) as $volume) {
                $map[$volume][] = $container;
            }
        }
        return $map;
    }

    // Return the authoritative list of volumes as [name, driver, mountpoint]
    // rows. 'docker volume ls' lists every volume, unlike 'docker system df'
    // which silently drops volumes it cannot size (e.g. an unmounted NFS/CIFS
    // volume), so this is used as the source of truth for the volume list.
    private function getVolumeList($podman)
    {
        $volumes = [];
        $cmdArgs = [];
        $cmdArgs[] = 'docker';
        $cmdArgs[] = 'volume';
        $cmdArgs[] = 'ls';
        $cmdArgs[] = '--format "{{.Name}}\t{{.Driver}}\t{{.Mountpoint}}"';
        $cmd = new \OMV\System\Process($cmdArgs);
        if ($podman) {
            $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
            $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
        }
        $cmd->setQuiet(true);
        $output = [];
        $cmd->execute($output, $exitStatus);
        foreach ($output as $line) {
            if (trim($line) === '') {
                continue;
            }
            $parts = explode("\t", $line);
            $volumes[] = [
                'name' => $parts[0] ?? '',
                'driver' => $parts[1] ?? '',
                'mountpoint' => $parts[2] ?? ''
            ];
        }
        return $volumes;
    }

    public function getVolumes($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        $objects = [];
        // Get configuration data.
        $db = \OMV\Config\Database::getInstance();
        // get cache time
        $settings = $db->get("conf.service.compose");
        $cacheTime = $settings->get('cachetimevolumes');
        $podman = $this->getPodman($context);
        // Check if cache file exists and is not older than cache setting
        if ($cacheTime > 0 && file_exists($this->cacheFileVolumes) &&
          (time() - filemtime($this->cacheFileVolumes)) < $cacheTime) {
            $data = json_decode(file_get_contents($this->cacheFileVolumes), true);
        } else {
            // Get images
            $cmdArgs = [];
            $cmdArgs[] = 'docker';
            $cmdArgs[] = 'system';
            $cmdArgs[] = 'df';
            $cmdArgs[] = '--verbose';
            $cmdArgs[] = '--format "json"';
            $cmd = new \OMV\System\Process($cmdArgs);
            if ($podman) {
                $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
            }
            $cmd->setQuiet(true);
            $output = [];
            $cmd->execute($output, $exitStatus);
            $outputJson = implode("", $output);
            if ($cacheTime > 0) {
                file_put_contents($this->cacheFileVolumes, $outputJson);
            }
            $data = json_decode($outputJson, true);
        }
        // 'docker system df' is the size source, but it omits volumes it cannot
        // size, so build a name => size lookup from it and use 'docker volume ls'
        // for the authoritative list. Volumes missing from df report no size.
        $sizeMap = [];
        foreach (($data['Volumes'] ?? []) as $volume) {
            $sizeMap[$volume['Name']] = $volume['Size'];
        }
        // Map each volume to the containers that mount it. This is queried
        // live (not cached with the disk-usage data) so associations stay
        // current even when volume sizes are served from cache.
        $containerMap = $this->getVolumeContainerMap($podman);
        $volumesAssoc = [];
        foreach ($this->getVolumeList($podman) as $volume) {
            $name = $volume['name'];
            $containers = $containerMap[$name] ?? [];
            $volumesAssoc[] = [
                "name" => $name,
                "size" => isset($sizeMap[$name]) ? $this->convertToBytes($sizeMap[$name]) : null,
                "mountpoint" => $volume['mountpoint'],
                "driver" => $volume['driver'],
                "containers" => implode(', ', $containers)
            ];
        }
        // Filter the result.
        return $this->applyFilter($volumesAssoc, $params['start'], $params['limit'],
            $params['sortfield'], $params['sortdir'], $params['search']);
    }

    public function getVolumesBg($params, $context) {
        return $this->callMethodBg("getVolumes", $params, $context);
    }

    public function doDockerVolumeCmd($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // clear cache for volumes
        $this->clearCache('volumes');
        $podman = $this->getPodman($context);
        $showCmd = $this->getShowCmd($context);
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($params, $showCmd, $podman) {
                $cmdArgs = [];
                $cmdArgs[] = 'docker';
                $cmdArgs[] = 'volume';
                $cmdArgs[] = $params['command'];
                $cmdArgs[] = $params['name'];
                $cmdArgs = array_filter($cmdArgs);
                $cmd = new \OMV\System\Process($cmdArgs);
                if ($podman) {
                    $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                    $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
                }
                $cmd->setRedirect2to1();
                $cmdLine = $cmd->getCommandLine();
                if ($showCmd) file_put_contents($bgOutputFilename, $cmdLine . PHP_EOL . PHP_EOL, FILE_APPEND);
                if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                    throw new \OMV\ExecException($cmdLine, $output);
                }
                return $output;
            }
        );
    }

    public function setVolume($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // clear cache for volumes
        $this->clearCache('volumes');
        $podman = $this->getPodman($context);
        $driver = !empty($params['driver']) ? $params['driver'] : 'local';
        $advanced = !empty($params['advanced']);
        $cmdArgs = [];
        $cmdArgs[] = 'docker';
        $cmdArgs[] = 'volume';
        $cmdArgs[] = 'create';
        $cmdArgs[] = '--driver ' . escapeshellarg($driver);
        if ($advanced) {
            $mountType = $params['mounttype'] ?? 'none';
            if ($mountType !== '' && $mountType !== 'none') {
                $cmdArgs[] = '--opt ' . escapeshellarg('type=' . $mountType);
                if (!empty($params['device'])) {
                    $cmdArgs[] = '--opt ' . escapeshellarg('device=' . $params['device']);
                }
                if (!empty($params['mountoptions'])) {
                    $cmdArgs[] = '--opt ' . escapeshellarg('o=' . $params['mountoptions']);
                }
            }
            if (!empty($params['driveropts'])) {
                $opts = explode(',', $params['driveropts']);
                foreach ($opts as $entry) {
                    $entry = trim($entry);
                    if ($entry !== '') {
                        $cmdArgs[] = '--opt ' . escapeshellarg($entry);
                    }
                }
            }
            if (!empty($params['labels'])) {
                $labels = explode(',', $params['labels']);
                foreach ($labels as $label) {
                    $label = trim($label);
                    if ($label !== '') {
                        $cmdArgs[] = '--label ' . escapeshellarg($label);
                    }
                }
            }
        }
        $cmdArgs[] = escapeshellarg($params['name']);
        $cmd = new \OMV\System\Process($cmdArgs);
        if ($podman) {
            $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
            $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
        }
        $cmd->setRedirect2to1();
        $cmd->execute($output, $exitStatus);
        return $output;
    }

    // Create a host directory for use as a bind mount, optionally setting its
    // ownership and permissions. This is host filesystem prep (mkdir/chown/chmod),
    // not a Docker volume; bind mounts never appear in 'docker volume ls'.
    public function createBindPath($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Resolve the target path from either an absolute path or a shared
        // folder plus a relative subdirectory.
        $source = $params['source'] ?? 'sharedfolder';
        if ($source === 'absolute') {
            $path = trim($params['abspath'] ?? '');
            if ($path === '') {
                throw new \OMV\Exception(gettext("Please provide an absolute path."));
            }
        } else {
            $sfref = $params['sharedfolderref'] ?? '';
            if (!is_uuid($sfref)) {
                throw new \OMV\Exception(gettext("Please select a shared folder."));
            }
            $sfpath = \OMV\Rpc\Rpc::call("ShareMgmt", "getPath", ["uuid" => $sfref], $context);
            $sfpath = rtrim($sfpath, '/');
            $rel = ltrim(trim($params['relpath'] ?? ''), '/');
            $path = ($rel === '') ? $sfpath : $sfpath . '/' . $rel;
        }
        // The path must be absolute and free of traversal components.
        if (substr($path, 0, 1) !== '/') {
            throw new \OMV\Exception(gettext("The path must be absolute."));
        }
        if (strpos($path, '/../') !== false || substr($path, -3) === '/..'
          || $path === '..') {
            throw new \OMV\Exception(gettext("The path must not contain '..' components."));
        }
        // Collapse duplicate and trailing slashes.
        $path = rtrim(preg_replace('#/+#', '/', $path), '/');
        if ($path === '') {
            $path = '/';
        }
        // Refuse to operate on critical system locations. A recursive chmod/chown
        // here as root could render the host unbootable.
        $protected = ['/', '/bin', '/boot', '/dev', '/etc', '/lib', '/lib32',
            '/lib64', '/libx32', '/proc', '/root', '/run', '/sbin', '/sys',
            '/usr', '/var'];
        foreach ($protected as $p) {
            if ($path === $p || ($p !== '/' && strpos($path . '/', $p . '/') === 0)) {
                throw new \OMV\Exception(sprintf(
                    gettext("Refusing to operate on the protected system path '%s'."),
                    $path));
            }
        }
        // Validate ownership and mode inputs (both optional).
        $owner = trim($params['owner'] ?? '');
        $group = trim($params['group'] ?? '');
        foreach (['owner' => $owner, 'group' => $group] as $key => $value) {
            if ($value !== '' && !preg_match('/^[A-Za-z0-9_][A-Za-z0-9_.-]*$/', $value)) {
                throw new \OMV\Exception(sprintf(
                    gettext("Invalid %s name."), $key));
            }
        }
        $mode = trim($params['mode'] ?? '');
        if ($mode !== '' && !preg_match('/^[0-7]{3,4}$/', $mode)) {
            throw new \OMV\Exception(gettext("Permissions must be an octal value, e.g. 755."));
        }
        $recursive = !empty($params['recursive']);
        // Create the directory if it does not exist yet.
        $created = false;
        if (!file_exists($path)) {
            if (!mkdir($path, 0777, true)) {
                throw new \OMV\Exception(sprintf(
                    gettext("Failed to create directory '%s'."), $path));
            }
            $created = true;
        } elseif (!is_dir($path)) {
            throw new \OMV\Exception(sprintf(
                gettext("'%s' already exists and is not a directory."), $path));
        }
        // Apply ownership. Omitting execute()'s exit-status argument makes the
        // process throw on failure, so errors surface to the caller.
        $output = [];
        if ($owner !== '' || $group !== '') {
            $spec = $owner;
            if ($group !== '') {
                $spec .= ':' . $group;
            }
            $cmdArgs = ['chown'];
            if ($recursive) {
                $cmdArgs[] = '-R';
            }
            $cmdArgs[] = $spec;
            $cmdArgs[] = $path;
            $cmd = new \OMV\System\Process($cmdArgs);
            $cmd->setRedirect2to1();
            $cmd->execute($output);
        }
        // Apply permissions.
        if ($mode !== '') {
            $cmdArgs = ['chmod'];
            if ($recursive) {
                $cmdArgs[] = '-R';
            }
            $cmdArgs[] = $mode;
            $cmdArgs[] = $path;
            $cmd = new \OMV\System\Process($cmdArgs);
            $cmd->setRedirect2to1();
            $cmd->execute($output);
        }
        return [
            'path' => $path,
            'created' => $created,
        ];
    }

    public function getNetworks($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        $objects = [];
        // get cache time
        $db = \OMV\Config\Database::getInstance();
        $settings = $db->get("conf.service.compose");
        $cacheTime = $settings->get('cachetimenetworks');
        $podman = $this->getPodman($context);
        // Check if cache file exists and is not older than cache setting
        $output = [];
        if ($cacheTime > 0 && file_exists($this->cacheFileNetworks) &&
          (time() - filemtime($this->cacheFileNetworks)) < $cacheTime) {
            $output = json_decode(file_get_contents($this->cacheFileNetworks), true);
        } else {
            // Get networks
            $cmdArgs = [];
            $cmdArgs[] = 'docker';
            $cmdArgs[] = 'network';
            $cmdArgs[] = 'ls';
            if ($podman) {
                $cmdArgs[] = '--format "{{json .}}"';
            } else {
                $cmdArgs[] = '--format "json"';
            }
            $cmd = new \OMV\System\Process($cmdArgs);
            if ($podman) {
                $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
            }
            $cmd->setQuiet(true);
            $output = [];
            $cmd->execute($output, $exitStatus);
            if ($cacheTime > 0) {
                file_put_contents($this->cacheFileNetworks, json_encode($output));
            }
        }
        $networksAssoc = [];
        foreach ($output as $network) {
            $networkJson = json_decode($network);
            $networksAssoc[] = [
                "name" => $networkJson->Name ?? $networkJson->name,
                "driver" => $networkJson->Driver ?? $networkJson->driver,
                "subnet" => "",
                "gateway" => "",
                "parent" => "",
                "mode" => "",
                "containers" => []
            ];
        }
        $networkNames = array_column($networksAssoc, 'name');
        $networkInspect = $this->inspectNetworks($networkNames, $podman, $cacheTime);
        // Build network -> containers map.
        $networkContainers = [];
        $containerLines = [];
        if (file_exists($this->cacheFileContainers)) {
            $containerLines = json_decode(file_get_contents($this->cacheFileContainers), true) ?? [];
        } else {
            $psArgs = ['docker', 'container', 'ls', '--all', '--no-trunc'];
            if ($podman) {
                $psArgs[] = '--format "{{json .}}"';
            } else {
                $psArgs[] = '--format "json"';
            }
            $psCmd = new \OMV\System\Process($psArgs);
            if ($podman) {
                $psCmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                $psCmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
            }
            $psCmd->setQuiet(true);
            $psCmd->execute($containerLines, $psExitStatus);
        }
        $containers = [];
        foreach ($containerLines as $line) {
            $decoded = json_decode($line);
            if ($decoded === null) continue;
            if (is_array($decoded)) {
                foreach ($decoded as $item) {
                    if (is_object($item)) $containers[] = $item;
                }
            } elseif (is_object($decoded)) {
                $containers[] = $decoded;
            }
        }
        foreach ($containers as $container) {
            // podman returns Names as an array; docker returns a string.
            $cname = $container->Names ?? $container->Name ?? $container->names ?? '';
            if (is_array($cname)) {
                $cname = $cname[0] ?? '';
            }
            if ($cname === '') {
                continue;
            }
            // podman returns Networks as an array; docker as a comma-separated string.
            $nets = $container->Networks ?? $container->networks ?? '';
            if (is_array($nets)) {
                $netList = $nets;
            } elseif (is_string($nets) && $nets !== '') {
                $netList = explode(',', $nets);
            } else {
                $netList = [];
            }
            foreach ($netList as $net) {
                $net = trim((string) $net);
                if ($net !== '') {
                    $networkContainers[$net][] = $cname;
                }
            }
        }
        foreach ($networksAssoc as &$network) {
            $info = $networkInspect[$network['name']] ?? null;
            $network['subnet'] = $info['subnet'] ?? '';
            $network['gateway'] = $info['gateway'] ?? '';
            $network['parent'] = $info['parent'] ?? '';
            $network['mode'] = $info['mode'] ?? '';
            $ips = $info['ips'] ?? [];
            $names = $networkContainers[$network['name']] ?? [];
            foreach (array_keys($ips) as $inspectName) {
                if (!in_array($inspectName, $names, true)) {
                    $names[] = $inspectName;
                }
            }
            $list = [];
            foreach ($names as $cname) {
                $ip = $ips[$cname] ?? '';
                $list[] = ($ip !== '') ? sprintf('%s (%s)', $cname, $ip) : $cname;
            }
            $network['containers'] = $list;
        }
        unset($network);
        // Filter the result.
        return $this->applyFilter($networksAssoc, $params['start'], $params['limit'],
            $params['sortfield'], $params['sortdir'], $params['search']);
    }

    public function getNetworksBg($params, $context)
    {
        return $this->callMethodBg("getNetworks", $params, $context);
    }

    private function inspectNetworks($names, $podman, $cacheTime)
    {
        $result = [];
        if (empty($names)) {
            return $result;
        }
        $lines = [];
        if ($cacheTime > 0 && file_exists($this->cacheFileNetworksInspect) &&
          (time() - filemtime($this->cacheFileNetworksInspect)) < $cacheTime) {
            $lines = json_decode(file_get_contents($this->cacheFileNetworksInspect), true) ?? [];
        } else {
            $cmdArgs = ['docker', 'network', 'inspect'];
            foreach ($names as $name) {
                $cmdArgs[] = escapeshellarg($name);
            }
            $cmdArgs[] = '--format "{{json .}}"';
            $cmd = new \OMV\System\Process($cmdArgs);
            if ($podman) {
                $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
            }
            $cmd->setQuiet(true);
            $cmd->execute($lines, $exitStatus);
            if ($cacheTime > 0) {
                file_put_contents($this->cacheFileNetworksInspect, json_encode($lines));
            }
        }
        foreach ($lines as $line) {
            $net = json_decode($line);
            if (!is_object($net)) {
                continue;
            }
            $name = $net->Name ?? $net->name ?? '';
            if ($name === '') {
                continue;
            }
            $subnets = [];
            $gateways = [];
            // docker: IPAM.Config[] {Subnet, Gateway}
            // podman: subnets[] {subnet, gateway}
            $ipamConfig = $net->IPAM->Config ?? $net->subnets ?? [];
            if (is_array($ipamConfig)) {
                foreach ($ipamConfig as $cfg) {
                    $sub = $cfg->Subnet ?? $cfg->subnet ?? '';
                    $gw = $cfg->Gateway ?? $cfg->gateway ?? '';
                    if ($sub !== '') {
                        $subnets[] = $sub;
                    }
                    if ($gw !== '') {
                        $gateways[] = $gw;
                    }
                }
            }
            $ips = [];
            // docker: Containers{} {Name, IPv4Address}
            // podman: containers{} {name, interfaces{} {subnets[] {ipnet}}}
            $containers = $net->Containers ?? $net->containers ?? null;
            if (is_object($containers)) {
                foreach ($containers as $c) {
                    $cname = $c->Name ?? $c->name ?? '';
                    if ($cname === '') {
                        continue;
                    }
                    $addr = $c->IPv4Address ?? '';
                    if ($addr === '' && isset($c->interfaces)) {
                        foreach ((array) $c->interfaces as $iface) {
                            $ifSubnets = $iface->subnets ?? [];
                            if (is_array($ifSubnets)) {
                                foreach ($ifSubnets as $s) {
                                    if (!empty($s->ipnet)) {
                                        $addr = $s->ipnet;
                                        break 2;
                                    }
                                }
                            }
                        }
                    }
                    // Strip the CIDR suffix (e.g. "172.19.0.2/16") for display.
                    if ($addr !== '') {
                        $addr = explode('/', $addr)[0];
                    }
                    $ips[$cname] = $addr;
                }
            }
            // docker: Options{} {parent, macvlan_mode, ipvlan_mode}
            // podman: options{} {mode}, with the parent as a top-level field.
            $options = $net->Options ?? $net->options ?? null;
            $parent = '';
            $mode = '';
            if (is_object($options)) {
                $parent = $options->parent ?? '';
                $mode = $options->macvlan_mode ?? $options->ipvlan_mode ??
                    $options->mode ?? '';
            }
            // podman exposes the macvlan/ipvlan parent as 'network_interface'
            // rather than an option.
            if ($parent === '') {
                $parent = $net->network_interface ?? $net->NetworkInterface ?? '';
            }
            $result[$name] = [
                'subnet' => implode('<br>', $subnets),
                'gateway' => implode('<br>', $gateways),
                'parent' => $parent,
                'mode' => $mode,
                'ips' => $ips,
            ];
        }
        return $result;
    }

    function enumerateNetworkList($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // Get the system network interface devices.
        $objects = \OMV\Rpc\Rpc::call('Network', 'enumerateDevices', NULL, $context);
        $devices = [];
        foreach ($objects as $device) {
            $devices[] = $device['devicename'];
        }
        sort($devices);
        $devicesf = array_diff($devices, ['lo']);
        // Filter the result.
        return $this->applyFilter($devicesf, $params['start'],
            $params['limit'], $params['sortfield'], $params['sortdir']);
    }

    public function doDockerNetworkCmd($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // clear cache for networks
        $this->clearCache('networks');
        $podman = $this->getPodman($context);
        $showCmd = $this->getShowCmd($context);
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($params, $showCmd, $podman) {
                $cmdArgs = [];
                $cmdArgs[] = 'docker';
                $cmdArgs[] = 'network';
                $cmdArgs[] = $params['command'];
                $cmdArgs[] = $params['name'];
                $cmdArgs = array_filter($cmdArgs);
                $cmd = new \OMV\System\Process($cmdArgs);
                if ($podman) {
                    $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                    $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
                }
                $cmd->setRedirect2to1();
                $cmdLine = $cmd->getCommandLine();
                if ($showCmd) file_put_contents($bgOutputFilename, $cmdLine . PHP_EOL . PHP_EOL, FILE_APPEND);
                if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                    throw new \OMV\ExecException($cmdLine, $output);
                }
                return $output;
            }
        );
    }

    public function doNetworkConnect($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // clear cache for networks
        $this->clearCache('networks');
        $podman = $this->getPodman($context);
        // command is either 'connect' or 'disconnect'.
        $command = ($params['command'] == 'disconnect') ? 'disconnect' : 'connect';
        $cmdArgs = [];
        $cmdArgs[] = 'docker';
        $cmdArgs[] = 'network';
        $cmdArgs[] = $command;
        if ($command == 'connect' && !empty($params['ipaddress'])) {
            $cmdArgs[] = sprintf("--ip=%s", $params['ipaddress']);
        }
        $cmdArgs[] = $params['name'];
        $cmdArgs[] = $params['container'];
        $cmd = new \OMV\System\Process($cmdArgs);
        if ($podman) {
            $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
            $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
        }
        $cmd->setRedirect2to1();
        $cmd->execute($output, $exitStatus);
        return $output;
    }

    public function setNetwork($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // clear cache for networks
        $this->clearCache('networks');
        $driver = $params['driver'];
        $internal = !empty($params['internal']);
        $podman = $this->getPodman($context);
        // Get networks
        $cmdArgs = [];
        $cmdArgs[] = 'docker';
        $cmdArgs[] = 'network';
        $cmdArgs[] = 'create';
        $cmdArgs[] = '--driver ' . escapeshellarg($driver);
        if ($internal && in_array($driver, ['bridge', 'overlay'], true)) {
            $cmdArgs[] = '--internal';
        }
        if (in_array($driver, ['macvlan', 'ipvlan'], true) && !empty($params['parentnetwork'])) {
            $cmdArgs[] = '--opt ' . escapeshellarg('parent=' . $params['parentnetwork']);
        }
        // The macvlan/ipvlan mode option key differs between runtimes:
        // docker uses macvlan_mode/ipvlan_mode, podman (netavark) uses mode.
        // Passing the wrong key makes podman reject the whole create.
        $mode = '';
        if ($driver == 'macvlan' && !empty($params['macvlanmode'])) {
            $mode = $params['macvlanmode'];
        } elseif ($driver == 'ipvlan' && !empty($params['ipvlanmode'])) {
            $mode = $params['ipvlanmode'];
        }
        if ($mode !== '') {
            if ($podman) {
                $cmdArgs[] = '--opt ' . escapeshellarg('mode=' . $mode);
            } else {
                $cmdArgs[] = '--opt ' . escapeshellarg(sprintf('%s_mode=%s', $driver, $mode));
            }
        }
        if (!empty($params['ipv6'])) {
            $cmdArgs[] = '--ipv6';
        }
        if ($params['subnet']) {
            $cmdArgs[] = '--subnet=' . escapeshellarg($params['subnet']);
        }
        if ($params['gateway']) {
            $cmdArgs[] = '--gateway=' . escapeshellarg($params['gateway']);
        }
        if (!empty($params['subnet6'])) {
            $cmdArgs[] = '--subnet=' . escapeshellarg($params['subnet6']);
        }
        if (!empty($params['gateway6'])) {
            $cmdArgs[] = '--gateway=' . escapeshellarg($params['gateway6']);
        }
        if ($params['iprange']) {
            $cmdArgs[] = '--ip-range=' . escapeshellarg($params['iprange']);
        }
        if ($params['auxaddress']) {
            $aux = explode(',', $params['auxaddress']);
            foreach ($aux as $entry) {
                $cmdArgs[] = '--aux-address=' . escapeshellarg(trim($entry));
            }
        }
        $cmdArgs[] = escapeshellarg($params['name']);
        $cmd = new \OMV\System\Process($cmdArgs);
        if ($podman) {
            $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
            $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
        }
        $cmd->setRedirect2to1();
        $cmd->execute($output, $exitStatus);
        return $output;
    }

    public function getImages($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        $skipStatus = \OMV\Environment::getBoolean('OMV_COMPOSE_SKIP_IMAGE_STATUS', false);
        if (!file_exists($this->regctl)) {
            $skipStatus = true;
        }
        // get cache time
        $db = \OMV\Config\Database::getInstance();
        $settings = $db->get("conf.service.compose");
        $podman = $this->getPodman($context);
        $cacheTime = $settings->get('cachetimeimages');
        $cacheFileContainers = sprintf('%s_containers.json', $this->cacheFileImages);
        $cacheFileImages = sprintf('%s_images.json', $this->cacheFileImages);
        // Get container images
        $containerImages = [];
        if ($cacheTime > 0 && file_exists($cacheFileContainers) &&
          (time() - filemtime($cacheFileContainers)) < $cacheTime) {
            $containerImages = json_decode(file_get_contents($cacheFileContainers), true);
        } else {
            $cmdArgs = [];
            $cmdArgs[] = 'docker';
            $cmdArgs[] = 'container';
            $cmdArgs[] = 'ls';
            $cmdArgs[] = '--all';
            $cmdArgs[] = '--no-trunc';
            $cmdArgs[] = '--quiet';
            // one inspect call for all containers: image id + compose project
            $cmdArgs[] = '| xargs --no-run-if-empty docker inspect --format ' .
                '\'{{.Image}} {{index .Config.Labels "com.docker.compose.project"}}\'';
            $cmd = new \OMV\System\Process($cmdArgs);
            if ($podman) {
                $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
            }
            $cmd->execute($containerImages, $exitStatus);
            $containerImages = array_filter($containerImages);
            if ($cacheTime > 0) {
                file_put_contents($cacheFileContainers, json_encode($containerImages));
            }
        }
        // map image id => compose projects using it
        $containerImageSet = [];
        foreach ($containerImages as $line) {
            $parts = explode(' ', trim($line), 2);
            $imgId = $parts[0];
            if ($imgId === '') {
                continue;
            }
            if (!isset($containerImageSet[$imgId])) {
                $containerImageSet[$imgId] = [];
            }
            $project = trim($parts[1] ?? '');
            if ($project !== '') {
                $containerImageSet[$imgId][$project] = true;
            }
        }
        // Get images
        $output = [];
        if ($cacheTime > 0 && file_exists($cacheFileImages) &&
          (time() - filemtime($cacheFileImages)) < $cacheTime) {
            $output = json_decode(file_get_contents($cacheFileImages), true);
        } else {
            $cmdArgs = [];
            $cmdArgs[] = 'docker';
            $cmdArgs[] = 'image';
            $cmdArgs[] = 'ls';
            $cmdArgs[] = '--all';
            $cmdArgs[] = '--digests';
            $cmdArgs[] = '--no-trunc';
            if ($podman) {
                $cmdArgs[] = '--format "{{json .}}"';
            } else {
                $cmdArgs[] = '--format "json"';
            }
            $cmd = new \OMV\System\Process($cmdArgs);
            if ($podman) {
                $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
            }
            $cmd->setQuiet(true);
            $output = [];
            $cmd->execute($output, $exitStatus);
            if ($cacheTime > 0) {
                file_put_contents($cacheFileImages, json_encode($output));
            }
        }
        // group images with same name and tag
        $grouped = [];
        foreach ($output as $image) {
            $imageJson = json_decode($image);
            $repo = $podman ? $imageJson->repository : $imageJson->Repository;
            $tag = $podman ? $imageJson->tag : $imageJson->Tag;
            $key = "{$repo}:{$tag}";
            if (!isset($grouped[$key])) {
                $grouped[$key] = [
                    "repo" => $repo,
                    "tag" => $tag,
                    "digests_raw" => [],
                    "ids_raw" => [],
                    "inuse" => false,
                    "projects" => [],
                    "createat" => $imageJson->CreatedAt ?? $imageJson->Created,
                    "createsince" => $imageJson->CreatedSince,
                    "size" => 0,
                    "virtualsize" => 0
                ];
            }
            $grouped[$key]['digests_raw'][] = $imageJson->Digest;
            $imageId = $imageJson->ID ?? $imageJson->Id ?? '';
            $grouped[$key]['ids_raw'][] = $imageId;
            $grouped[$key]['inuse'] = $grouped[$key]['inuse'] || isset($containerImageSet[$imageId]);
            if (isset($containerImageSet[$imageId])) {
                $grouped[$key]['projects'] += $containerImageSet[$imageId];
            }
            // show largest size and virtualsize
            $grouped[$key]['size'] = isset($grouped[$key]['size'])
                ? max($grouped[$key]['size'], $this->convertToBytes($imageJson->Size))
                : $this->convertToBytes($imageJson->Size);
            $grouped[$key]['virtualsize'] = isset($grouped[$key]['virtualsize'])
                ? max($grouped[$key]['virtualsize'], $this->convertToBytes($imageJson->VirtualSize))
                : $this->convertToBytes($imageJson->VirtualSize);
        }
        // add image status, deduplicate id and digest, format multi-line entries
        $imagesAssoc = [];
        foreach ($grouped as $entry) {
            $digests = array_unique($entry['digests_raw']);
            $status = $skipStatus ? 'NA' :
                $this->getImageStatus($entry['repo'], $entry['tag'], $digests);
            $ids = array_values(array_unique(array_filter($entry['ids_raw'])));
            $hasRepo = !in_array($entry['repo'], ['', '<none>'], true);
            $tagged = $hasRepo && !in_array($entry['tag'], ['', '<none>'], true);
            // pull the tag (or digest) in use, never fall back to :latest
            $pullref = '';
            if ($tagged) {
                $pullref = "{$entry['repo']}:{$entry['tag']}";
            } elseif ($hasRepo) {
                $pinned = array_values(array_filter($digests,
                    fn($d) => is_string($d) && strpos($d, 'sha256:') === 0));
                if (count($pinned) === 1) {
                    $pullref = "{$entry['repo']}@{$pinned[0]}";
                }
            }
            $projects = array_keys($entry['projects']);
            sort($projects, SORT_NATURAL | SORT_FLAG_CASE);
            $imagesAssoc[] = [
                "id" => implode('<br/>', $ids),
                "ids" => implode(',', $ids),
                // remove/inspect/tag by name so other tags of the image are kept
                "ref" => $tagged ? "{$entry['repo']}:{$entry['tag']}" : implode(',', $ids),
                "pullref" => $pullref,
                "repo" => $entry['repo'],
                "createat" => $entry['createat'],
                "createsince" => $entry['createsince'],
                "size" => $entry['size'],
                "tag" => $entry['tag'],
                "digest" => implode('<br/>', $digests),
                "status" => $status,
                "virtualsize" => $entry['virtualsize'],
                "inuse" => $entry['inuse'],
                "projects" => implode(',', $projects)
            ];
        }
        // Filter the result.
        return $this->applyFilter($imagesAssoc, $params['start'], $params['limit'],
            $params['sortfield'], $params['sortdir'], $params['search']);
    }

    private function execWithTimeout(string $cmdLine, array &$output, int $timeout): int
    {
        $process = proc_open($cmdLine, [0 => ['pipe', 'r'], 1 => ['pipe', 'w']], $pipes);
        if (!is_resource($process)) {
            return 1;
        }
        fclose($pipes[0]);
        stream_set_blocking($pipes[1], false);
        $stdout = '';
        $deadline = microtime(true) + $timeout;
        $timedOut = false;
        while (true) {
            $status = proc_get_status($process);
            $stdout .= fread($pipes[1], 8192);
            if (!$status['running']) {
                $exitStatus = $status['exitcode'];
                break;
            }
            if (microtime(true) >= $deadline) {
                proc_terminate($process, 9);
                $exitStatus = 124;
                $timedOut = true;
                break;
            }
            usleep(50000);
        }
        if (!$timedOut) {
            $stdout .= stream_get_contents($pipes[1]);
        }
        fclose($pipes[1]);
        proc_close($process);
        if (!empty($stdout)) {
            $lines = explode("\n", rtrim($stdout, "\n"));
            array_push($output, ...$lines);
        }
        return $exitStatus;
    }

    private function getImageStatus($img, $tag, $digests)
    {
        if ($img == "<none>" || $tag == "<none>" || empty($digests) ||
            strlen($img) == 0 || strlen($tag) == 0) {
            return 'NA';
        }
        $allNone = true;
        foreach ($digests as $d) {
            if ($d !== '<none>' && strlen($d) > 0) {
                $allNone = false;
                break;
            }
        }
        if ($allNone) {
            return 'NA';
        }
        // get database
        $db = \OMV\Config\Database::getInstance();
        $settings = $db->get("conf.service.compose");
        // get cache time
        $cacheTime = $settings->get('cachetimeimages');
        $iname = sprintf('%s_%s', str_replace('/', '_', $img), $tag);
        $cacheFile = sprintf('%s_%s.json', $this->cacheFileImages, $iname);
        // get latest digest from image's registry
        $exitStatus = 0;
        if ($cacheTime > 0 && file_exists($cacheFile) &&
          (time() - filemtime($cacheFile)) < $cacheTime) {
            $output = json_decode(file_get_contents($cacheFile), true);
        } else {
            $cmdArgs = [];
            $cmdArgs[] = 'image';
            $cmdArgs[] = 'digest';
            $cmdArgs[] = '--list';
            if (strlen($tag) > 0) {
                $cmdArgs[] = sprintf('"%s:%s"', $img, $tag);
            } else {
                $cmdArgs[] = sprintf('"%s"', $img);
            }
            $output = [];
            $cmd = new \OMV\System\Process($this->regctl, $cmdArgs);
            $exitStatus = $this->execWithTimeout($cmd->getCommandLine(), $output, 10);
            if ($cacheTime > 0) {
                file_put_contents($cacheFile, json_encode($output));
            }
        }
        // determine status
        if ($exitStatus === 124) {
            return 'TIMEOUT';
        }
        if ($exitStatus > 0 || empty($output)) {
            return 'FAILED';
        }
        $latestDigest = trim(implode('', $output));
        if (empty($latestDigest)) {
            return 'FAILED';
        }
        // if any digest is current, return current
        foreach ($digests as $digest) {
            if ($digest === $latestDigest) {
                return 'CURRENT';
            }
        }
        return 'AVAILABLE';
    }

    public function getImagesBg($params, $context) {
        return $this->callMethodBg("getImages", $params, $context);
    }

    // Split an image list from the images tab. Grouped rows join ids with
    // commas (older pages joined them with <br/>).
    private function splitImageIds($ids): array
    {
        $parts = array_map('trim', preg_split('/,|<br\/>/', (string)$ids));
        return array_values(array_unique(array_filter($parts, 'strlen')));
    }

    public function doDockerImageCmd($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        $command = $params['command'] ?? '';
        if (!in_array($command, ['rm', 'inspect', 'pull'], true)) {
            throw new \OMV\Exception(sprintf(
                gettext("Invalid image command '%s'."), $command));
        }
        $ids = $this->splitImageIds($params['id'] ?? '');
        if (empty($ids)) {
            throw new \OMV\Exception(gettext("No image specified."));
        }
        // clear cache for images
        $this->clearCache('images');
        $podman = $this->getPodman($context);
        $showCmd = $this->getShowCmd($context);
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($command, $ids, $showCmd, $podman) {
                // docker image pull takes a single image, so pull one at a time
                if ('pull' === $command) {
                    $allOutput = [];
                    $failed = [];
                    foreach ($ids as $id) {
                        $cmd = new \OMV\System\Process(['docker', 'image', 'pull',
                            escapeshellarg($id)]);
                        if ($podman) {
                            $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                            $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
                        }
                        $cmd->setRedirect2to1();
                        $cmdLine = $cmd->getCommandLine();
                        if ($showCmd) file_put_contents($bgOutputFilename, $cmdLine . PHP_EOL . PHP_EOL, FILE_APPEND);
                        $output = [];
                        $exitStatus = $this->exec($cmdLine, $output, $bgOutputFilename);
                        $allOutput = array_merge($allOutput, $output);
                        if (0 !== $exitStatus) {
                            $failed[] = $id;
                        }
                        file_put_contents($bgOutputFilename, PHP_EOL, FILE_APPEND);
                    }
                    // drop images cached by a refresh while the pulls ran
                    $this->clearCache('images');
                    if (!empty($failed)) {
                        throw new \OMV\Exception(sprintf(
                            gettext("Failed to pull: %s"), implode(', ', $failed)));
                    }
                    return $allOutput;
                }
                $cmdArgs = [];
                $cmdArgs[] = 'docker';
                $cmdArgs[] = 'image';
                $cmdArgs[] = $command;
                $cmdArgs = array_merge($cmdArgs, array_map('escapeshellarg', $ids));
                $cmd = new \OMV\System\Process($cmdArgs);
                if ($podman) {
                    $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
                    $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
                }
                $cmd->setRedirect2to1();
                $cmdLine = $cmd->getCommandLine();
                if ($showCmd) file_put_contents($bgOutputFilename, $cmdLine . PHP_EOL . PHP_EOL, FILE_APPEND);
                $exitStatus = $this->exec($cmdLine, $output, $bgOutputFilename);
                // drop images cached by a refresh while the command ran
                $this->clearCache('images');
                if (0 !== $exitStatus) {
                    throw new \OMV\ExecException($cmdLine, $output);
                }
                return $output;
            }
        );
    }

    public function getRestoreList($params, $context)
    {
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);

        $sfpath = $this->getBackupPath($context);
        $dirs = array_diff(scandir($sfpath), ["..", "."]);
        $objects = [];

        foreach ($dirs as $dir) {
            $volList = sprintf("%s/%s/vol.list", $sfpath, $dir);
            if (!file_exists($volList)) {
                continue;
            }

            // Default size fallback (compose-level)
            $spaceUsed = sprintf("%s/%s/space.used", $sfpath, $dir);
            $backupSizeDefault = -1;
            if (file_exists($spaceUsed)) {
                $backupSizeDefault = (int) trim((string) file_get_contents($spaceUsed));
            }

            $history = sprintf("%s/%s/vol.list.history", $sfpath, $dir);
            $timestamps = [];
            $repoBytesByTs = [];

            if (file_exists($history)) {
                $lines = @file($history, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                if (is_array($lines) && count($lines) > 0) {

                    $tsSet = [];

                    foreach ($lines as $ln) {
                        // Two supported formats:
                        //  1) ts,volnum,borg,archive
                        //  2) ts,repo_bytes,<bytes>
                        $parts = explode(",", $ln);

                        if (count($parts) >= 3 && trim($parts[1]) === "repo_bytes") {
                            $ts = trim($parts[0]);
                            $bytes = (int) trim($parts[2]);
                            if ($ts !== "") {
                                $repoBytesByTs[$ts] = $bytes;
                            }
                            continue;
                        }

                        if (count($parts) >= 4) {
                            $ts = trim($parts[0]);
                            $backend = trim($parts[2]);
                            if ($ts === "" || $backend !== "borg") {
                                continue;
                            }
                            $tsSet[$ts] = true;
                        }
                    }

                    if (count($tsSet) > 0) {
                        $timestamps = array_keys($tsSet);
                        rsort($timestamps, SORT_STRING); // newest first
                    }
                }
            }

            if (count($timestamps) > 0) {
                // History-driven list (prevents duplicate "latest" row)
                $first = true;
                foreach ($timestamps as $ts) {
                    $display = str_replace("_", " ", $ts);
                    $display = preg_replace('/(\d{2})-(\d{2})-(\d{2})$/', '$1:$2:$3', $display);

                    $size = $backupSizeDefault;
                    if (array_key_exists($ts, $repoBytesByTs)) {
                        $size = $repoBytesByTs[$ts];
                    }

                    $objects[] = [
                        'backup'     => $dir,
                        'backupsize' => $size,
                        'time'       => $display,
                        'snapshot'   => $ts,
                        'islatest'   => $first,
                    ];
                    $first = false;
                }
            } else {
                // No usable history => legacy behavior
                $latestTime = date("Y-m-d H:i:s", filemtime($volList));
                $objects[] = [
                    'backup'     => $dir,
                    'backupsize' => $backupSizeDefault,
                    'time'       => $latestTime,
                    'snapshot'   => '',     // empty = latest
                    'islatest'   => true,
                ];
            }
        }

        return $objects;
    }

    public function doRestore($params, $context)
    {
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
          use ($params) {
            $cmdArgs = [];
            $cmdArgs[] = '/usr/sbin/omv-compose-restore';
            $cmdArgs[] = escapeshellarg($params['backup']);
            if (!empty($params['time'])) {
                $ts = str_replace(" ", "_", $params['time']);
                $ts = str_replace(":", "-", $ts);
                $cmdArgs[] = '--at ' . escapeshellarg($ts);
            }
            $cmd = new \OMV\System\Process($cmdArgs);
            $cmd->setRedirect2to1();
            $cmdLine = $cmd->getCommandLine();
            if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                throw new \OMV\ExecException($cmdLine, $output);
            }
            return $output;
        });
    }

    public function restoreGlobalEnv($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // get backup list from list file
        $sfpath = $this->getBackupPath($context);
        $globalEnv = sprintf('%s/global.env', $sfpath);
        if (file_exists($globalEnv)) {
            $curparams = $this->getGlobalEnv(null, $context);
            $curparams['globalenv'] = trim(file_get_contents($globalEnv));
            $this->setGlobalEnv($curparams, $context);
        } else {
            throw new \OMV\Exception($globalEnv . ' does not exist!');
        }
    }

    public function deleteBackup($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        $sfpath = $this->getBackupPath($context);
        $name = strval($params['name'] ?? '');
        if (strlen($name) < 1) {
          throw new \OMV\ExecException(
              gettext("No name specified!")
          );
        }
        // the name must be a single directory inside the backup folder
        if ($name !== basename($name) || $name === '.' || $name === '..') {
          throw new \OMV\ExecException(
              gettext("Invalid backup name!") . ' - ' . $name
          );
        }
        $delPath = sprintf('%s/%s', $sfpath, $name);
        if (!is_dir($delPath)) {
          throw new \OMV\ExecException(
            gettext("Directory does not exist!") .
            ' - ' . $delPath
          );
        }
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($delPath) {
                $cmdArgs = [];
                $cmdArgs[] = 'rm';
                $cmdArgs[] = '-rfv';
                $cmdArgs[] = escapeshellarg($delPath);
                $cmd = new \OMV\System\Process($cmdArgs);
                $cmd->setRedirect2to1();
                $cmdLine = $cmd->getCommandLine();
                if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                    throw new \OMV\ExecException($cmdLine, $output);
                }
                return $output;
            }
        );
    }

    public function getJobList($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.getlist");
        // Get configuration data.
        $db = \OMV\Config\Database::getInstance();
        $objects = $db->get("conf.service.compose.job");
        // Add additional job informations.
        $objectsAssoc = [];
        foreach ($objects as $objectk => &$objectv) {
            $excludes = str_replace(',', '<br />', $objectv->get("excludes"));
            $objectv->set("excludes", $excludes);
            $objectsAssoc[] = $objectv->getAssoc();
        }
        // Filter the result.
        return $this->applyFilter($objectsAssoc, $params['start'], $params['limit'],
            $params['sortfield'], $params['sortdir'], $params['search']);
    }

    function getJob($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.objectuuid");
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $result = $db->getAssoc("conf.service.compose.job", $params['uuid']);
        // set action visibility
        $result['maintenance'] = $result['backup'] || $result['update'] || $result['prune'];
        $result['cstate'] = $result['filestart'] || $result['filestop'];
        $result['cbuild'] = $result['filebuild'] || $result['filepull'] || $result['filenocache'] || $result['fileprunebuilder'];
        if ($result['filepull'] || $result['filenocache']) $result['filebuild'] = true;
        // Convert comma separated list into an array.
        $result['minute'] = explode(",", $result['minute']);
        $result['hour'] = explode(",", $result['hour']);
        $result['dayofmonth'] = explode(",", $result['dayofmonth']);
        $result['month'] = explode(",", $result['month']);
        $result['dayofweek'] = explode(",", $result['dayofweek']);
        return $result;
    }

    function setJob($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.compose.setjob");
        // set filebuild if filepull or filenocache are set
        if ($params['filepull'] || $params['filenocache']) $params['filebuild'] = true;
        // make checkboxes in hidden fields are set to false
        $modeKeys = ['maintenance', 'cstate', 'cbuild'];
        $disableMap = [
            'maintenance' => ['filestart', 'filestop', 'filebuild', 'filepull', 'filenocache', 'fileprunebuilder'],
            'cstate' => ['backup', 'update', 'prune', 'filebuild', 'filepull', 'filenocache', 'fileprunebuilder'],
            'cbuild' => ['backup', 'update', 'prune', 'filestart', 'filestop'],
        ];
        foreach ($disableMap as $mode => $disableKeys) {
            if ($params[$mode]) {
                foreach ($disableKeys as $k) {
                    $params[$k] = false;
                }
                break;
            }
        }
        // remove mode flags
        unset($params['maintenance'], $params['cstate'], $params['cbuild']);
        // Require at least one action
        $actionKeys = [
            'backup', 'update', 'prune',
            'filestart', 'filestop',
            'filebuild', 'filepull', 'filenocache', 'fileprunebuilder'
        ];
        $any = false;
        foreach ($actionKeys as $k) {
            if (!empty($params[$k])) {
                $any = true;
                break;
            }
        }
        if (!$any) {
            throw new \OMV\ExecException(gettext('You must select at least one action type!'));
        }
        // make sure backup scripts exist if specified
        if ($params['backup']) {
            $params['prebackup'] = trim($params['prebackup']);
            $params['postbackup'] = trim($params['postbackup']);
            if (strlen($params['prebackup']) > 1 && !file_exists($params['prebackup'])) {
                throw new \OMV\ExecException(gettext('The prebackup script does not exist!'));
            }
            if (strlen($params['postbackup']) > 1 && !file_exists($params['postbackup'])) {
                throw new \OMV\ExecException(gettext('The postbackup script does not exist!'));
            }
        } else {
            $params['prebackup'] = '';
            $params['postbackup'] = '';
        }
        // merge filter patterns with the selected compose files
        $filter = explode(',', $params['filter'] ?? '');
        $filterm = array_merge($filter, $params['filterselect'] ?? []);
        $filtert = array_map('trim', $filterm);
        $filteru = array_unique($filtert);
        $filterf = array_filter($filteru);
        // only sort if both the text field and the dropdown were used
        if (strlen(trim($params['filter'] ?? '')) > 0 && !empty($params['filterselect'])) {
            sort($filterf);
        }
        $params['filter'] = implode(',', $filterf);
        // merge excludefilter patterns with the selected compose files
        $excludefilter = explode(',', $params['excludefilter'] ?? '');
        $excludefilterm = array_merge($excludefilter, $params['excludeselect'] ?? []);
        $excludefiltert = array_map('trim', $excludefilterm);
        $excludefilteru = array_unique($excludefiltert);
        $excludefilterf = array_filter($excludefilteru);
        // only sort if both the text field and the dropdown were used
        if (strlen(trim($params['excludefilter'] ?? '')) > 0 && !empty($params['excludeselect'])) {
            sort($excludefilterf);
        }
        $params['excludefilter'] = implode(',', $excludefilterf);
        // remove the helper select fields
        unset($params['filterselect'], $params['excludeselect']);
        // clean filter (the cron jobs pass it inside single quotes)
        $params['filter'] = str_replace(['@','(',')',' ',"'"], '', $params['filter']);
        // clean excludefilter
        $params['excludefilter'] = str_replace(['@','(',')',' ',"'"], '', $params['excludefilter'] ?? '');
        // clean excludes
        $excludes = explode(',', $params['excludes']);
        $excludest = array_map('trim', $excludes);
        $excludesu = array_unique($excludest);
        $excludesf = array_filter($excludesu);
        sort($excludesf);
        $params['excludes'] = implode(',', $excludesf);
        // Convert array into a comma separated list.
        $params['minute'] = implode(",", $params['minute']);
        $params['hour'] = implode(",", $params['hour']);
        $params['dayofmonth'] = implode(",", $params['dayofmonth']);
        $params['month'] = implode(",", $params['month']);
        $params['dayofweek'] = implode(",", $params['dayofweek']);
        // Prepare the configuration object.
        $object = new \OMV\Config\ConfigObject("conf.service.compose.job");
        $db = \OMV\Config\Database::getInstance();
        $object->setAssoc($params);
        // Set the configuration object.
        $db->set($object);
        // Return the configuration object.
        return $object->getAssoc();
    }

    public function deleteJob($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.objectuuid");
        // Delete the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $object = $db->get("conf.service.compose.job", $params['uuid']);
        $db->delete($object);
        // Return the deleted configuration object.
        return $object->getAssoc();
    }

    public function doJob($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        // Validate the parameters of the RPC service method.
        $this->validateMethodParams($params, "rpc.common.objectuuid");
        // Get the configuration object.
        $db = \OMV\Config\Database::getInstance();
        $object = $db->get("conf.service.compose.job", $params['uuid']);
        $podman = $this->getPodman($context);
        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($object, $params, $podman) {
                $output = [];
                if ($object->get('backup')) {
                    $cmdArgs = [];
                    $cmdArgs[] = '/usr/sbin/omv-compose-backup-multi';
                    $cmdArgs[] = '-f ' . escapeshellarg($object->get('filter'));
                    $cmdArgs[] = '-u ' . escapeshellarg($params['uuid']);
                    $cmd = new \OMV\System\Process($cmdArgs);
                    $cmd->setRedirect2to1();
                    $cmdLine = $cmd->getCommandLine();
                    if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                        throw new \OMV\ExecException($cmdLine, $output);
                    }
                }
                if ($object->get('update')) {
                    $cmdArgs = [];
                    $cmdArgs[] = '/usr/sbin/omv-compose-update-multi';
                    $cmdArgs[] = '-f ' . escapeshellarg($object->get('filter'));
                    $cmdArgs[] = '-u ' . escapeshellarg($params['uuid']);
                    $cmd = new \OMV\System\Process($cmdArgs);
                    $cmd->setRedirect2to1();
                    $cmdLine = $cmd->getCommandLine();
                    if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                        throw new \OMV\ExecException($cmdLine, $output);
                    }
                }
                if ($object->get('prune')) {
                    $cmdArgs = [];
                    $cmdArgs[] = '/usr/sbin/omv-compose-prune';
                    $cmd = new \OMV\System\Process($cmdArgs);
                    $cmd->setRedirect2to1();
                    $cmdLine = $cmd->getCommandLine();
                    if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                        throw new \OMV\ExecException($cmdLine, $output);
                    }
                }
                if ($object->get('filestart')) {
                    $cmdArgs = [];
                    $cmdArgs[] = '/usr/sbin/omv-compose-start-multi';
                    $cmdArgs[] = '-f ' . escapeshellarg($object->get('filter'));
                    $cmdArgs[] = '-u ' . escapeshellarg($params['uuid']);
                    $cmd = new \OMV\System\Process($cmdArgs);
                    $cmd->setRedirect2to1();
                    $cmdLine = $cmd->getCommandLine();
                    if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                        throw new \OMV\ExecException($cmdLine, $output);
                    }
                }
                if ($object->get('filestop')) {
                    $cmdArgs = [];
                    $cmdArgs[] = '/usr/sbin/omv-compose-stop-multi';
                    $cmdArgs[] = '-f ' . escapeshellarg($object->get('filter'));
                    $cmdArgs[] = '-u ' . escapeshellarg($params['uuid']);
                    $cmd = new \OMV\System\Process($cmdArgs);
                    $cmd->setRedirect2to1();
                    $cmdLine = $cmd->getCommandLine();
                    if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                        throw new \OMV\ExecException($cmdLine, $output);
                    }
                }
                if ($object->get('filebuild')) {
                    $cmdArgs = [];
                    $cmdArgs[] = '/usr/sbin/omv-compose-build-multi';
                    $cmdArgs[] = '-f ' . escapeshellarg($object->get('filter'));
                    $cmdArgs[] = '-u ' . escapeshellarg($params['uuid']);
                    $cmdArgs[] = (bool)$object->get('filepull') ? '1' : '0';
                    $cmdArgs[] = (bool)$object->get('filenocache') ? '1' : '0';
                    $cmd = new \OMV\System\Process($cmdArgs);
                    $cmd->setRedirect2to1();
                    $cmdLine = $cmd->getCommandLine();
                    if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                        throw new \OMV\ExecException($cmdLine, $output);
                    }
                }
                if ($object->get('fileprunebuilder')) {
                    $cmdArgs = [];
                    $cmdArgs[] = '/usr/sbin/omv-compose-prunebuilder';
                    $cmd = new \OMV\System\Process($cmdArgs);
                    $cmd->setRedirect2to1();
                    $cmdLine = $cmd->getCommandLine();
                    if (0 !== $this->exec($cmdLine, $output, $bgOutputFilename)) {
                        throw new \OMV\ExecException($cmdLine, $output);
                    }
                }
                return $output;
            }
        );
    }

    public function getRepoList($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        // get repos
        $repos = [];
        $repoFile = '/root/.docker/config.json';
        if (file_exists($repoFile)) {
            $configData = json_decode(file_get_contents($repoFile), true);
            if (isset($configData['auths']) && is_array($configData['auths'])) {
                foreach ($configData['auths'] as $repo => $details) {
                    $repos[] = [
                        "repo" => $repo
                    ];
                }
            }
        }
        // Filter the result.
        return $this->applyFilter($repos, $params['start'], $params['limit'],
            $params['sortfield'], $params['sortdir'], $params['search']);
    }

    public function repoLogin($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        $cmdArgs = [];
        $cmdArgs[] = 'docker';
        $cmdArgs[] = 'login';
        $cmdArgs[] = escapeshellarg($params['url']);
        $cmdArgs[] = '--username';
        $cmdArgs[] = escapeshellarg($params['username']);
        $cmdArgs[] = '--password-stdin';
        $cmd = new \OMV\System\Process($cmdArgs);
        $podman = $this->getPodman($context);
        if ($podman) {
            $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
            $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
        }
        $cmd->setRedirect2to1();
        $cmdLine = $cmd->getCommandLine();
        // Write the password to stdin so it never appears in the command
        // line, the process list or the error message.
        $proc = proc_open($cmdLine, [0 => ['pipe', 'r'], 1 => ['pipe', 'w']], $pipes);
        if (!is_resource($proc)) {
            throw new \OMV\Exception(sprintf("Failed to execute command '%s'.", $cmdLine));
        }
        fwrite($pipes[0], strval($params['passwd']));
        fclose($pipes[0]);
        $output = explode("\n", rtrim(stream_get_contents($pipes[1])));
        fclose($pipes[1]);
        $exitStatus = proc_close($proc);
        if (0 !== $exitStatus) {
            throw new \OMV\ExecException($cmdLine, $output, $exitStatus);
        }
    }

    public function repoLogout($params, $context)
    {
        // Validate the RPC caller context.
        $this->validateMethodContext($context, ['role' => OMV_ROLE_ADMINISTRATOR]);
        $cmdArgs = [];
        $cmdArgs[] = 'docker';
        $cmdArgs[] = 'logout';
        $cmdArgs[] = escapeshellarg($params['repo']);
        $cmd = new \OMV\System\Process($cmdArgs);
        $podman = $this->getPodman($context);
        if ($podman) {
            $cmd->setEnv('DOCKER_HOST', $this->podmanSockPath);
            $cmd->setEnv('PODMAN_COMPOSE_QUIET', '1');
        }
        $cmd->execute($output, $exitStatus);
    }

    private function isResolvedPort($hostPort) {
        // Accept plain integers and integer ranges (e.g. 8080 or 8000-8010).
        // Reject env var references like ${REDIS_PORT} or ${HTTP_PORT:-8080}.
        return preg_match('/^\d+(-\d+)?$/', $hostPort) === 1;
    }

    private function parsePortEntry($portEntry, $filename, $svcName) {
        if (is_array($portEntry)) {
            // Long form: {target: 80, published: 8080, protocol: tcp}
            $containerPort = isset($portEntry['target']) ? (string)$portEntry['target'] : '';
            $hostPort = isset($portEntry['published']) ? (string)$portEntry['published'] : '';
            $protocol = isset($portEntry['protocol']) ? (string)$portEntry['protocol'] : 'tcp';
            $hostIp = isset($portEntry['host_ip']) ? (string)$portEntry['host_ip'] : '';
            if ($hostPort === '' || $hostPort === '0') return null;
            if (!$this->isResolvedPort($hostPort)) return null;
            return $this->buildPortRecord($filename, $svcName, $hostIp, $hostPort, $containerPort, $protocol);
        }

        $portStr = trim((string)$portEntry);

        // Extract protocol suffix
        $protocol = 'tcp';
        if (($slashPos = strrpos($portStr, '/')) !== false) {
            $protocol = substr($portStr, $slashPos + 1);
            $portStr = substr($portStr, 0, $slashPos);
        }

        // Split by colon: HOST:CONTAINER or IP:HOST:CONTAINER. The last two
        // parts are always the ports, so anything before them is the IP
        // (this also covers IPv6 addresses like [::1]:8080:80).
        $parts = explode(':', $portStr);
        $numParts = count($parts);

        if ($numParts === 1) {
            // Container-only port, no host binding
            return null;
        }
        $containerPort = array_pop($parts);
        $hostPort = array_pop($parts);
        $hostIp = trim(implode(':', $parts), '[]');

        if ($hostPort === '' || $hostPort === '0') return null;
        if (!$this->isResolvedPort($hostPort)) return null;

        return $this->buildPortRecord($filename, $svcName, $hostIp, $hostPort, $containerPort, $protocol);
    }

    private function buildPortRecord($filename, $svcName, $hostIp, $hostPort, $containerPort, $protocol) {
        // host_port stays numeric for doFindFreePorts; host_port_label adds
        // the bind address in brackets after the port so sorting still works.
        $hostLabel = $hostPort;
        if ($hostIp !== '') $hostLabel .= sprintf(' [%s]', $hostIp);
        return [
            'id' => sprintf('%s:%s:%s:%s:%s', $filename, $svcName, $hostIp, $hostPort, $protocol),
            'file' => $filename,
            'service' => $svcName,
            'host_ip' => $hostIp,
            'host_port' => $hostPort,
            'host_port_label' => $hostLabel,
            'container_port' => $containerPort,
            'protocol' => $protocol,
        ];
    }

    private function parseComposePorts($body, $filename) {
        $results = [];
        if (!function_exists('yaml_parse')) return $results;

        $parsed = @yaml_parse($body);
        if (!is_array($parsed) || !isset($parsed['services']) || !is_array($parsed['services'])) {
            return $results;
        }

        foreach ($parsed['services'] as $svcName => $svcConfig) {
            if (!is_array($svcConfig) || !isset($svcConfig['ports'])) continue;
            foreach ($svcConfig['ports'] as $portEntry) {
                $record = $this->parsePortEntry($portEntry, $filename, (string)$svcName);
                if ($record !== null) {
                    $results[] = $record;
                }
            }
        }

        return $results;
    }

    public function getUsedPorts($params, $context) {
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        $this->validateMethodParams($params, "rpc.common.getlist");

        $db = \OMV\Config\Database::getInstance();
        $objects = $db->get("conf.service.compose.file");

        $results = [];
        foreach ($objects as $objectv) {
            $name = $objectv->get('name');
            $body = $objectv->get('body');
            foreach ($this->parseComposePorts($body, $name) as $port) {
                $results[] = $port;
            }
        }

        return $this->applyFilter($results, $params['start'], $params['limit'],
            $params['sortfield'], $params['sortdir'], $params['search']);
    }

    public function getUsedPortsBg($params, $context) {
        return $this->callMethodBg("getUsedPorts", $params, $context);
    }

    public function doFindFreePorts($params, $context) {
        $this->validateMethodContext($context, ["role" => OMV_ROLE_ADMINISTRATOR]);
        $startPort = max(1, min(65535, intval($params['startPort'] ?? 1024)));

        $db = \OMV\Config\Database::getInstance();
        $objects = $db->get("conf.service.compose.file");
        $usedPorts = [];

        foreach ($objects as $objectv) {
            foreach ($this->parseComposePorts($objectv->get('body'), '') as $port) {
                $hp = $port['host_port'];
                if (strpos($hp, '-') !== false) {
                    [$rangeStart, $rangeEnd] = explode('-', $hp, 2);
                    if (is_numeric($rangeStart) && is_numeric($rangeEnd)) {
                        for ($p = intval($rangeStart); $p <= intval($rangeEnd) && $p <= 65535; $p++) {
                            $usedPorts[$p] = true;
                        }
                    }
                } elseif (is_numeric($hp)) {
                    $usedPorts[intval($hp)] = true;
                }
            }
        }

        return $this->execBgProc(function($bgStatusFilename, $bgOutputFilename)
            use ($startPort, $usedPorts) {
                $suggestions = [];
                $port = $startPort;
                while (count($suggestions) < 20 && $port <= 65535) {
                    if (!isset($usedPorts[$port])) {
                        $suggestions[] = $port;
                    }
                    $port++;
                }
                $output = sprintf("Suggested free host ports starting from %d:\n\n", $startPort);
                foreach ($suggestions as $p) {
                    $output .= sprintf("  %d\n", $p);
                }
                if (empty($suggestions)) {
                    $output .= "  No free ports found in range.\n";
                }
                file_put_contents($bgOutputFilename, $output, FILE_APPEND);
                return [];
            }
        );
    }
}
