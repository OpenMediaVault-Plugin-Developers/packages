
phpVirtualBox is Copyright (C) 2015 Ian Moore (imoore76 at yahoo dot com)

FREE, WITHOUT WARRANTY:

All files of this program (phpVirtualBox) are distributed under the
terms contained in the LICENSE.txt file in this folder unless otherwise
specified in an individual source file. By using this software, you are
agreeing to the terms contained therein. If you have not received and read
the license file, or do not agree with its conditions, please cease using
this software immediately and remove any copies you may have in your
possession.

INSTALLATION:

Rename config.php-example to config.php and edit as needed.

Default login is username: admin password: admin

Please see the wiki located at
http://sourceforge.net/p/phpvirtualbox/wiki/Home/
for detailed installation and configuration instructions.

PASSWORD RECOVERY:

Rename the file recovery.php-disabled to recovery.php, navigate to it in
your web browser, and follow the instructions presented.
