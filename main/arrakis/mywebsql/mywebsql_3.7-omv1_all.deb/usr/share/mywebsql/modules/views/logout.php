<script type="text/javascript" language="javascript">
	win = window.parent ? window.parent : window;
	win.location = win.location;
</script>
