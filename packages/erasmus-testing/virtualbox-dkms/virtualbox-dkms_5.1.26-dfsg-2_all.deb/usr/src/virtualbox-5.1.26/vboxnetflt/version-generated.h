#ifndef ___version_generated_h___
#define ___version_generated_h___

#define VBOX_VERSION_MAJOR 5
#define VBOX_VERSION_MINOR 1
#define VBOX_VERSION_BUILD 26
#define VBOX_VERSION_STRING_RAW "5.1.26"
#define VBOX_VERSION_STRING "5.1.26_Debian"
#define VBOX_API_VERSION_STRING "5_1"

#define VBOX_PRIVATE_BUILD_DESC "Private build by aaron"

#endif
