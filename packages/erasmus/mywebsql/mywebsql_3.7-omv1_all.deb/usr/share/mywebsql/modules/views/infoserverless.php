<div id='results'>
</div>

<script type="text/javascript" language="javascript">
parent.transferInfoMessage();
</script>
