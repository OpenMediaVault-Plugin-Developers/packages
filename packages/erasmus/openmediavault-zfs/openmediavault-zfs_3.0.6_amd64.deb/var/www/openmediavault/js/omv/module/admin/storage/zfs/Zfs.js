// require("js/omv/WorkspaceManager.js")
OMV.WorkspaceManager.registerNode({
    id      : "zfs",
    path    : "/storage",
    text    : _("ZFS"),
    icon16  : "images/zfs_main.png",
    iconSvg : "images/zfs_main.svg"
});

