#ifndef ___version_generated_h___
#define ___version_generated_h___

#define VBOX_VERSION_MAJOR 5
#define VBOX_VERSION_MINOR 2
#define VBOX_VERSION_BUILD 8
#define VBOX_VERSION_STRING_RAW "5.2.8"
#define VBOX_VERSION_STRING "5.2.8_Debian"
#define VBOX_API_VERSION_STRING "5_2"

#define VBOX_PRIVATE_BUILD_DESC "Private build by aaron"

#endif
